// ============================================================
//  Part 02 – Problem 04
//  Topic   : Custom SelectionSort for integer array
//            + sorting shape areas generated from Part 02
// ============================================================

namespace P04_SelectionSort;

public static class Sorter
{
    // ── Selection Sort ────────────────────────────────────────
    // O(n²) — finds the minimum in the unsorted portion each pass
    public static void SelectionSort(int[] numbers)
    {
        int n = numbers.Length;
        for (int i = 0; i < n - 1; i++)
        {
            // Find index of minimum element in numbers[i..n-1]
            int minIdx = i;
            for (int j = i + 1; j < n; j++)
            {
                if (numbers[j] < numbers[minIdx])
                    minIdx = j;
            }
            // Swap minimum into position i
            if (minIdx != i)
                (numbers[i], numbers[minIdx]) = (numbers[minIdx], numbers[i]);
        }
    }
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – P04  |  Custom SelectionSort                ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        // ── Demo 1: integer array ──────────────────────────────
        int[] nums = { 64, 25, 12, 22, 11, 90, 3, 47, 55, 8 };
        Console.WriteLine("\n  Integer array — Before:");
        Console.WriteLine("  " + string.Join(", ", nums));

        Sorter.SelectionSort(nums);
        Console.WriteLine("  Integer array — After SelectionSort:");
        Console.WriteLine("  " + string.Join(", ", nums));

        // ── Demo 2: shape areas from Part 02 (as ints) ────────
        // Square areas:   1,4,9,16,25,36,49,64,81,100
        // Circle areas:   3,12,28,50,78,113,153,201,254,314  (truncated to int)
        int[] shapeAreas =
        {
            1, 4, 9, 16, 25, 36, 49, 64, 81, 100,   // squares
            3, 12, 28, 50, 78, 113, 153, 201, 254, 314  // circles
        };

        Console.WriteLine("\n  Shape areas (squares + circles) — Before:");
        Console.WriteLine("  " + string.Join(", ", shapeAreas));

        Sorter.SelectionSort(shapeAreas);
        Console.WriteLine("  After SelectionSort:");
        Console.WriteLine("  " + string.Join(", ", shapeAreas));

        Console.WriteLine("\n  Step-by-step trace for small array { 5, 3, 8, 1, 2 }:");
        int[] trace = { 5, 3, 8, 1, 2 };
        int n = trace.Length;
        for (int i = 0; i < n - 1; i++)
        {
            int minIdx = i;
            for (int j = i + 1; j < n; j++)
                if (trace[j] < trace[minIdx]) minIdx = j;
            (trace[i], trace[minIdx]) = (trace[minIdx], trace[i]);
            Console.WriteLine($"  Pass {i + 1}: [{string.Join(", ", trace)}]");
        }
    }
}
