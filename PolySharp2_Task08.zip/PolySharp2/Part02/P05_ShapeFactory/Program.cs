// ============================================================
//  Part 02 – Problem 05
//  Topic   : Factory Pattern — ShapeFactory
//  Demonstrates: coding against abstraction (GeometricShape)
// ============================================================

namespace P05_ShapeFactory;

// ── Abstract base (same as P03) ───────────────────────────────
public abstract class GeometricShape
{
    public double Dimension1 { get; }
    public double Dimension2 { get; }

    protected GeometricShape(double d1, double d2)
    { Dimension1 = d1; Dimension2 = d2; }

    public abstract double CalculateArea();
    public abstract double Perimeter { get; }

    public virtual void Display()
        => Console.WriteLine($"  {GetType().Name,-12}  " +
                             $"D1={Dimension1,6:F2}  D2={Dimension2,6:F2}  " +
                             $"Area={CalculateArea(),9:F4}  " +
                             $"Perimeter={Perimeter,9:F4}");
}

public class Rectangle : GeometricShape
{
    public Rectangle(double w, double h) : base(w, h) { }
    public override double CalculateArea() => Dimension1 * Dimension2;
    public override double Perimeter => 2 * (Dimension1 + Dimension2);
}

public class Triangle : GeometricShape
{
    public Triangle(double b, double h) : base(b, h) { }
    public override double CalculateArea() => 0.5 * Dimension1 * Dimension2;
    public override double Perimeter
        => Dimension1 + Dimension2 +
           Math.Sqrt(Dimension1 * Dimension1 + Dimension2 * Dimension2);
}

public class Square : GeometricShape
{
    public Square(double side) : base(side, side) { }
    public override double CalculateArea() => Dimension1 * Dimension1;
    public override double Perimeter => 4 * Dimension1;
}

// ── Factory ───────────────────────────────────────────────────
public static class ShapeFactory
{
    /// <summary>
    /// Creates a GeometricShape by name.
    /// Caller codes against GeometricShape — never against Rectangle directly.
    /// </summary>
    public static GeometricShape CreateShape(string shapeType, double dim1, double dim2)
    {
        return shapeType.ToLower() switch
        {
            "rectangle" => new Rectangle(dim1, dim2),
            "triangle"  => new Triangle(dim1, dim2),
            "square"    => new Square(dim1),
            _ => throw new ArgumentException($"Unknown shape type: '{shapeType}'")
        };
    }
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – P05  |  Shape Factory Pattern               ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        // All created through factory — caller never uses 'new Rectangle' directly
        var requests = new (string type, double d1, double d2)[]
        {
            ("rectangle", 5,  3),
            ("triangle",  6,  8),
            ("square",    4,  0),
            ("rectangle", 10, 2),
            ("triangle",  3,  4),
            ("square",    7,  0),
        };

        List<GeometricShape> shapes = new();
        Console.WriteLine("\n  Creating shapes via ShapeFactory.CreateShape()...");
        foreach (var (type, d1, d2) in requests)
        {
            var shape = ShapeFactory.CreateShape(type, d1, d2);
            shapes.Add(shape);
        }

        Console.WriteLine("\n  All created shapes:");
        Console.WriteLine("  Shape         D1      D2        Area        Perimeter");
        Console.WriteLine("  " + new string('-', 68));
        foreach (var s in shapes) s.Display();

        Console.WriteLine("\n  Sorted by Area (using IComparable lambda):");
        shapes.Sort((a, b) => a.CalculateArea().CompareTo(b.CalculateArea()));
        foreach (var s in shapes) s.Display();

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Factory pattern benefit:");
        Console.WriteLine("  Adding a new shape (Pentagon, Hexagon) requires only:");
        Console.WriteLine("   1. New class deriving from GeometricShape.");
        Console.WriteLine("   2. One new case in the switch.");
        Console.WriteLine("  Zero changes to any calling code — pure OCP.\n");
    }
}
