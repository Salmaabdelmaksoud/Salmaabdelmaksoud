// ============================================================
//  Part 02 – Problem 03
//  Topic   : Abstract class GeometricShape → Triangle, Rectangle
// ============================================================

namespace P03_GeometricShapes;

// ── Abstract base ─────────────────────────────────────────────
public abstract class GeometricShape
{
    public double Dimension1 { get; }
    public double Dimension2 { get; }

    protected GeometricShape(double d1, double d2)
    { Dimension1 = d1; Dimension2 = d2; }

    public abstract double CalculateArea();
    public abstract double Perimeter { get; }

    public void Display()
    {
        Console.WriteLine($"  {GetType().Name,-12} " +
                          $"D1={Dimension1,6:F2}  D2={Dimension2,6:F2} " +
                          $" | Area={CalculateArea(),9:F4} " +
                          $" | Perimeter={Perimeter,9:F4}");
    }
}

// ── Triangle ──────────────────────────────────────────────────
public class Triangle : GeometricShape
{
    public Triangle(double baseLen, double height) : base(baseLen, height) { }

    public override double CalculateArea() => 0.5 * Dimension1 * Dimension2;

    // Perimeter approximation using hypotenuse (right triangle)
    public override double Perimeter
        => Dimension1 + Dimension2 +
           Math.Sqrt(Dimension1 * Dimension1 + Dimension2 * Dimension2);
}

// ── Rectangle ─────────────────────────────────────────────────
public class Rectangle : GeometricShape
{
    public Rectangle(double width, double height) : base(width, height) { }

    public override double CalculateArea() => Dimension1 * Dimension2;

    public override double Perimeter => 2 * (Dimension1 + Dimension2);
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – P03  |  GeometricShape Hierarchy            ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        List<GeometricShape> shapes = new()
        {
            new Rectangle(5,  3),
            new Rectangle(10, 4),
            new Triangle(6,  8),
            new Triangle(3,  4),
            new Rectangle(7,  7),
        };

        Console.WriteLine("\n  Shape         D1      D2        Area        Perimeter");
        Console.WriteLine("  " + new string('-', 68));
        foreach (var s in shapes) s.Display();
    }
}
