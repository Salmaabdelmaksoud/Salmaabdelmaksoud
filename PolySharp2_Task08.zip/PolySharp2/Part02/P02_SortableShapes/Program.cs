// ============================================================
//  Part 02 – Problem 02
//  Topic   : IComparable<Shape> — Sort shapes by area
// ============================================================

namespace P02_SortableShapes;

// ── Shape with IComparable ────────────────────────────────────
public class Shape : IComparable<Shape>
{
    public string Name { get; }
    public double Area { get; }

    public Shape(string name, double area)
    { Name = name; Area = area; }

    public int CompareTo(Shape? other)
    {
        if (other is null) return 1;
        return Area.CompareTo(other.Area);
    }

    public override string ToString()
        => $"  {Name,-12}  Area = {Area,10:F4}";
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – P02  |  Sortable Shapes with IComparable    ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        Shape[] shapes =
        {
            new Shape("Square 4x4",        16.0),
            new Shape("Circle r=3",        Math.PI * 9),
            new Shape("Rectangle 2x8",     16.0),
            new Shape("Circle r=1",        Math.PI),
            new Shape("Square 1x1",        1.0),
            new Shape("Rectangle 10x5",    50.0),
            new Shape("Circle r=5",        Math.PI * 25),
        };

        Console.WriteLine("\n  Before sort:");
        foreach (var s in shapes) Console.WriteLine(s);

        Array.Sort(shapes);   // uses CompareTo()

        Console.WriteLine("\n  After Array.Sort() — ascending by Area:");
        foreach (var s in shapes) Console.WriteLine(s);
    }
}
