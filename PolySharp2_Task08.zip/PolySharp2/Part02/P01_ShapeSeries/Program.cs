// ============================================================
//  Part 02 – Problem 01
//  Topic   : IShapeSeries — SquareSeries & CircleSeries
//  Concepts: Coding against abstraction, not concreteness
// ============================================================

namespace P01_ShapeSeries;

// ── Interface (abstraction) ───────────────────────────────────
public interface IShapeSeries
{
    int  CurrentShapeArea { get; set; }
    void GetNextArea();
    void ResetSeries();
}

// ── SquareSeries : side 1,2,3,… → area 1,4,9,… ──────────────
public class SquareSeries : IShapeSeries
{
    private int _side = 0;
    public int CurrentShapeArea { get; set; }

    public void GetNextArea()
    {
        _side++;
        CurrentShapeArea = _side * _side;
    }

    public void ResetSeries()
    {
        _side            = 0;
        CurrentShapeArea = 0;
        Console.WriteLine("  [SquareSeries] Reset.");
    }
}

// ── CircleSeries : radius 1,2,3,… → area π,4π,9π,… ──────────
public class CircleSeries : IShapeSeries
{
    private int _radius = 0;
    public int CurrentShapeArea { get; set; }

    public void GetNextArea()
    {
        _radius++;
        CurrentShapeArea = (int)(Math.PI * _radius * _radius);
    }

    public void ResetSeries()
    {
        _radius          = 0;
        CurrentShapeArea = 0;
        Console.WriteLine("  [CircleSeries] Reset.");
    }
}

// ── PrintTenShapes — coded against IShapeSeries (abstraction) ─
public static class SeriesPrinter
{
    public static void PrintTenShapes(IShapeSeries series)
    {
        series.ResetSeries();
        Console.WriteLine($"\n  {series.GetType().Name} — First 10 areas:");
        Console.Write("  ");
        for (int i = 1; i <= 10; i++)
        {
            series.GetNextArea();
            Console.Write($"{series.CurrentShapeArea,6}");
            if (i == 5) Console.Write("\n  ");
        }
        Console.WriteLine();
    }
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – P01  |  IShapeSeries                        ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        // Notice: PrintTenShapes takes IShapeSeries — works for ANY future series too
        SeriesPrinter.PrintTenShapes(new SquareSeries());
        SeriesPrinter.PrintTenShapes(new CircleSeries());

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Coding against abstraction (IShapeSeries) means");
        Console.WriteLine("  PrintTenShapes never needs to change when a new series");
        Console.WriteLine("  (TriangleSeries, FibonacciSeries…) is added.");
        Console.WriteLine("  The method is closed for modification, open for extension.\n");
    }
}
