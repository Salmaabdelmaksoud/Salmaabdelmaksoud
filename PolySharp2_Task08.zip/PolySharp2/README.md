# PolySharp 2 🔷
## C# OOP – Task 08 | Full Assignment Solution

---

## 🚀 How to Open in Visual Studio

1. Extract the ZIP anywhere on your machine
2. Double-click **`PolySharp2.sln`**
3. In **Solution Explorer** → right-click any project → **Set as Startup Project**
4. Press **Ctrl + F5** to run

---

## 📁 Project Map

### Part 01 – Problems & Questions

| Project | Topic |
|---|---|
| `P01_IVehicle` | IVehicle interface → Car & Bike |
| `P02_AbstractShape` | Abstract Shape vs interface approach |
| `P03_IComparable` | IComparable Product sorting |
| `P04_CopyConstructor` | Shallow vs Deep copy |
| `P05_ExplicitInterface` | Explicit interface implementation |
| `P06_StructEncapsulation` | Struct encapsulation + abstraction |
| `P07_ILogger` | Default interface method + override |
| `P08_BookConstructors` | Constructor overloading |

### Part 02 – Design Challenges

| Project | Topic |
|---|---|
| `P01_ShapeSeries` | IShapeSeries → SquareSeries & CircleSeries |
| `P02_SortableShapes` | IComparable shape sorting |
| `P03_GeometricShapes` | Abstract GeometricShape hierarchy |
| `P04_SelectionSort` | Custom SelectionSort implementation |
| `P05_ShapeFactory` | Factory Pattern |

---

## 📚 Part 02 – Theory Questions

### 1. LinkedIn Article: Abstract Class

**"Abstract Classes: The Backbone of Extensible C# Design"**

Abstract classes sit in the sweet spot between interfaces and concrete classes.
They let you define *what* a family of objects must do (abstract members) and *how*
some of that behaviour is shared (concrete members) — all in one place.

A `GeometricShape` abstract class is a perfect example: `CalculateArea()` is abstract
because every shape computes area differently. But `Display()` is concrete because
printing the result is always the same. Without abstract classes you'd either duplicate
`Display()` across every shape, or lose type safety by using raw interfaces everywhere.

When to use: whenever related classes share state (fields) or partial behaviour,
and you want to prevent direct instantiation of the base.

---

### 2. Coding Against an Interface vs a Class

**What does "code against an interface" mean?**

It means your variables, method parameters, and return types should be declared as
the interface (or abstract type), not the concrete class.

```csharp
// Bad — concrete dependency
Car myCar = new Car();
Drive(myCar);          // Drive() only works with Car

// Good — coded against interface
IVehicle vehicle = new Car();
Drive(vehicle);        // Drive() works with ANY IVehicle
```

**What does "code against abstraction, not concreteness" mean?**

It is the same idea applied more broadly: depend on what a thing *can do*,
not on what it *specifically is*. `PrintTenShapes(IShapeSeries series)` doesn't
know or care whether `series` is a `SquareSeries` or `CircleSeries`.
It only knows the three operations declared on `IShapeSeries`.

This is the **Dependency Inversion Principle**: high-level modules should depend
on abstractions, not on low-level details.

---

### 3. Abstraction as a Guideline

Abstraction means: **expose only what is necessary; hide everything else.**

It is not just a feature — it is a design discipline:

| Level | How we implement it in this task |
|---|---|
| Interface | `IVehicle` hides Car/Bike internals — only `StartEngine/StopEngine` visible |
| Abstract class | `GeometricShape` hides individual area formulas — exposes `CalculateArea()` |
| Encapsulation | `Account` struct hides `_balance` — only `Deposit/Withdraw` exposed |
| Factory | `ShapeFactory` hides `new Rectangle` — caller only sees `GeometricShape` |

**Relation with Encapsulation:**
- Abstraction decides **what to hide** (the design decision).
- Encapsulation is the **mechanism that enforces it** (`private` fields, `public` methods).
- You cannot have meaningful abstraction without encapsulation.

---

## 🎁 Part 03 – Bonus

### Self-Study Report

**Key takeaways from Task 08:**

- Interfaces and abstract classes are both tools for abstraction — choose based on
  whether you need shared state/code (abstract class) or pure contract (interface).
- `IComparable<T>` is a built-in contract that unlocks all of .NET's sorting
  infrastructure for your custom types at zero extra cost.
- Explicit interface implementation is a powerful conflict resolver — and also a
  way to hide interface methods from the public surface of a class.
- The Factory Pattern is abstraction in practice: callers never `new` a concrete type;
  they ask the factory for something that satisfies a contract.
- SelectionSort is O(n²) but perfectly illustrates the "find minimum, swap" pattern
  that underlies more advanced algorithms.

---

### Operator Overloading

Operator overloading lets you define how standard C# operators (`+`, `-`, `*`, `==`, `<`, `>`, etc.)
behave when applied to your custom types.

```csharp
public class Money
{
    public decimal Amount   { get; }
    public string  Currency { get; }

    public Money(decimal amount, string currency)
    { Amount = amount; Currency = currency; }

    // Overload +
    public static Money operator +(Money a, Money b)
    {
        if (a.Currency != b.Currency)
            throw new InvalidOperationException("Currency mismatch");
        return new Money(a.Amount + b.Amount, a.Currency);
    }

    // Overload == and !=
    public static bool operator ==(Money a, Money b) => a.Amount == b.Amount;
    public static bool operator !=(Money a, Money b) => !(a == b);

    public override string ToString() => $"{Amount:F2} {Currency}";
}

// Usage — reads like natural arithmetic
Money salary  = new Money(5000, "EGP");
Money bonus   = new Money(1500, "EGP");
Money total   = salary + bonus;   // 6500.00 EGP
```

**Rules:**
- Operators must be `public static` methods on the class.
- If you overload `==` you must also overload `!=` and override `Equals()`/`GetHashCode()`.
- Overload only when the operation is genuinely intuitive for the type.
  `Vector + Vector` makes sense. `Student + Student` probably does not.

---

## 🛠 Requirements
- .NET 8 SDK
- Visual Studio 2022 (any edition)
