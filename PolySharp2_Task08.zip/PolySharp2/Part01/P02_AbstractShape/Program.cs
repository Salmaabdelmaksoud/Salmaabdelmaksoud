// ============================================================
//  Part 01 – Problem 02
//  Topic   : Abstract class Shape vs Interface-based approach
//  Q: When should you prefer an abstract class over an interface?
// ============================================================

namespace P02_AbstractShape;

// ── Abstract class approach ───────────────────────────────────
public abstract class Shape
{
    public string Color { get; set; } = "White";

    // Non-abstract — shared implementation all subclasses use
    public void Display()
        => Console.WriteLine($"  [{GetType().Name}]  Color={Color}  Area={GetArea():F4}");

    // Abstract — every subclass must provide its own version
    public abstract double GetArea();
}

public class Rectangle : Shape
{
    public double Width  { get; }
    public double Height { get; }

    public Rectangle(double w, double h, string color = "Blue")
    { Width = w; Height = h; Color = color; }

    public override double GetArea() => Width * Height;
}

public class Circle : Shape
{
    public double Radius { get; }

    public Circle(double r, string color = "Red")
    { Radius = r; Color = color; }

    public override double GetArea() => Math.PI * Radius * Radius;
}

// ── Interface-based approach for comparison ───────────────────
public interface IShape
{
    double GetArea();
    void Display();    // Every implementor must write Display() themselves
}

public class RectangleI : IShape
{
    public double Width, Height;
    public RectangleI(double w, double h) { Width = w; Height = h; }
    public double GetArea() => Width * Height;
    // Must re-write Display() in every class — no code reuse
    public void Display() => Console.WriteLine($"  [RectangleI]  Area={GetArea():F4}");
}

public class CircleI : IShape
{
    public double Radius;
    public CircleI(double r) { Radius = r; }
    public double GetArea() => Math.PI * Radius * Radius;
    public void Display() => Console.WriteLine($"  [CircleI]     Area={GetArea():F4}");
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P02  |  Abstract Class vs Interface         ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        Console.WriteLine("\n  — Abstract Class approach —");
        List<Shape> shapes = new() { new Rectangle(5, 3), new Circle(4), new Rectangle(2, 7, "Green") };
        foreach (var s in shapes) s.Display();   // Display() reused from base — zero duplication

        Console.WriteLine("\n  — Interface approach (no shared Display) —");
        List<IShape> ishapes = new() { new RectangleI(5, 3), new CircleI(4) };
        foreach (var s in ishapes) s.Display();

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Q: When to prefer abstract class over interface?");
        Console.WriteLine("────────────────────────────────────────────────────────");
        Console.WriteLine("  Use abstract class when:");
        Console.WriteLine("   • You have shared state (fields like Color) or shared code.");
        Console.WriteLine("   • Subclasses share a common base behaviour (Display here).");
        Console.WriteLine("   • You want to enforce a common constructor or template.");
        Console.WriteLine("  Use interface when:");
        Console.WriteLine("   • You only need a contract — no shared implementation.");
        Console.WriteLine("   • A class needs to implement multiple contracts (multi-interface).\n");
    }
}
