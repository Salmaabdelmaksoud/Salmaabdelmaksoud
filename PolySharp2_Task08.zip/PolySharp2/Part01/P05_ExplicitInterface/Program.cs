// ============================================================
//  Part 01 – Problem 05
//  Topic   : Explicit Interface Implementation
//  Q: How does explicit interface implementation resolve naming conflicts?
// ============================================================

namespace P05_ExplicitInterface;

// ── Interfaces ───────────────────────────────────────────────
public interface IWalkable
{
    void Walk();   // walking as a movement contract
}

public interface IPerformable
{
    void Walk();   // walking as a dance/performance step — SAME name, different meaning!
}

// ── Robot implements both — explicit implementation solves the conflict ──
public class Robot : IWalkable, IPerformable
{
    public string Name { get; }

    public Robot(string name) { Name = name; }

    // Robot's OWN Walk() method — called on Robot reference directly
    public void Walk()
        => Console.WriteLine($"  [{Name}] Robot.Walk()      — Normal locomotion movement");

    // Explicit IWalkable.Walk() — only accessible via IWalkable reference
    void IWalkable.Walk()
        => Console.WriteLine($"  [{Name}] IWalkable.Walk()  — Navigating terrain step-by-step");

    // Explicit IPerformable.Walk() — only accessible via IPerformable reference
    void IPerformable.Walk()
        => Console.WriteLine($"  [{Name}] IPerformable.Walk()— Performing a choreographed walk");
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P05  |  Explicit Interface Implementation   ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        Robot robot = new Robot("R2-D2");

        Console.WriteLine("\n  — Via Robot reference (own method) —");
        robot.Walk();

        Console.WriteLine("\n  — Via IWalkable reference —");
        IWalkable walker = robot;
        walker.Walk();

        Console.WriteLine("\n  — Via IPerformable reference —");
        IPerformable performer = robot;
        performer.Walk();

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Q: How does explicit interface implementation help?");
        Console.WriteLine("────────────────────────────────────────────────────────");
        Console.WriteLine("  When two interfaces declare a method with the same name,");
        Console.WriteLine("  explicit implementation lets you provide a separate body");
        Console.WriteLine("  for each interface. Each body is only callable through");
        Console.WriteLine("  the specific interface reference — no ambiguity, no conflict.\n");
    }
}
