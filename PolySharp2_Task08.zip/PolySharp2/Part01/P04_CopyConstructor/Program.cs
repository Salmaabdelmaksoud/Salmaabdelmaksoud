// ============================================================
//  Part 01 – Problem 04
//  Topic   : Copy Constructor — Shallow vs Deep Copy
//  Q: What is the primary purpose of a copy constructor?
// ============================================================

namespace P04_CopyConstructor;

// ── Grade (reference type inside Student — proves deep copy) ─
public class Grade
{
    public string Subject { get; set; }
    public double Score   { get; set; }

    public Grade(string subject, double score)
    { Subject = subject; Score = score; }

    public override string ToString() => $"{Subject}:{Score}";
}

// ── Student ───────────────────────────────────────────────────
public class Student
{
    public int    Id   { get; set; }
    public string Name { get; set; }

    // Reference type — this is what distinguishes shallow from deep
    public Grade TopGrade { get; set; }

    // Normal constructor
    public Student(int id, string name, Grade topGrade)
    {
        Id       = id;
        Name     = name;
        TopGrade = topGrade;
    }

    // ── SHALLOW copy constructor ──────────────────────────────
    // Copies the Grade reference — both students point at the SAME Grade object
    public Student(Student other)
    {
        Id       = other.Id;
        Name     = other.Name;
        TopGrade = other.TopGrade;   // same reference → shallow!
    }

    // ── DEEP copy constructor ─────────────────────────────────
    // Creates a brand-new Grade object — fully independent copy
    public static Student DeepCopy(Student other)
        => new Student(other.Id, other.Name,
                       new Grade(other.TopGrade.Subject, other.TopGrade.Score));

    public override string ToString()
        => $"  Id={Id}  Name={Name,-12}  TopGrade=[{TopGrade}]  " +
           $"(Grade @{RuntimeHelpers.GetHashCode(TopGrade)})";
}

// Needed for hash code demonstration
using System.Runtime.CompilerServices;

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P04  |  Copy Constructor (Shallow vs Deep)  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        Grade  g1      = new Grade("Math", 95.0);
        Student original = new Student(1, "Alice", g1);

        // ── Shallow copy ──────────────────────────────────────
        Student shallow = new Student(original);   // copy constructor

        Console.WriteLine("\n  BEFORE mutation:");
        Console.WriteLine("  Original : " + original);
        Console.WriteLine("  Shallow  : " + shallow);

        shallow.TopGrade.Score = 50.0;   // mutates ORIGINAL too!
        Console.WriteLine("\n  AFTER changing shallow.TopGrade.Score = 50:");
        Console.WriteLine("  Original : " + original);   // also changed!
        Console.WriteLine("  Shallow  : " + shallow);
        Console.WriteLine("  *** Original was affected — same Grade reference! ***");

        // ── Deep copy ─────────────────────────────────────────
        Student restored = new Student(1, "Alice", new Grade("Math", 95.0));
        Student deep     = Student.DeepCopy(restored);

        Console.WriteLine("\n  BEFORE mutation (deep copy):");
        Console.WriteLine("  Original : " + restored);
        Console.WriteLine("  Deep     : " + deep);

        deep.TopGrade.Score = 10.0;   // does NOT affect original
        Console.WriteLine("\n  AFTER changing deep.TopGrade.Score = 10:");
        Console.WriteLine("  Original : " + restored);   // unchanged
        Console.WriteLine("  Deep     : " + deep);
        Console.WriteLine("  *** Original is safe — fully independent copy! ***");

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Q: Primary purpose of a copy constructor?");
        Console.WriteLine("────────────────────────────────────────────────────────");
        Console.WriteLine("  To create a new object with the same data as an existing one,");
        Console.WriteLine("  while choosing how deep that copy goes. A deep copy ensures");
        Console.WriteLine("  mutations to the copy never accidentally alter the original.\n");
    }
}
