// ============================================================
//  Part 01 – Problem 07
//  Topic   : ILogger with default Log() + ConsoleLogger override
//  Q: How do default interface implementations affect backward compatibility?
// ============================================================

namespace P07_ILogger;

public enum LogLevel { Info, Warning, Error }

// ── ILogger with default implementation ──────────────────────
public interface ILogger
{
    // Default implementation — any class gets this for free
    void Log(string message, LogLevel level = LogLevel.Info)
    {
        string timestamp = DateTime.Now.ToString("HH:mm:ss");
        string prefix    = level switch
        {
            LogLevel.Warning => "[WARN ]",
            LogLevel.Error   => "[ERROR]",
            _                => "[INFO ]"
        };
        Console.WriteLine($"  {prefix} {timestamp}  {message}");
    }

    // Additional method every logger must implement
    void Flush();
}

// ── ConsoleLogger — overrides the default Log() ──────────────
public class ConsoleLogger : ILogger
{
    private readonly ConsoleColor _color;

    public ConsoleLogger(ConsoleColor color = ConsoleColor.Cyan) { _color = color; }

    // Custom override — coloured output
    public void Log(string message, LogLevel level = LogLevel.Info)
    {
        var prev = Console.ForegroundColor;
        Console.ForegroundColor = level switch
        {
            LogLevel.Error   => ConsoleColor.Red,
            LogLevel.Warning => ConsoleColor.Yellow,
            _                => _color
        };
        Console.WriteLine($"  [Console][{level,-7}] {message}");
        Console.ForegroundColor = prev;
    }

    public void Flush()
        => Console.WriteLine("  [Console] Buffer flushed.\n");
}

// ── FileLogger — uses the DEFAULT Log() (no override) ────────
public class FileLogger : ILogger
{
    private readonly string _path;
    private readonly List<string> _buffer = new();

    public FileLogger(string path) { _path = path; }

    // Uses ILogger's default Log() body — no code written here
    // But adds entries to buffer as well
    public void Log(string message, LogLevel level = LogLevel.Info)
    {
        // call default via explicit cast
        ((ILogger)this).Log(message, level);
        _buffer.Add($"[{level}] {message}");
    }

    public void Flush()
    {
        Console.WriteLine($"  [FileLogger] Would write {_buffer.Count} line(s) to '{_path}'.");
        _buffer.Clear();
    }
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P07  |  ILogger Default Implementation      ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        ILogger console = new ConsoleLogger();
        ILogger file    = new FileLogger("app.log");

        Console.WriteLine("\n  — ConsoleLogger (custom override) —");
        console.Log("Application started");
        console.Log("Disk space low", LogLevel.Warning);
        console.Log("Database connection failed", LogLevel.Error);
        console.Flush();

        Console.WriteLine("  — FileLogger (uses default implementation) —");
        file.Log("Service initialised");
        file.Log("Config file missing", LogLevel.Warning);
        file.Flush();

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Q: How do default interface methods affect backward compatibility?");
        Console.WriteLine("────────────────────────────────────────────────────────");
        Console.WriteLine("  Without defaults: adding Log() to ILogger forces ALL existing");
        Console.WriteLine("  classes to implement it or they break at compile time.");
        Console.WriteLine("  With defaults: existing classes get the new method for free.");
        Console.WriteLine("  They still compile and work. They can override it when ready.");
        Console.WriteLine("  This is essential for library authors evolving public interfaces.\n");
    }
}
