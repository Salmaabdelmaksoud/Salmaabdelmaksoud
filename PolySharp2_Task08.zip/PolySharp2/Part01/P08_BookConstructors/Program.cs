// ============================================================
//  Part 01 – Problem 08
//  Topic   : Constructor Overloading  →  Book class
//  Q: How does constructor overloading improve class usability?
// ============================================================

namespace P08_BookConstructors;

public class Book
{
    public string Title    { get; set; }
    public string Author   { get; set; }
    public int    Year     { get; set; }
    public double Price    { get; set; }

    // 1. Default constructor
    public Book()
    {
        Title  = "Untitled";
        Author = "Unknown";
        Year   = DateTime.Now.Year;
        Price  = 0.0;
    }

    // 2. Title only
    public Book(string title) : this()
    {
        Title = title;
    }

    // 3. Title + Author
    public Book(string title, string author) : this(title)
    {
        Author = author;
    }

    // 4. All fields
    public Book(string title, string author, int year, double price)
        : this(title, author)
    {
        Year  = year;
        Price = price;
    }

    public override string ToString()
        => $"  \"{Title,-30}\"  by {Author,-20}  ({Year})  {Price:C}";
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P08  |  Book Constructor Overloading        ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        Book b1 = new Book();
        Book b2 = new Book("Clean Code");
        Book b3 = new Book("The Pragmatic Programmer", "Hunt & Thomas");
        Book b4 = new Book("Design Patterns", "Gang of Four", 1994, 49.99);

        Console.WriteLine("\n  Constructor Used          Result");
        Console.WriteLine("  " + new string('-', 70));
        Console.WriteLine($"  Default              {b1}");
        Console.WriteLine($"  Title only           {b2}");
        Console.WriteLine($"  Title + Author       {b3}");
        Console.WriteLine($"  All params           {b4}");

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Q: How does constructor overloading improve usability?");
        Console.WriteLine("────────────────────────────────────────────────────────");
        Console.WriteLine("  Callers only provide what they actually know at creation time.");
        Console.WriteLine("  No need to pass dummy nulls or defaults — each overload");
        Console.WriteLine("  chains to the next (using this()) so defaults are consistent");
        Console.WriteLine("  and written in exactly one place.\n");
    }
}
