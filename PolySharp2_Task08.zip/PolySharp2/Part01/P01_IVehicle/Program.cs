// ============================================================
//  Part 01 – Problem 01
//  Topic   : Interface IVehicle  →  Car and Bike
//  Q: Why code against an interface rather than a concrete class?
// ============================================================

namespace P01_IVehicle;

// ── Interface ────────────────────────────────────────────────
public interface IVehicle
{
    string Brand { get; }
    void StartEngine();
    void StopEngine();
}

// ── Car ──────────────────────────────────────────────────────
public class Car : IVehicle
{
    public string Brand { get; }
    private bool _running;

    public Car(string brand) { Brand = brand; }

    public void StartEngine()
    {
        _running = true;
        Console.WriteLine($"  [{Brand} Car]  Engine started  — Vroom!");
    }

    public void StopEngine()
    {
        _running = false;
        Console.WriteLine($"  [{Brand} Car]  Engine stopped  — Click.");
    }
}

// ── Bike ─────────────────────────────────────────────────────
public class Bike : IVehicle
{
    public string Brand { get; }

    public Bike(string brand) { Brand = brand; }

    public void StartEngine()
        => Console.WriteLine($"  [{Brand} Bike] Engine started  — Rrrr!");

    public void StopEngine()
        => Console.WriteLine($"  [{Brand} Bike] Engine stopped  — Shhhh.");
}

// ── Helper that works against the interface, not a class ─────
public static class VehicleHelper
{
    // Accepts ANY IVehicle — Car, Bike, or any future type
    public static void DriveAndStop(IVehicle vehicle)
    {
        Console.WriteLine($"\n  >>> Driving: {vehicle.Brand}");
        vehicle.StartEngine();
        Console.WriteLine($"      ... travelling ...");
        vehicle.StopEngine();
    }
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P01  |  IVehicle Interface                  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        // Code against IVehicle — not against Car or Bike directly
        IVehicle car  = new Car("Toyota");
        IVehicle bike = new Bike("Harley");

        VehicleHelper.DriveAndStop(car);
        VehicleHelper.DriveAndStop(bike);

        Console.WriteLine("\n  Polymorphic list:");
        List<IVehicle> fleet = new() { new Car("BMW"), new Bike("Honda"), new Car("Tesla") };
        foreach (var v in fleet)
            VehicleHelper.DriveAndStop(v);

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Q: Why code against an interface rather than a class?");
        Console.WriteLine("────────────────────────────────────────────────────────");
        Console.WriteLine("  Coding against IVehicle means DriveAndStop() works for");
        Console.WriteLine("  ANY vehicle type — now and in the future — without ever");
        Console.WriteLine("  changing a single line. This is the Open/Closed Principle:");
        Console.WriteLine("  open for extension, closed for modification.");
        Console.WriteLine("  It also makes unit testing easy: swap real classes with mocks.\n");
    }
}
