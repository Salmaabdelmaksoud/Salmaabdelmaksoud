// ============================================================
//  Part 01 – Problem 03
//  Topic   : IComparable<T>  →  Sort Product array by Price
//  Q: How does IComparable improve flexibility in sorting?
// ============================================================

namespace P03_IComparable;

// ── Product ──────────────────────────────────────────────────
public class Product : IComparable<Product>
{
    public int    Id    { get; }
    public string Name  { get; }
    public double Price { get; }

    public Product(int id, string name, double price)
    {
        Id    = id;
        Name  = name;
        Price = price;
    }

    // Array.Sort() and List.Sort() call this automatically
    public int CompareTo(Product? other)
    {
        if (other is null) return 1;
        return Price.CompareTo(other.Price);   // ascending by Price
    }

    public override string ToString()
        => $"  Id={Id,-3} | {Name,-18} | Price = {Price,8:C}";
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P03  |  IComparable Product Sorting         ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        Product[] products =
        {
            new Product(1, "Laptop",        1299.99),
            new Product(2, "Mouse",           29.99),
            new Product(3, "Keyboard",        79.99),
            new Product(4, "Monitor",        499.00),
            new Product(5, "USB Hub",         19.99),
            new Product(6, "Webcam",          89.99),
        };

        Console.WriteLine("\n  Before sorting:");
        foreach (var p in products) Console.WriteLine(p);

        Array.Sort(products);   // uses CompareTo() — no extra lambda needed

        Console.WriteLine("\n  After Array.Sort() — sorted by Price (ascending):");
        foreach (var p in products) Console.WriteLine(p);

        // Reverse sort — using IComparer approach for comparison
        Array.Sort(products, (a, b) => b.Price.CompareTo(a.Price));
        Console.WriteLine("\n  Sorted by Price (descending) using lambda Comparer:");
        foreach (var p in products) Console.WriteLine(p);

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Q: How does IComparable improve flexibility in sorting?");
        Console.WriteLine("────────────────────────────────────────────────────────");
        Console.WriteLine("  IComparable bakes a natural default ordering into the class.");
        Console.WriteLine("  Array.Sort(), List.Sort(), SortedSet, and LINQ OrderBy all");
        Console.WriteLine("  use it automatically — no extra Comparer code required.");
        Console.WriteLine("  For secondary orderings you add IComparer<T> implementations.\n");
    }
}
