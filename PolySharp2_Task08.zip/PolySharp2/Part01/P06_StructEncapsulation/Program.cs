// ============================================================
//  Part 01 – Problem 06
//  Topic   : Struct Encapsulation + Abstraction guideline
//  Q1: Key difference between encapsulation in structs vs classes?
//  Q2: What is abstraction as a guideline? Its relation with encapsulation?
// ============================================================

namespace P06_StructEncapsulation;

// ── Account struct with full encapsulation ───────────────────
public struct Account
{
    // Private backing fields — hidden from outside
    private int    _accountId;
    private string _accountHolder;
    private double _balance;

    // Public properties — controlled access point
    public int    AccountId      => _accountId;
    public string AccountHolder  => _accountHolder;
    public double Balance        => _balance;

    // Constructor — only way to set the private fields
    public Account(int id, string holder, double initialBalance)
    {
        if (initialBalance < 0)
            throw new ArgumentException("Initial balance cannot be negative.");

        _accountId     = id;
        _accountHolder = holder;
        _balance       = initialBalance;
    }

    // Controlled mutations through methods
    public void Deposit(double amount)
    {
        if (amount <= 0) throw new ArgumentException("Deposit must be positive.");
        _balance += amount;
        Console.WriteLine($"  Deposited {amount:C}  —  New balance: {_balance:C}");
    }

    public void Withdraw(double amount)
    {
        if (amount <= 0) throw new ArgumentException("Amount must be positive.");
        if (amount > _balance) throw new InvalidOperationException("Insufficient funds.");
        _balance -= amount;
        Console.WriteLine($"  Withdrew  {amount:C}  —  New balance: {_balance:C}");
    }

    public override string ToString()
        => $"  Account#{_accountId}  |  Holder: {_accountHolder,-15}  |  Balance: {_balance,10:C}";
}

// ── Program ──────────────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P06  |  Struct Encapsulation                ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");

        Account acc = new Account(1001, "Ahmed Hassan", 5_000.00);
        Console.WriteLine("\n  Created: " + acc);

        acc.Deposit(1_500.00);
        acc.Withdraw(300.00);
        Console.WriteLine("  Final  : " + acc);

        // Demonstrate struct is a VALUE type — copy on assignment
        Account copy = acc;
        copy.Deposit(9_999.00);
        Console.WriteLine("\n  After mutating the copy:");
        Console.WriteLine("  Original: " + acc);    // unchanged — value semantics
        Console.WriteLine("  Copy    : " + copy);

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Q1: Encapsulation in struct vs class?");
        Console.WriteLine("────────────────────────────────────────────────────────");
        Console.WriteLine("  Both use private fields + public properties/methods.");
        Console.WriteLine("  Key difference: structs are VALUE types (stack, copied on assign).");
        Console.WriteLine("  Classes are REFERENCE types (heap, shared on assign).");
        Console.WriteLine("  A copy of a struct is fully independent — a copy of a class");
        Console.WriteLine("  is just another pointer to the same object.");

        Console.WriteLine("\n────────────────────────────────────────────────────────");
        Console.WriteLine("  Q2: What is abstraction and its relation to encapsulation?");
        Console.WriteLine("────────────────────────────────────────────────────────");
        Console.WriteLine("  Abstraction (guideline): expose WHAT an object does, hide HOW.");
        Console.WriteLine("  Account exposes Deposit/Withdraw — the caller doesn't know");
        Console.WriteLine("  or care how the balance is stored internally.");
        Console.WriteLine("  Encapsulation is the MECHANISM that enforces abstraction:");
        Console.WriteLine("  private fields hide the 'how'; public interface is the 'what'.");
        Console.WriteLine("  Together: abstraction decides what to hide, encapsulation enforces it.\n");
    }
}
