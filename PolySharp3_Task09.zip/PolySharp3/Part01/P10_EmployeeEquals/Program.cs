// ============================================================
//  Part01 – P10 | Employee.Equals + Generic SearchArray
//  Q1: Equals vs == for class vs struct?
//  Q2: Why override ToString()?
// ============================================================
namespace P10_EmployeeEquals;

// ── Generic Helper ────────────────────────────────────────────
public static class Helper2<T>
{
    // Returns index of first match using Equals(), or -1
    public static int SearchArray(T[] array, T target)
    {
        for (int i = 0; i < array.Length; i++)
            if (array[i]!.Equals(target))
                return i;
        return -1;
    }
}

// ── Employee ──────────────────────────────────────────────────
public class Employee
{
    public int    Id         { get; }
    public string Name       { get; }
    public string Department { get; }

    public Employee(int id, string name, string dept)
    { Id = id; Name = name; Department = dept; }

    // Equals by Id — logical equality, not reference equality
    public override bool Equals(object? obj)
        => obj is Employee e && e.Id == Id;

    public override int GetHashCode() => Id.GetHashCode();

    public override string ToString()
        => $"Employee{{ Id={Id}, Name={Name}, Dept={Department} }}";
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P10  |  Employee.Equals + SearchArray   ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Employee[] employees =
        {
            new Employee(1, "Ahmed Hassan",  "Engineering"),
            new Employee(2, "Sara Mohamed",  "Marketing"),
            new Employee(3, "Karim Ali",     "HR"),
            new Employee(4, "Layla Tarek",   "Engineering"),
            new Employee(5, "Omar Saeed",    "Finance"),
        };

        Console.WriteLine("  Employee array:");
        foreach (var e in employees) Console.WriteLine($"    {e}");

        // Search by logical equality (same Id) — different object instances
        Employee searchTarget = new Employee(3, "Anyone", "Anywhere");
        int idx = Helper2<Employee>.SearchArray(employees, searchTarget);

        Console.WriteLine($"\n  Searching for Id=3 (new object, different ref):");
        Console.WriteLine($"  Found at index: {idx}  → {(idx >= 0 ? employees[idx].ToString() : "not found")}");

        // Demonstrate reference vs value equality
        Employee ref1 = employees[0];
        Employee ref2 = employees[0];
        Employee copy = new Employee(1, "Ahmed Hassan", "Engineering");

        Console.WriteLine("\n  Reference equality (==):");
        Console.WriteLine($"  ref1 == ref2 (same ref): {ref1 == ref2}");
        Console.WriteLine($"  ref1 == copy (diff ref): {ref1 == copy}");

        Console.WriteLine("\n  Logical equality (Equals):");
        Console.WriteLine($"  ref1.Equals(ref2): {ref1.Equals(ref2)}");
        Console.WriteLine($"  ref1.Equals(copy): {ref1.Equals(copy)}  ← same Id, different object");

        Console.WriteLine("\n  Q1: Equals vs == for class vs struct?");
        Console.WriteLine("  CLASS: == compares references by default. Override Equals for value equality.");
        Console.WriteLine("  STRUCT: == is not defined by default. Equals compares field-by-field.");
        Console.WriteLine("  Always override GetHashCode when overriding Equals.\n");
        Console.WriteLine("  Q2: Why override ToString()?");
        Console.WriteLine("  Without override, Console.WriteLine(emp) prints 'Namespace.Employee'.");
        Console.WriteLine("  Overriding gives instant readable debug output everywhere — free.\n");
    }
}
