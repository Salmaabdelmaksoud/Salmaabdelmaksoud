// ============================================================
//  Part01 – P11 | Generic Max<T> method
//  Q: Can generics be constrained to specific types?
// ============================================================
namespace P11_GenericMax;

public static class Helper
{
    // Constrained to IComparable<T> — guarantees CompareTo exists
    public static T Max<T>(T a, T b) where T : IComparable<T>
        => a.CompareTo(b) >= 0 ? a : b;

    // Also a generic Min for demonstration
    public static T Min<T>(T a, T b) where T : IComparable<T>
        => a.CompareTo(b) <= 0 ? a : b;

    // Generic method without constraint (works on any type with == semantics)
    public static T[] Filter<T>(T[] array, Func<T, bool> predicate)
    {
        var result = new List<T>();
        foreach (var item in array)
            if (predicate(item)) result.Add(item);
        return result.ToArray();
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P11  |  Generic Max<T> Method           ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // Integers
        int maxInt = Helper.Max(42, 17);
        Console.WriteLine($"  Max(42,  17)           = {maxInt}");

        // Doubles
        double maxDbl = Helper.Max(3.14, 2.71);
        Console.WriteLine($"  Max(3.14, 2.71)        = {maxDbl}");

        // Strings (alphabetical)
        string maxStr = Helper.Max("Zebra", "Apple");
        Console.WriteLine($"  Max(\"Zebra\",\"Apple\")   = {maxStr}");

        string maxStr2 = Helper.Max("Ahmed", "Ziad");
        Console.WriteLine($"  Max(\"Ahmed\",\"Ziad\")    = {maxStr2}");

        // DateTime
        DateTime maxDate = Helper.Max(new DateTime(2024,1,1), new DateTime(2025,6,15));
        Console.WriteLine($"  Max(2024-01-01, 2025-06-15) = {maxDate:yyyy-MM-dd}");

        // Min too
        Console.WriteLine($"\n  Min(42, 17) = {Helper.Min(42, 17)}");

        // Filter example
        int[] numbers = { 1,5,12,3,8,20,7,15 };
        int[] big = Helper.Filter(numbers, n => n > 7);
        Console.WriteLine($"\n  Filter ints > 7: [{string.Join(", ", big)}]");

        Console.WriteLine("\n  Q: Can generics be constrained to specific types?");
        Console.WriteLine("  Yes — using 'where T : constraint':");
        Console.WriteLine("    where T : IComparable<T>  — must support ordering");
        Console.WriteLine("    where T : class           — must be a reference type");
        Console.WriteLine("    where T : struct          — must be a value type");
        Console.WriteLine("    where T : new()           — must have parameterless constructor");
        Console.WriteLine("    where T : SomeBaseClass   — must inherit from a class");
        Console.WriteLine("  Without constraints the compiler only allows object-level operations.\n");
    }
}
