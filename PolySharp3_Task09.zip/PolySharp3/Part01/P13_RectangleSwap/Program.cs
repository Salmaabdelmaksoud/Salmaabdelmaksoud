// ============================================================
//  Part01 – P13 | Non-generic Swap for Rectangle struct
//  Q: Why prefer generic swap over type-specific methods?
// ============================================================
namespace P13_RectangleSwap;

// ── Custom struct ─────────────────────────────────────────────
public struct Rectangle
{
    public double Length { get; set; }
    public double Width  { get; set; }

    public Rectangle(double length, double width)
    { Length = length; Width = width; }

    public double Area      => Length * Width;
    public double Perimeter => 2 * (Length + Width);

    public override string ToString()
        => $"Rectangle(L={Length}, W={Width})  Area={Area}  Perim={Perimeter}";
}

// ── Non-generic swap (Rectangle-specific) ────────────────────
public static class SwapHelper
{
    // Non-generic — must write a separate method for every type
    public static void Swap(ref Rectangle a, ref Rectangle b)
    {
        Rectangle temp = a;
        a = b;
        b = temp;
    }

    // Generic swap — works for any type with ref semantics
    public static void Swap<T>(ref T a, ref T b)
    {
        T temp = a;
        a = b;
        b = temp;
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P13  |  Rectangle Struct Swap           ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Rectangle r1 = new Rectangle(10, 5);
        Rectangle r2 = new Rectangle(3, 8);

        Console.WriteLine("  Before swap:");
        Console.WriteLine($"    r1 = {r1}");
        Console.WriteLine($"    r2 = {r2}");

        // Non-generic swap
        SwapHelper.Swap(ref r1, ref r2);
        Console.WriteLine("\n  After non-generic Swap(ref r1, ref r2):");
        Console.WriteLine($"    r1 = {r1}");
        Console.WriteLine($"    r2 = {r2}");

        // Generic swap — same result
        SwapHelper.Swap<Rectangle>(ref r1, ref r2);
        Console.WriteLine("\n  After generic Swap<Rectangle>(ref r1, ref r2) — back to original:");
        Console.WriteLine($"    r1 = {r1}");
        Console.WriteLine($"    r2 = {r2}");

        // Generic swap on other types
        int x = 100, y = 200;
        SwapHelper.Swap(ref x, ref y);
        Console.WriteLine($"\n  Generic Swap(int): x={x}, y={y}");

        string s1 = "Hello", s2 = "World";
        SwapHelper.Swap(ref s1, ref s2);
        Console.WriteLine($"  Generic Swap(string): s1={s1}, s2={s2}");

        Console.WriteLine("\n  Q: Why prefer generic swap?");
        Console.WriteLine("  One generic method replaces N type-specific methods.");
        Console.WriteLine("  Zero code duplication, compiler-enforced type safety.");
        Console.WriteLine("  Works for any future type without any code changes.\n");
    }
}
