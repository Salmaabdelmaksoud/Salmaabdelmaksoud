// ============================================================
//  Part01 – P03 | Person with Department property
//  Q: What is the purpose of virtual with properties?
// ============================================================
namespace P03_PersonDepartment;

public class Person
{
    public int    Id         { get; set; }
    public string Name       { get; set; }
    public int    Age        { get; set; }

    // virtual — derived classes can override how Department is represented
    public virtual string Department { get; set; } = "General";

    public Person(int id, string name, int age, string department = "General")
    {
        Id         = id;
        Name       = name;
        Age        = age;
        Department = department;
    }

    public override string ToString()
        => $"  [{Id}] {Name,-18} Age={Age,-4} Dept={Department}";
}

// Derived class overrides Department to add a prefix
public class Manager : Person
{
    public int TeamSize { get; set; }

    public Manager(int id, string name, int age, string department, int teamSize)
        : base(id, name, age, department)
    {
        TeamSize = teamSize;
    }

    // Override the virtual property — managers get a "Mgr:" prefix
    public override string Department
    {
        get => $"Mgr: {base.Department}";
        set => base.Department = value;
    }

    public override string ToString()
        => base.ToString() + $"  TeamSize={TeamSize}";
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P03  |  Person + Department Property    ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Person p1 = new Person(1, "Ahmed Hassan",  28, "Engineering");
        Person p2 = new Person(2, "Sara Mohamed",  34, "Marketing");
        Person p3 = new Manager(3, "Karim Ali",    45, "Engineering", 12);

        Console.WriteLine("  Persons:");
        Console.WriteLine(p1);
        Console.WriteLine(p2);

        Console.WriteLine("\n  Manager (overrides Department property):");
        Console.WriteLine(p3);

        // Polymorphic — base reference, derived object
        Console.WriteLine("\n  Via Person reference:");
        Person poly = new Manager(4, "Layla Tarek", 39, "Finance", 8);
        Console.WriteLine($"  Department = {poly.Department}");   // Manager's override

        Console.WriteLine("\n  Q: What is virtual for properties?");
        Console.WriteLine("  virtual on a property means derived classes can completely");
        Console.WriteLine("  replace the get/set logic. Without virtual, the base property");
        Console.WriteLine("  runs even when you access it through a derived reference.\n");
    }
}
