// ============================================================
//  Part01 – P01 | Weekdays Enum
//  Q: Why explicitly assign values to enum members?
// ============================================================
namespace P01_Weekdays;

public enum Weekdays
{
    Monday    = 1,
    Tuesday   = 2,
    Wednesday = 3,
    Thursday  = 4,
    Friday    = 5
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P01  |  Weekdays Enum                   ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Console.WriteLine($"  {"Day",-12} {"Name",-12} {"Value"}");
        Console.WriteLine("  " + new string('-', 35));

        foreach (Weekdays day in Enum.GetValues<Weekdays>())
            Console.WriteLine($"  {day,-12} {day.ToString(),-12} {(int)day}");

        // Demonstrate casting
        Console.WriteLine("\n  Casting int → Weekday:");
        Console.WriteLine($"  (Weekdays)3 = {(Weekdays)3}");
        Console.WriteLine($"  (Weekdays)5 = {(Weekdays)5}");

        // Day-name lookup
        Console.WriteLine("\n  Is Wednesday a workday?");
        Weekdays today = Weekdays.Wednesday;
        bool isWorkday = today >= Weekdays.Monday && today <= Weekdays.Friday;
        Console.WriteLine($"  {today} → {(isWorkday ? "Yes!" : "No")}");

        Console.WriteLine("\n  Q: Why explicitly assign values?");
        Console.WriteLine("  Because the default starts at 0. If Monday should mean '1'");
        Console.WriteLine("  (matching real-world day numbering, or a DB column),");
        Console.WriteLine("  you must set it. It also protects against accidental shifts");
        Console.WriteLine("  when someone inserts a new member in the middle.\n");
    }
}
