// ============================================================
//  Part01 – P06 | ComplexNumber — Operator Overloading (* added)
//  Q: Can you overload ALL operators in C#?
// ============================================================
namespace P06_ComplexNumber;

public class ComplexNumber
{
    public double Real      { get; }
    public double Imaginary { get; }

    public ComplexNumber(double real, double imaginary)
    { Real = real; Imaginary = imaginary; }

    // Addition: (a+bi) + (c+di) = (a+c) + (b+d)i
    public static ComplexNumber operator +(ComplexNumber a, ComplexNumber b)
        => new ComplexNumber(a.Real + b.Real, a.Imaginary + b.Imaginary);

    // Subtraction
    public static ComplexNumber operator -(ComplexNumber a, ComplexNumber b)
        => new ComplexNumber(a.Real - b.Real, a.Imaginary - b.Imaginary);

    // Multiplication: (a+bi)(c+di) = (ac-bd) + (ad+bc)i
    public static ComplexNumber operator *(ComplexNumber a, ComplexNumber b)
        => new ComplexNumber(
            a.Real * b.Real - a.Imaginary * b.Imaginary,
            a.Real * b.Imaginary + a.Imaginary * b.Real);

    // Equality
    public static bool operator ==(ComplexNumber a, ComplexNumber b)
        => a.Real == b.Real && a.Imaginary == b.Imaginary;

    public static bool operator !=(ComplexNumber a, ComplexNumber b)
        => !(a == b);

    public override bool Equals(object? obj)
        => obj is ComplexNumber c && this == c;

    public override int GetHashCode()
        => HashCode.Combine(Real, Imaginary);

    public double Magnitude
        => Math.Sqrt(Real * Real + Imaginary * Imaginary);

    public override string ToString()
    {
        if (Imaginary >= 0)
            return $"({Real} + {Imaginary}i)";
        return $"({Real} - {Math.Abs(Imaginary)}i)";
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P06  |  ComplexNumber Operator Overload ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        ComplexNumber c1 = new ComplexNumber(3,  2);   // 3 + 2i
        ComplexNumber c2 = new ComplexNumber(1, -4);   // 1 - 4i

        Console.WriteLine($"  c1 = {c1}   |Magnitude| = {c1.Magnitude:F4}");
        Console.WriteLine($"  c2 = {c2}   |Magnitude| = {c2.Magnitude:F4}\n");

        Console.WriteLine($"  c1 + c2 = {c1 + c2}");
        Console.WriteLine($"  c1 - c2 = {c1 - c2}");
        Console.WriteLine($"  c1 * c2 = {c1 * c2}");
        Console.WriteLine($"  c1 == c2: {c1 == c2}");

        ComplexNumber c3 = new ComplexNumber(3, 2);
        Console.WriteLine($"  c1 == c3: {c1 == c3}  (same values)");

        Console.WriteLine("\n  Q: Can you overload ALL operators in C#?");
        Console.WriteLine("  No. Overloadable: +,-,*,/,%,&,|,^,~,<<,>>,==,!=,<,>,<=,>=");
        Console.WriteLine("  NOT overloadable: =, &&, ||, ?:, ??, ->, new, is, as, sizeof");
        Console.WriteLine("  Reason: some operators have language-level semantics that");
        Console.WriteLine("  must remain consistent (assignment, null-coalescing, etc.).\n");
    }
}
