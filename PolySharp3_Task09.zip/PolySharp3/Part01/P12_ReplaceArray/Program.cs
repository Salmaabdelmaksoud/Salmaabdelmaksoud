// ============================================================
//  Part01 – P12 | Helper2<T>.ReplaceArray
//  Q: Key differences between generic methods and generic classes?
// ============================================================
namespace P12_ReplaceArray;

// ── Generic CLASS — T is fixed for the whole class ────────────
public class Helper2<T>
{
    // ReplaceArray — replaces all occurrences of 'oldVal' with 'newVal'
    public T[] ReplaceArray(T[] array, T oldVal, T newVal)
    {
        T[] result = new T[array.Length];
        for (int i = 0; i < array.Length; i++)
            result[i] = EqualityComparer<T>.Default.Equals(array[i], oldVal) ? newVal : array[i];
        return result;
    }

    // SearchArray — returns index or -1
    public int SearchArray(T[] array, T target)
    {
        for (int i = 0; i < array.Length; i++)
            if (EqualityComparer<T>.Default.Equals(array[i], target))
                return i;
        return -1;
    }

    // PrintArray helper
    public void PrintArray(T[] array, string label = "")
    {
        if (!string.IsNullOrEmpty(label))
            Console.Write($"  {label}: ");
        Console.WriteLine("[" + string.Join(", ", array) + "]");
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P12  |  Helper2<T>.ReplaceArray         ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // Integer array
        var intHelper = new Helper2<int>();
        int[] nums    = { 1, 2, 3, 2, 4, 2, 5 };

        intHelper.PrintArray(nums, "Original ints");
        int[] replaced = intHelper.ReplaceArray(nums, 2, 99);
        intHelper.PrintArray(replaced, "Replace 2→99");

        Console.WriteLine();

        // String array
        var strHelper = new Helper2<string>();
        string[] words = { "hello", "world", "hello", "c#", "hello" };

        strHelper.PrintArray(words, "Original strings");
        string[] replacedStr = strHelper.ReplaceArray(words, "hello", "HI");
        strHelper.PrintArray(replacedStr, "Replace hello→HI");

        // Search demo
        Console.WriteLine($"\n  SearchArray for 99 in replaced ints: index={intHelper.SearchArray(replaced, 99)}");
        Console.WriteLine($"  SearchArray for 'c#' in strings:     index={strHelper.SearchArray(words, "c#")}");

        Console.WriteLine("\n  Q: Generic method vs generic class?");
        Console.WriteLine("  Generic CLASS: T is set at instantiation time.");
        Console.WriteLine("    Helper2<int> locks T=int for all methods on that instance.");
        Console.WriteLine("  Generic METHOD: T is inferred at each call site independently.");
        Console.WriteLine("    Helper.Max(1,2) → T=int;  Helper.Max(\"a\",\"b\") → T=string.");
        Console.WriteLine("  Use generic class when multiple methods share the same T.");
        Console.WriteLine("  Use generic method for a single utility operation.\n");
    }
}
