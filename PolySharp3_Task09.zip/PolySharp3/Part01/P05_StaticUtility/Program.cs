// ============================================================
//  Part01 – P05 | Static Utility — Rectangle Perimeter
//  Q: Key difference between static and object members?
// ============================================================
namespace P05_StaticUtility;

public static class Utility
{
    // Static method — called on the CLASS, no instance needed
    public static double RectanglePerimeter(double length, double width)
        => 2 * (length + width);

    public static double RectangleArea(double length, double width)
        => length * width;

    public static double CirclePerimeter(double radius)
        => 2 * Math.PI * radius;

    public static double CircleArea(double radius)
        => Math.PI * radius * radius;

    public static string Separator(char ch = '-', int len = 50)
        => new string(ch, len);
}

// For comparison — instance-based version
public class ShapeCalculator
{
    public double Length { get; set; }
    public double Width  { get; set; }

    public ShapeCalculator(double length, double width)
    { Length = length; Width = width; }

    // Instance method — needs 'this'
    public double GetPerimeter() => 2 * (Length + Width);
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P05  |  Static Utility Class            ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // No 'new' needed — call directly on the class
        Console.WriteLine("  Rectangle (5 x 3):");
        Console.WriteLine($"    Perimeter = {Utility.RectanglePerimeter(5, 3)}");
        Console.WriteLine($"    Area      = {Utility.RectangleArea(5, 3)}");

        Console.WriteLine("\n  Rectangle (10 x 4):");
        Console.WriteLine($"    Perimeter = {Utility.RectanglePerimeter(10, 4)}");
        Console.WriteLine($"    Area      = {Utility.RectangleArea(10, 4)}");

        Console.WriteLine("\n  Circle (radius = 7):");
        Console.WriteLine($"    Perimeter = {Utility.CirclePerimeter(7):F4}");
        Console.WriteLine($"    Area      = {Utility.CircleArea(7):F4}");

        Console.WriteLine(Utility.Separator());

        // Contrast: instance-based
        ShapeCalculator calc = new ShapeCalculator(5, 3);
        Console.WriteLine($"\n  Instance-based perimeter = {calc.GetPerimeter()}");

        Console.WriteLine("\n  Q: Static vs instance members?");
        Console.WriteLine("  Static  → belongs to the TYPE itself; shared; no 'this'.");
        Console.WriteLine("  Instance→ belongs to each OBJECT; has its own state via 'this'.");
        Console.WriteLine("  Use static for pure functions, helpers, factories, constants.\n");
    }
}
