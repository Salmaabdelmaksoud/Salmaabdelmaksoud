// ============================================================
//  Part01 – P14 | Department class + Employee search by dept
//  Q: How does overriding Equals improve search accuracy?
// ============================================================
namespace P14_DepartmentSearch;

// ── Generic SearchArray ───────────────────────────────────────
public static class Helper2<T>
{
    public static int SearchArray(T[] array, T target)
    {
        for (int i = 0; i < array.Length; i++)
            if (array[i]!.Equals(target))
                return i;
        return -1;
    }

    public static T[] FindAll(T[] array, T target)
    {
        var results = new List<T>();
        foreach (var item in array)
            if (item!.Equals(target))
                results.Add(item);
        return results.ToArray();
    }
}

// ── Department ────────────────────────────────────────────────
public class Department
{
    public int    Id   { get; }
    public string Name { get; }

    public Department(int id, string name) { Id = id; Name = name; }

    // Equals by Name (case-insensitive) — improves search accuracy
    public override bool Equals(object? obj)
        => obj is Department d &&
           string.Equals(d.Name, Name, StringComparison.OrdinalIgnoreCase);

    public override int GetHashCode()
        => Name.ToLower().GetHashCode();

    public override string ToString() => $"Dept({Id}, {Name})";
}

// ── Employee ──────────────────────────────────────────────────
public class Employee
{
    public int        Id         { get; }
    public string     Name       { get; }
    public Department Department { get; }

    public Employee(int id, string name, Department dept)
    { Id = id; Name = name; Department = dept; }

    public override bool Equals(object? obj)
        => obj is Employee e && e.Id == Id;

    public override int GetHashCode() => Id.GetHashCode();

    public override string ToString()
        => $"  [{Id}] {Name,-18} → {Department}";
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P14  |  Department + Employee Search    ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        var eng  = new Department(10, "Engineering");
        var mkt  = new Department(20, "Marketing");
        var hr   = new Department(30, "HR");
        var fin  = new Department(40, "Finance");

        Employee[] employees =
        {
            new Employee(1, "Ahmed Hassan",  eng),
            new Employee(2, "Sara Mohamed",  mkt),
            new Employee(3, "Karim Ali",     hr),
            new Employee(4, "Layla Tarek",   eng),
            new Employee(5, "Omar Saeed",    fin),
            new Employee(6, "Nour Hamed",    eng),
        };

        Console.WriteLine("  All employees:");
        foreach (var e in employees) Console.WriteLine(e);

        // Search by department — new object, same name
        var searchDept = new Department(99, "engineering");  // different Id, case different
        Console.WriteLine($"\n  Searching for department '{searchDept.Name}' (Equals ignores case & Id):");
        var engEmployees = Helper2<Employee>.FindAll(
            employees,
            new Employee(0, "", searchDept) { }
        );

        // Better: search by department directly
        var allInEng = Array.FindAll(employees, e => e.Department.Equals(searchDept));
        Console.WriteLine($"  Found {allInEng.Length} Engineering employees:");
        foreach (var e in allInEng) Console.WriteLine(e);

        // Search single
        var firstEng = Array.Find(employees, e => e.Department.Equals(new Department(0, "marketing")));
        Console.WriteLine($"\n  First Marketing employee: {firstEng}");

        Console.WriteLine("\n  Q: How does overriding Equals improve search accuracy?");
        Console.WriteLine("  Without override, Equals compares object references.");
        Console.WriteLine("  'new Department(99,\"Engineering\")' would never match");
        Console.WriteLine("  any existing department even with the same name.");
        Console.WriteLine("  Overriding Equals with name-based logic makes logical");
        Console.WriteLine("  equality work correctly across different instances.\n");
    }
}
