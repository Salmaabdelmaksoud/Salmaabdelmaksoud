// ============================================================
//  Part01 – P09 | Enum.TryParse for Grades
//  Q: Advantages of TryParse over int.Parse?
// ============================================================
namespace P09_EnumTryParse;

public enum Grades { A = 5, B = 4, C = 3, D = 2, F = 1 }

class Program
{
    static void ParseAndDisplay(string input)
    {
        // Safe parsing — no exception on invalid input
        if (Enum.TryParse<Grades>(input, ignoreCase: true, out Grades result))
            Console.WriteLine($"  '{input,-10}' → Valid  : {result}  (value={(int)result})");
        else
            Console.WriteLine($"  '{input,-10}' → Invalid: not a recognised grade");
    }

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P09  |  Enum.TryParse                   ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        string[] inputs = { "A", "b", "C", "Z", "5", "abc", "F", "99", "D", "" };

        Console.WriteLine("  Parsing inputs with Enum.TryParse:");
        Console.WriteLine("  " + new string('-', 48));
        foreach (var input in inputs)
            ParseAndDisplay(input);

        // Show what direct parsing would look like (risky)
        Console.WriteLine("\n  Direct (int)Enum cast — dangerous if input is unknown:");
        try
        {
            string risky = "999";
            Grades g = (Grades)int.Parse(risky);
            Console.WriteLine($"  Cast result: {g}  (may be undefined!)");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"  Exception: {ex.Message}");
        }

        Console.WriteLine("\n  Q: TryParse vs int.Parse advantages?");
        Console.WriteLine("  TryParse never throws — returns false on bad input.");
        Console.WriteLine("  Handles both name ('A') and numeric ('5') inputs.");
        Console.WriteLine("  Has ignoreCase option — 'a' and 'A' both work.");
        Console.WriteLine("  Safe for user input, config files, API payloads.\n");
    }
}
