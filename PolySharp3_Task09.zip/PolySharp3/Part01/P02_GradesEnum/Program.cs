// ============================================================
//  Part01 – P02 | Grades Enum with short underlying type
//  Q: What happens if value exceeds the underlying type's range?
// ============================================================
namespace P02_GradesEnum;

// short range: -32,768 to 32,767
public enum Grades : short
{
    A  = 5,
    B  = 4,
    C  = 3,
    D  = 2,
    F  = -1      // Failed — negative value intentionally
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P02  |  Grades Enum (short)             ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Console.WriteLine($"  {"Grade",-8} {"Name",-6} {"Value (short)"}");
        Console.WriteLine("  " + new string('-', 30));

        foreach (Grades g in Enum.GetValues<Grades>())
            Console.WriteLine($"  {g,-8} {g.ToString(),-6} {(short)g,6}");

        Console.WriteLine("\n  Underlying type: " + Enum.GetUnderlyingType(typeof(Grades)).Name);
        Console.WriteLine("  short range: -32,768  to  32,767");

        Console.WriteLine("\n  Is student passing?");
        Grades result = Grades.C;
        Console.WriteLine($"  Grade {result} → {((short)result > 0 ? "Pass" : "Fail")}");

        result = Grades.F;
        Console.WriteLine($"  Grade {result} → {((short)result > 0 ? "Pass" : "Fail")}");

        Console.WriteLine("\n  Q: What if you exceed the underlying type's range?");
        Console.WriteLine("  It is a compile-time error — the compiler rejects it.");
        Console.WriteLine("  e.g.  F = -40000  on a short would not compile.");
        Console.WriteLine("  Always pick the smallest type that safely covers your range.\n");
    }
}
