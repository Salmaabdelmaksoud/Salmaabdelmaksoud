// ============================================================
//  Part01 – P07 | Gender Enum with byte underlying type
//  Q: When should you change the underlying type of an enum?
// ============================================================
namespace P07_GenderEnum;

// Default (int) — 4 bytes each
public enum GenderDefault
{
    Male, Female, NonBinary, PreferNotToSay
}

// byte — 1 byte each (range 0-255)
public enum Gender : byte
{
    Male            = 1,
    Female          = 2,
    NonBinary       = 3,
    PreferNotToSay  = 0
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P07  |  Gender Enum (byte)              ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Console.WriteLine("  Gender enum values (byte underlying type):");
        Console.WriteLine($"  {"Name",-20} {"Byte Value"}");
        Console.WriteLine("  " + new string('-', 32));
        foreach (Gender g in Enum.GetValues<Gender>())
            Console.WriteLine($"  {g,-20} {(byte)g}");

        Console.WriteLine($"\n  Underlying type: {Enum.GetUnderlyingType(typeof(Gender)).Name}");
        Console.WriteLine($"  byte  range: 0 – 255");

        // Memory comparison
        int countDefault = Enum.GetValues<GenderDefault>().Length;
        int countByte    = Enum.GetValues<Gender>().Length;

        Console.WriteLine($"\n  Memory per member:");
        Console.WriteLine($"  GenderDefault (int)  : {sizeof(int)} bytes × {countDefault} members = {sizeof(int) * countDefault} bytes");
        Console.WriteLine($"  Gender        (byte) : {sizeof(byte)} byte  × {countByte} members = {sizeof(byte) * countByte} bytes");

        int savedPerMillion = (sizeof(int) - sizeof(byte)) * 1_000_000;
        Console.WriteLine($"\n  In an array of 1,000,000 Gender values:");
        Console.WriteLine($"  Default (int) : {sizeof(int) * 1_000_000:N0} bytes");
        Console.WriteLine($"  byte version  : {sizeof(byte) * 1_000_000:N0} bytes");
        Console.WriteLine($"  Saving        : {savedPerMillion:N0} bytes ({savedPerMillion / 1024 / 1024} MB)");

        Console.WriteLine("\n  Q: When should you change the underlying type?");
        Console.WriteLine("  When storing millions of enum values (databases, files, arrays)");
        Console.WriteLine("  and the member count fits in a smaller type (byte: 0-255).");
        Console.WriteLine("  Also when interoperating with protocols that expect specific sizes.\n");
    }
}
