// ============================================================
//  Part01 – P08 | Static Temperature Converter
//  Q: Why can't a static class have instance constructors?
// ============================================================
namespace P08_TempConverter;

public static class Utility
{
    // Celsius → Fahrenheit
    public static double CelsiusToFahrenheit(double celsius)
        => celsius * 9.0 / 5.0 + 32;

    // Fahrenheit → Celsius
    public static double FahrenheitToCelsius(double fahrenheit)
        => (fahrenheit - 32) * 5.0 / 9.0;

    // Celsius → Kelvin
    public static double CelsiusToKelvin(double celsius)
        => celsius + 273.15;

    // Kelvin → Celsius
    public static double KelvinToCelsius(double kelvin)
        => kelvin - 273.15;

    // Pretty print a conversion row
    public static void PrintConversion(double celsius)
    {
        double f = CelsiusToFahrenheit(celsius);
        double k = CelsiusToKelvin(celsius);
        Console.WriteLine($"  {celsius,8:F1} °C   →   {f,8:F1} °F   →   {k,8:2} K");
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P08  |  Temperature Converter (static)  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Console.WriteLine($"  {"Celsius",8}      {"Fahrenheit",10}      {"Kelvin",8}");
        Console.WriteLine("  " + new string('-', 48));

        double[] samples = { -273.15, -40, 0, 20, 37, 100, 200 };
        foreach (double c in samples)
            Utility.PrintConversion(c);

        Console.WriteLine("\n  Spot checks:");
        Console.WriteLine($"  100°C in °F  = {Utility.CelsiusToFahrenheit(100)}");     // 212
        Console.WriteLine($"  32°F  in °C  = {Utility.FahrenheitToCelsius(32)}");      // 0
        Console.WriteLine($"  0°C   in K   = {Utility.CelsiusToKelvin(0)}");           // 273.15

        Console.WriteLine("\n  Q: Why can't a static class have instance constructors?");
        Console.WriteLine("  A static class can never be instantiated — 'new Utility()'");
        Console.WriteLine("  is a compile-time error. An instance constructor would be");
        Console.WriteLine("  unreachable dead code. The CLR allocates no object memory.");
        Console.WriteLine("  Static classes only have a private static constructor for");
        Console.WriteLine("  one-time initialisation (e.g. loading config).\n");
    }
}
