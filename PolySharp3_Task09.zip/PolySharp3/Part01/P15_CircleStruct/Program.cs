// ============================================================
//  Part01 – P15 | Circle struct vs Circle class — == and Equals
//  Q: Why is == not implemented by default for structs?
// ============================================================
namespace P15_CircleStruct;

// ── Circle STRUCT ─────────────────────────────────────────────
public struct CircleStruct
{
    public double Radius { get; }
    public string Color  { get; }

    public CircleStruct(double radius, string color)
    { Radius = radius; Color = color; }

    // Struct Equals uses field-by-field comparison by default
    // but we can also explicitly override:
    public override bool Equals(object? obj)
        => obj is CircleStruct c && c.Radius == Radius && c.Color == Color;

    public override int GetHashCode()
        => HashCode.Combine(Radius, Color);

    // Must explicitly define == for structs
    public static bool operator ==(CircleStruct a, CircleStruct b)
        => a.Equals(b);

    public static bool operator !=(CircleStruct a, CircleStruct b)
        => !a.Equals(b);

    public override string ToString() => $"CircleStruct(r={Radius}, color={Color})";
}

// ── Circle CLASS ──────────────────────────────────────────────
public class CircleClass
{
    public double Radius { get; }
    public string Color  { get; }

    public CircleClass(double radius, string color)
    { Radius = radius; Color = color; }

    // Without overriding Equals, classes compare REFERENCES
    public override bool Equals(object? obj)
        => obj is CircleClass c && c.Radius == Radius && c.Color == Color;

    public override int GetHashCode()
        => HashCode.Combine(Radius, Color);

    // == still compares references unless we also overload it
    public override string ToString() => $"CircleClass(r={Radius}, color={Color})";
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P15  |  CircleStruct vs CircleClass     ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // ── Struct ────────────────────────────────────────────
        CircleStruct s1 = new CircleStruct(5, "Red");
        CircleStruct s2 = new CircleStruct(5, "Red");
        CircleStruct s3 = new CircleStruct(3, "Blue");

        Console.WriteLine("  ── STRUCT ──");
        Console.WriteLine($"  s1 = {s1}");
        Console.WriteLine($"  s2 = {s2}  (same values)");
        Console.WriteLine($"  s3 = {s3}  (different values)");
        Console.WriteLine($"\n  s1 == s2 : {s1 == s2}   (value comparison, both same fields)");
        Console.WriteLine($"  s1 == s3 : {s1 == s3}  (different radius+color)");
        Console.WriteLine($"  s1.Equals(s2): {s1.Equals(s2)}");

        // Struct is copied on assignment — fully independent
        CircleStruct copy = s1;
        Console.WriteLine($"\n  After 'CircleStruct copy = s1' — value copy, fully independent");
        Console.WriteLine($"  s1 == copy: {s1 == copy}");

        // ── Class ─────────────────────────────────────────────
        CircleClass c1 = new CircleClass(5, "Red");
        CircleClass c2 = new CircleClass(5, "Red");
        CircleClass c3 = c1;   // same reference

        Console.WriteLine("\n  ── CLASS ──");
        Console.WriteLine($"  c1 = {c1}");
        Console.WriteLine($"  c2 = {c2}  (same values, different object)");
        Console.WriteLine($"  c3 = c1 (same reference)");
        Console.WriteLine($"\n  c1 == c2 : {c1 == c2}   (reference comparison — different objects!)");
        Console.WriteLine($"  c1 == c3 : {c1 == c3}   (same reference)");
        Console.WriteLine($"  c1.Equals(c2): {c1.Equals(c2)}  (overridden — value-based)");
        Console.WriteLine($"  c1.Equals(c3): {c1.Equals(c3)}");

        Console.WriteLine("\n  Q: Why is == not implemented by default for structs?");
        Console.WriteLine("  Structs can contain any combination of fields — the compiler");
        Console.WriteLine("  cannot know the correct equality semantics for every case.");
        Console.WriteLine("  A struct with a float field might need approximate equality.");
        Console.WriteLine("  By requiring explicit operator == the designer makes the intent");
        Console.WriteLine("  obvious and avoids silent bugs from incorrect default behaviour.\n");
    }
}
