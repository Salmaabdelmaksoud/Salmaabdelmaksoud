// ============================================================
//  Part01 – P04 | Sealed Property — DisplaySalary demo
//  Q: Why can't you override a sealed property or method?
// ============================================================
namespace P04_SealedProperty;

public class Person
{
    public string Name { get; set; }

    public Person(string name) { Name = name; }

    // Virtual base property — can be overridden once
    public virtual double Salary { get; set; }
}

public class Employee : Person
{
    public Employee(string name, double salary) : base(name)
    {
        Salary = salary;
    }

    // sealed override — locks the property; no further override allowed
    public sealed override double Salary { get; set; }
}

// Child of Employee — Salary is sealed, cannot be overridden here
public class Child : Employee
{
    public string Role { get; set; }

    public Child(string name, double salary, string role)
        : base(name, salary)
    {
        Role = role;
    }

    // Use the sealed Salary property — just can't override it
    public void DisplaySalary()
    {
        Console.WriteLine($"  Employee  : {Name}");
        Console.WriteLine($"  Role      : {Role}");
        Console.WriteLine($"  Salary    : {Salary:C}");
        Console.WriteLine($"  After tax : {Salary * 0.85:C}  (15% deduction)");
    }
}

// This would be a compile error if uncommented:
// public class GrandChild : Child
// {
//     public override double Salary { get; set; }  // ERROR — sealed!
// }

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P04  |  Sealed Property + DisplaySalary║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Child c1 = new Child("Ahmed Hassan",  12_000, "Senior Dev");
        Child c2 = new Child("Sara Mohamed",   8_500, "UI Designer");

        c1.DisplaySalary();
        Console.WriteLine();
        c2.DisplaySalary();

        Console.WriteLine("\n  Q: Why can't you override a sealed member?");
        Console.WriteLine("  'sealed override' terminates the virtual dispatch chain.");
        Console.WriteLine("  It is a deliberate design decision: the class author says");
        Console.WriteLine("  'this implementation is final — do not change it further'.");
        Console.WriteLine("  Common in security-critical or invariant-heavy scenarios.\n");
    }
}
