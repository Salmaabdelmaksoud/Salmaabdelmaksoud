// ============================================================
//  Part02 – P02 | Generic Stack<T> class
// ============================================================
namespace P02_GenericStack;

public class GenericStack<T>
{
    private readonly List<T> _data = new();

    public int  Count   => _data.Count;
    public bool IsEmpty => _data.Count == 0;

    // Push — add to top
    public void Push(T item)
    {
        _data.Add(item);
        Console.WriteLine($"  PUSH  {item}  → size={Count}");
    }

    // Pop — remove and return top item
    public T Pop()
    {
        if (IsEmpty) throw new InvalidOperationException("Stack is empty.");
        T item = _data[^1];
        _data.RemoveAt(_data.Count - 1);
        Console.WriteLine($"  POP   {item}  → size={Count}");
        return item;
    }

    // Peek — look at top without removing
    public T Peek()
    {
        if (IsEmpty) throw new InvalidOperationException("Stack is empty.");
        return _data[^1];
    }

    // Display the stack (top → bottom)
    public void Display()
    {
        Console.Write($"  Stack (top→bottom, size={Count}): [");
        for (int i = _data.Count - 1; i >= 0; i--)
        {
            Console.Write(_data[i]);
            if (i > 0) Console.Write(", ");
        }
        Console.WriteLine("]");
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – P02  |  Generic Stack<T>                ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // Integer stack
        Console.WriteLine("  ── int stack ──");
        var intStack = new GenericStack<int>();
        intStack.Push(10);
        intStack.Push(20);
        intStack.Push(30);
        intStack.Display();
        Console.WriteLine($"  Peek = {intStack.Peek()}");
        intStack.Pop();
        intStack.Pop();
        intStack.Display();

        Console.WriteLine("\n  ── string stack ──");
        var strStack = new GenericStack<string>();
        strStack.Push("first");
        strStack.Push("second");
        strStack.Push("third");
        strStack.Display();
        strStack.Pop();
        strStack.Display();

        Console.WriteLine("\n  ── Undo history simulation ──");
        var history = new GenericStack<string>();
        history.Push("Typed 'Hello'");
        history.Push("Typed ' World'");
        history.Push("Deleted last word");
        history.Push("Typed ' C#'");
        history.Display();

        Console.WriteLine("\n  Undoing actions:");
        while (!history.IsEmpty)
        {
            string action = history.Pop();
            Console.WriteLine($"  Undone: {action}");
        }

        // Empty stack exception demo
        Console.WriteLine("\n  Popping from empty stack:");
        try { intStack.Pop(); }
        catch (InvalidOperationException ex) { Console.WriteLine($"  Exception: {ex.Message}"); }
        Console.WriteLine();
    }
}
