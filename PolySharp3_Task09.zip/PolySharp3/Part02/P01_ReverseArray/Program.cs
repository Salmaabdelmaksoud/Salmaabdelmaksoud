// ============================================================
//  Part02 – P01 | Generic method to reverse an array
// ============================================================
namespace P01_ReverseArray;

public static class ArrayHelper
{
    // Generic reverse — works for any type
    public static T[] Reverse<T>(T[] source)
    {
        T[] result = new T[source.Length];
        for (int i = 0; i < source.Length; i++)
            result[i] = source[source.Length - 1 - i];
        return result;
    }

    public static void Print<T>(T[] array, string label = "")
    {
        if (!string.IsNullOrEmpty(label))
            Console.Write($"  {label,-20}: ");
        Console.WriteLine("[" + string.Join(", ", array) + "]");
    }
}

// Custom object to prove it works on any type
public class Student
{
    public string Name { get; }
    public int    Age  { get; }
    public Student(string name, int age) { Name = name; Age = age; }
    public override string ToString() => $"{Name}({Age})";
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – P01  |  Generic Reverse Array           ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // Integers
        int[] nums    = { 1, 2, 3, 4, 5, 6, 7 };
        int[] revNums = ArrayHelper.Reverse(nums);
        ArrayHelper.Print(nums,    "Original ints");
        ArrayHelper.Print(revNums, "Reversed");

        Console.WriteLine();

        // Strings
        string[] words    = { "apple", "banana", "cherry", "date" };
        string[] revWords = ArrayHelper.Reverse(words);
        ArrayHelper.Print(words,    "Original strings");
        ArrayHelper.Print(revWords, "Reversed");

        Console.WriteLine();

        // Custom objects
        Student[] students =
        {
            new Student("Ahmed", 22),
            new Student("Sara",  24),
            new Student("Karim", 21),
            new Student("Layla", 23),
        };
        Student[] revStudents = ArrayHelper.Reverse(students);
        ArrayHelper.Print(students,    "Original students");
        ArrayHelper.Print(revStudents, "Reversed");

        Console.WriteLine();

        // Double-reverse — should restore original
        int[] doubleRev = ArrayHelper.Reverse(revNums);
        ArrayHelper.Print(doubleRev, "Double-reversed");
        Console.WriteLine($"  Matches original? {string.Join(",",doubleRev)==string.Join(",",nums)}\n");
    }
}
