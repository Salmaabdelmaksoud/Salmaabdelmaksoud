// ============================================================
//  Part02 – P03 | Generic SwapElements in array by index
// ============================================================
namespace P03_SwapElements;

public static class ArrayHelper
{
    // Swap two elements at given indices
    public static void SwapAt<T>(T[] array, int i, int j)
    {
        if (i < 0 || i >= array.Length || j < 0 || j >= array.Length)
            throw new IndexOutOfRangeException($"Indices {i},{j} out of range for array of size {array.Length}.");
        (array[i], array[j]) = (array[j], array[i]);
    }

    // Swap two variables by reference
    public static void Swap<T>(ref T a, ref T b)
        => (a, b) = (b, a);

    public static void Print<T>(T[] array, string label = "")
    {
        string prefix = string.IsNullOrEmpty(label) ? "" : $"  {label,-20}: ";
        Console.WriteLine(prefix + "[" + string.Join(", ", array) + "]");
    }
}

public class Product
{
    public string Name  { get; set; }
    public double Price { get; set; }
    public Product(string name, double price) { Name = name; Price = price; }
    public override string ToString() => $"{Name}(${Price})";
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – P03  |  Generic SwapElements            ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // Integer array
        int[] nums = { 10, 20, 30, 40, 50 };
        ArrayHelper.Print(nums, "Before swap(0,4)");
        ArrayHelper.SwapAt(nums, 0, 4);
        ArrayHelper.Print(nums, "After  swap(0,4)");

        Console.WriteLine();

        // String array
        string[] names = { "Alice", "Bob", "Charlie", "Diana" };
        ArrayHelper.Print(names, "Before swap(1,3)");
        ArrayHelper.SwapAt(names, 1, 3);
        ArrayHelper.Print(names, "After  swap(1,3)");

        Console.WriteLine();

        // Custom object array
        Product[] products =
        {
            new Product("Laptop", 1299),
            new Product("Mouse",    29),
            new Product("Monitor", 499),
        };
        ArrayHelper.Print(products, "Before swap(0,2)");
        ArrayHelper.SwapAt(products, 0, 2);
        ArrayHelper.Print(products, "After  swap(0,2)");

        Console.WriteLine();

        // SwapAt used inside bubble sort as demo
        int[] bubble = { 64, 25, 12, 22, 11 };
        ArrayHelper.Print(bubble, "Bubble sort input");
        for (int i = 0; i < bubble.Length - 1; i++)
            for (int j = 0; j < bubble.Length - i - 1; j++)
                if (bubble[j] > bubble[j + 1])
                    ArrayHelper.SwapAt(bubble, j, j + 1);
        ArrayHelper.Print(bubble, "Bubble sort output");

        // Index out of range demo
        Console.WriteLine("\n  Out-of-range swap:");
        try { ArrayHelper.SwapAt(nums, 0, 99); }
        catch (IndexOutOfRangeException ex) { Console.WriteLine($"  {ex.Message}"); }

        Console.WriteLine();
    }
}
