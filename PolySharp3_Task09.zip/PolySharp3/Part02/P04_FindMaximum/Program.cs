// ============================================================
//  Part02 – P04 | Generic FindMaximum — IComparable constraint
// ============================================================
namespace P04_FindMaximum;

public static class ArrayHelper
{
    // Constrained to IComparable<T> — can use CompareTo
    public static T FindMax<T>(T[] array) where T : IComparable<T>
    {
        if (array.Length == 0)
            throw new ArgumentException("Array must not be empty.");

        T max = array[0];
        for (int i = 1; i < array.Length; i++)
            if (array[i].CompareTo(max) > 0)
                max = array[i];
        return max;
    }

    public static T FindMin<T>(T[] array) where T : IComparable<T>
    {
        if (array.Length == 0)
            throw new ArgumentException("Array must not be empty.");

        T min = array[0];
        for (int i = 1; i < array.Length; i++)
            if (array[i].CompareTo(min) < 0)
                min = array[i];
        return min;
    }

    // Returns index of max element
    public static int FindMaxIndex<T>(T[] array) where T : IComparable<T>
    {
        int maxIdx = 0;
        for (int i = 1; i < array.Length; i++)
            if (array[i].CompareTo(array[maxIdx]) > 0)
                maxIdx = i;
        return maxIdx;
    }
}

// Custom comparable type
public class Employee : IComparable<Employee>
{
    public string Name   { get; }
    public double Salary { get; }

    public Employee(string name, double salary) { Name = name; Salary = salary; }

    // Compare by salary
    public int CompareTo(Employee? other)
    {
        if (other is null) return 1;
        return Salary.CompareTo(other.Salary);
    }

    public override string ToString() => $"{Name}(${Salary:N0})";
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – P04  |  Generic FindMaximum             ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // Integers
        int[] nums = { 3, 17, 8, 42, 5, 99, 14 };
        Console.WriteLine($"  Ints:   [{string.Join(", ", nums)}]");
        Console.WriteLine($"  Max = {ArrayHelper.FindMax(nums)},  Min = {ArrayHelper.FindMin(nums)}");
        Console.WriteLine($"  Max at index {ArrayHelper.FindMaxIndex(nums)}\n");

        // Doubles
        double[] doubles = { 3.14, 2.71, 1.41, 9.81, 6.67 };
        Console.WriteLine($"  Doubles: [{string.Join(", ", doubles)}]");
        Console.WriteLine($"  Max = {ArrayHelper.FindMax(doubles)},  Min = {ArrayHelper.FindMin(doubles)}\n");

        // Strings (alphabetical)
        string[] words = { "banana", "apple", "cherry", "mango", "avocado" };
        Console.WriteLine($"  Strings: [{string.Join(", ", words)}]");
        Console.WriteLine($"  Max = {ArrayHelper.FindMax(words)}  (last alphabetically)");
        Console.WriteLine($"  Min = {ArrayHelper.FindMin(words)}  (first alphabetically)\n");

        // Custom IComparable objects
        Employee[] employees =
        {
            new Employee("Ahmed",  12_000),
            new Employee("Sara",    8_500),
            new Employee("Karim", 22_000),
            new Employee("Layla", 15_000),
        };
        Console.WriteLine($"  Employees: [{string.Join(", ", employees as object[])}]");
        Console.WriteLine($"  Highest salary: {ArrayHelper.FindMax(employees)}");
        Console.WriteLine($"  Lowest  salary: {ArrayHelper.FindMin(employees)}\n");
    }
}
