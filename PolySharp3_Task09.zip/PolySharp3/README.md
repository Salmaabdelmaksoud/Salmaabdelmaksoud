# PolySharp3 🔷
## C# OOP – Task 09 | Full Assignment Solution
### Enums · Operator Overloading · Static Classes · Generics · Structs

---

## 🚀 How to Open in Visual Studio

1. Extract the ZIP anywhere
2. Double-click **`PolySharp3.sln`**
3. Right-click any project in Solution Explorer → **Set as Startup Project**
4. Press **Ctrl+F5** to run

---

## 📁 Project Map

### Part 01 – Problems

| # | Project | Topic |
|---|---------|-------|
| 01 | `P01_Weekdays` | Weekdays enum with explicit values |
| 02 | `P02_GradesEnum` | Grades enum with `short` underlying type |
| 03 | `P03_PersonDepartment` | Person + virtual Department property |
| 04 | `P04_SealedProperty` | Sealed property + DisplaySalary |
| 05 | `P05_StaticUtility` | Static Utility – rectangle perimeter |
| 06 | `P06_ComplexNumber` | ComplexNumber + `*` operator overload |
| 07 | `P07_GenderEnum` | Gender enum with `byte` + memory demo |
| 08 | `P08_TempConverter` | Static temperature converter |
| 09 | `P09_EnumTryParse` | Enum.TryParse graceful parsing |
| 10 | `P10_EmployeeEquals` | Employee.Equals + generic SearchArray |
| 11 | `P11_GenericMax` | Generic Max\<T\> with constraints |
| 12 | `P12_ReplaceArray` | Helper2\<T\>.ReplaceArray |
| 13 | `P13_RectangleSwap` | Rectangle struct + generic Swap |
| 14 | `P14_DepartmentSearch` | Department.Equals + employee search |
| 15 | `P15_CircleStruct` | CircleStruct vs CircleClass: == and Equals |

### Part 02 – Generic Challenges

| # | Project | Topic |
|---|---------|-------|
| 01 | `P01_ReverseArray` | Generic reverse array |
| 02 | `P02_GenericStack` | Generic Stack\<T\> with push/pop/peek |
| 03 | `P03_SwapElements` | Generic SwapAt by index |
| 04 | `P04_FindMaximum` | Generic FindMax with IComparable constraint |

---

## 📚 Part 02 – Theory Questions

### 1. LinkedIn Article: C# Class Types

**"Know Your Types: A Developer's Guide to C# Class Flavours"**

Not all C# classes are created equal. Understanding the differences between
concrete classes, abstract classes, static classes, sealed classes, and partial
classes is what separates junior from senior C# developers.

- **Concrete class** — the everyday workhorse. Can be instantiated, inherited, extended.
- **Abstract class** — a template with at least one abstract member. Cannot be
  instantiated directly. Forces derived classes to complete the contract. Perfect
  when you have shared state AND shared behaviour to pass down the hierarchy.
- **Static class** — no instances, ever. All members are static. Used for helpers,
  utilities, and extension methods (like our Utility class). The compiler enforces
  that nothing tries to create one with `new`.
- **Sealed class** — shuts down the inheritance chain. Useful when overriding
  would break invariants (e.g. security, identity checks). `string` in .NET is sealed.
- **Partial class** — split across multiple files. Mostly used by code generators
  (WinForms, EF Core) to separate generated code from hand-written code.
- **Record** (C# 9+) — value-oriented, immutable by default, with built-in `Equals`,
  `GetHashCode`, and `ToString`. Ideal for DTOs and domain value objects.

Choosing the right class type is the foundation of a clean, maintainable design.

---

### 2. Generalization Concept Using Generics

Generalization in OOP means designing code around what objects have in common
rather than what makes them specific. Generics take this one step further —
they let you write code that is *parameterized over a type* rather than hard-coded
to one.

```csharp
// Without generics — you write three methods
int    MaxInt(int a, int b)       => a > b ? a : b;
double MaxDouble(double a, double b) => a > b ? a : b;
string MaxString(string a, string b) => string.Compare(a, b) > 0 ? a : b;

// With generics — one method covers all of them
T Max<T>(T a, T b) where T : IComparable<T>
    => a.CompareTo(b) >= 0 ? a : b;
```

The `where T : IComparable<T>` constraint is the generalization contract:
"I don't care what T is, as long as it supports ordering." This is the
essence of programming against abstraction — the method works with integers,
strings, dates, custom classes, anything that satisfies the contract.

Real-world applications: collection classes (`List<T>`, `Dictionary<TKey,TValue>`),
repository patterns (`IRepository<T>`), response wrappers (`ApiResponse<T>`).

---

### 3. Hierarchy Design in Real Business

A well-designed class hierarchy models the real business domain, not the technical
implementation. Here's a realistic HR example:

```
Person (Id, Name, DateOfBirth)
├── Employee (EmployeeId, HireDate, Salary)
│   ├── FullTimeEmployee (Benefits, PensionPlan)
│   └── PartTimeEmployee (HoursPerWeek, HourlyRate)
│       └── Contractor (ContractEndDate, Agency)
├── Customer (CustomerId, LoyaltyPoints)
└── Supplier (SupplierId, PaymentTerms)
```

Design rules that make hierarchy work in production:
- **IS-A test**: only use inheritance when derived IS genuinely a specialization
  of base. A Contractor IS-A PartTimeEmployee. A Car IS-NOT-A Engine.
- **Liskov Substitution**: anywhere you use Employee, a FullTimeEmployee must work
  correctly without the caller knowing the difference.
- **Prefer composition for HAS-A**: Employee HAS-A Department — don't inherit from
  Department, hold a reference to it.
- **Keep hierarchies shallow**: more than 3 levels deep becomes fragile and hard
  to reason about in any real system.
- **Use interfaces for cross-cutting behaviour**: `ILoggable`, `IAuditable`,
  `IExportable` can be applied to any node in the tree without polluting the hierarchy.

---

## 🎁 Part 03 – Bonus

### Self-Study Report

**Key takeaways from Task 09:**

- Enums are strongly typed named constants. Explicit values prevent accidental
  shifts when members are added. Choosing the right underlying type (byte, short)
  matters at scale.
- `virtual` properties enable polymorphism at the property level — not just methods.
  `sealed override` locks a member to prevent further subclassing.
- Static classes are containers for stateless pure functions. They cannot be
  instantiated and have no instance constructor by design.
- Operator overloading makes custom types feel native when the operation is
  genuinely intuitive (`ComplexNumber * ComplexNumber`). Not every operator can
  be overloaded — language-critical ones like `=` and `&&` are off-limits.
- Generics deliver type-safe code reuse. Constraints (`where T : IComparable<T>`)
  are the mechanism that turns wild-card generics into precise, contract-driven code.
- Struct equality requires explicit `operator ==` because the compiler cannot
  safely assume field-by-field comparison is always the right semantic.
- Overriding `Equals` and `GetHashCode` together is a critical pair — break one
  and collections like `Dictionary` and `HashSet` produce wrong results silently.

---

### Event-Driven Programming

Event-driven programming (EDP) is a paradigm where the flow of a program is
determined by events — user actions, sensor outputs, messages, or signals — rather
than a fixed sequential execution path.

**Core mechanics in C#:**

```csharp
// 1. Declare a delegate type (the event signature)
public delegate void StockAlertHandler(string ticker, double price);

// 2. Declare the event on the publisher
public class StockMarket
{
    public event StockAlertHandler? PriceThresholdExceeded;

    public void CheckPrice(string ticker, double price)
    {
        if (price > 100)
            PriceThresholdExceeded?.Invoke(ticker, price);
    }
}

// 3. Subscribe in the consumer
var market = new StockMarket();
market.PriceThresholdExceeded += (ticker, price) =>
    Console.WriteLine($"ALERT: {ticker} hit {price:C}!");

market.CheckPrice("MSFT", 105.50);   // fires the event
market.CheckPrice("AAPL",  98.00);   // below threshold — no event
```

**Key concepts:**
- **Publisher** — raises the event when something happens (StockMarket).
- **Subscriber** — listens and reacts (the lambda above).
- **Delegate** — the function-pointer contract that connects them.
- **Event** — wraps the delegate so only the publisher can invoke it.

**Where EDP shines:**
- UI frameworks (button clicks, keyboard input, window resize)
- Real-time systems (IoT sensor readings, trading systems)
- Microservices (message queues, WebSocket streams)
- Game engines (collision events, timer ticks)

The pattern naturally decouples publishers from subscribers — the market doesn't
know or care who is listening. This makes EDP systems extremely extensible.

---

## 🛠 Requirements
- .NET 8 SDK
- Visual Studio 2022 (any edition)
