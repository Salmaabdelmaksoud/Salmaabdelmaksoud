// ============================================================
//  Part02 – ResearchTopics
//  1. Parallel Programming & Concurrency
//  2. Unit Testing and TDD
//  3. Async/Await Programming
//  (Full write-ups in README.md)
// ============================================================
namespace ResearchTopics;

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02 – Research Topics Summary                             ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════════════╝\n");

        // ── 1. Parallel Programming Demo ──────────────────────────────
        Console.WriteLine("  ── 1. Parallel Programming & Concurrency ──");
        Console.WriteLine("  Running 4 tasks concurrently with Parallel.For:\n");

        object lockObj = new();
        int total = 0;

        Parallel.For(0, 5, i =>
        {
            int result = i * i;
            lock (lockObj)
            {
                total += result;
                Console.WriteLine($"    Task {i}: {i}² = {result}");
            }
        });

        Console.WriteLine($"\n    Sum of squares (0..4): {total}");

        // ── 2. TDD Principle Demo ─────────────────────────────────────
        Console.WriteLine("\n  ── 2. Unit Testing & TDD ──");
        Console.WriteLine("  Simulating test assertions for Calculator methods:\n");

        static int Add(int a, int b) => a + b;
        static bool Assert(string name, bool condition)
        {
            string status = condition ? "PASS" : "FAIL";
            Console.WriteLine($"    [{status}] {name}");
            return condition;
        }

        Assert("Add(2,3)    == 5",  Add(2, 3)    == 5);
        Assert("Add(0,0)    == 0",  Add(0, 0)    == 0);
        Assert("Add(-1,1)   == 0",  Add(-1, 1)   == 0);
        Assert("Add(100,200)==300", Add(100, 200) == 300);

        // ── 3. Async/Await Demo ───────────────────────────────────────
        Console.WriteLine("\n  ── 3. Async / Await ──");
        Console.WriteLine("  Running async operation synchronously in console context:\n");

        RunAsync().GetAwaiter().GetResult();

        Console.WriteLine("\n  Full detailed write-up is in README.md\n");
    }

    static async Task RunAsync()
    {
        Console.WriteLine("    [Async] Starting simulated API call...");
        await Task.Delay(300);   // simulate I/O wait
        Console.WriteLine("    [Async] Response received after 300ms.");

        // Multiple async tasks in parallel
        Task<string> t1 = FetchAsync("Orders", 200);
        Task<string> t2 = FetchAsync("Users",  150);
        Task<string> t3 = FetchAsync("Products",250);

        string[] results = await Task.WhenAll(t1, t2, t3);
        foreach (var r in results)
            Console.WriteLine($"    [Async] {r}");
    }

    static async Task<string> FetchAsync(string resource, int delayMs)
    {
        await Task.Delay(delayMs);
        return $"Fetched {resource} in {delayMs}ms";
    }
}
