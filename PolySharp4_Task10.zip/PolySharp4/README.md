# PolySharp4 🔷
## C# Task 10 | Generics · Delegates · Lambdas · Functional Programming
### 20 Problems + Research Topics + Bonus

---

## 🚀 How to Open in Visual Studio

1. Extract the ZIP
2. Double-click **`PolySharp4.sln`**
3. Right-click any project → **Set as Startup Project**
4. Press **Ctrl+F5**

---

## 📁 Project Map

### Part 01 — 20 Problems

| # | Project | Topic |
|---|---------|-------|
| 01 | `P01_GenericSort` | SortingAlgorithm\<T\> — Employee by Salary |
| 02 | `P02_LambdaDescending` | SortingTwo\<T\> lambda — descending ints |
| 03 | `P03_StringLengthSort` | Dynamic comparer — sort strings by length |
| 04 | `P04_ManagerSort` | Manager : Employee + IComparable\<Manager\> |
| 05 | `P05_FuncDelegate` | Func\<T,T,bool\> — sort by Name length |
| 06 | `P06_AnonVsLambda` | Anonymous function vs Lambda comparison |
| 07 | `P07_GenericSwap` | Standalone Swap\<T\> inside SortingAlgorithm |
| 08 | `P08_MultiCriteriaSort` | Salary then Name tiebreaker |
| 09 | `P09_GetDefault` | GetDefault\<T\> using default(T) |
| 10 | `P10_ICloneable` | ICloneable constraint — clone before sort |
| 11 | `P11_StringTransform` | delegate string→string transformations |
| 12 | `P12_MathDelegate` | delegate (int,int)→int math operations |
| 13 | `P13_GenericDelegate` | Generic delegate\<T,R\> list mapping |
| 14 | `P14_FuncSquare` | Func\<int,int\> — square each element |
| 15 | `P15_ActionDelegate` | Action\<string\> — print operations |
| 16 | `P16_PredicateFilter` | Predicate\<int\> — filter even numbers |
| 17 | `P17_AnonFilter` | Anonymous function — filter string list |
| 18 | `P18_AnonMath` | Anonymous function — math on two ints |
| 19 | `P19_LambdaFilter` | Lambda — filter strings by conditions |
| 20 | `P20_LambdaMath` | Lambda — math on doubles (division, power) |

### Part 02 — Research

| Project | Content |
|---------|---------|
| `ResearchTopics` | Live demo of Parallel, TDD assertions, Async/Await |

---

## 📚 Part 02 — Theory

### 1. LinkedIn Article: Delegates — Implementing the Functional Paradigm in C#

**"How Delegates Turned C# into a Functional Language"**

Most developers think of C# as a pure object-oriented language. But since C# 2.0,
delegates have quietly made it one of the most expressive functional languages on
the JVM-adjacent landscape.

A delegate is a type-safe function pointer. When you write:

```csharp
Func<int, int> square = x => x * x;
```

You are treating a function as a value — storing it, passing it, returning it,
just like any other object. This is the first pillar of functional programming.

**The four functional patterns delegates unlock:**

**Map** — transform every element in a collection:
```csharp
List<int> squares = nums.Select(x => x * x).ToList();
```

**Filter** — keep only elements that satisfy a predicate:
```csharp
List<int> evens = nums.Where(x => x % 2 == 0).ToList();
```

**Reduce** — collapse a collection to a single value:
```csharp
int total = nums.Aggregate(0, (acc, x) => acc + x);
```

**Compose** — chain transforms into a pipeline:
```csharp
var result = employees
    .Where(e => e.Salary > 10_000)
    .OrderBy(e => e.Name)
    .Select(e => e.Name.ToUpper());
```

Each step is a delegate. The pipeline reads like English.
The code is shorter, more testable, and more maintainable than equivalent loops.

The key insight: delegates decouple **what to do** from **how to iterate**.
That separation is the essence of functional programming.

---

### 2. Research: Three Advanced C# Topics

---

#### A. Parallel Programming and Concurrency

Concurrency means multiple tasks are in progress at the same time.
Parallelism means they actually execute simultaneously on multiple CPU cores.

**When to use:**
- CPU-bound work: image processing, data crunching, scientific computation.
- Independent tasks that don't share mutable state.

**C# tools:**

```csharp
// Parallel.For — distributes loop iterations across all CPU cores
Parallel.For(0, 1000, i =>
{
    results[i] = HeavyComputation(i);  // runs on thread pool
});

// Task Parallel Library — explicit tasks
Task t1 = Task.Run(() => ProcessChunk(data[0..500]));
Task t2 = Task.Run(() => ProcessChunk(data[500..]));
await Task.WhenAll(t1, t2);

// PLINQ — parallel LINQ
var results = hugeList
    .AsParallel()
    .Where(x => x.IsValid)
    .Select(x => Transform(x))
    .ToList();
```

**The concurrency challenge:** shared mutable state causes race conditions.
Solution: `lock`, `Interlocked`, `ConcurrentDictionary`, or immutable data.

**Rule of thumb:** only parallelise when the work is CPU-bound and independent.
Parallelising I/O-bound work often makes things slower, not faster.

---

#### B. Unit Testing and Test-Driven Development (TDD)

Unit testing means writing automated tests that verify each method in isolation.
TDD means writing the test *before* the production code.

**TDD cycle — Red → Green → Refactor:**
1. **Red**: write a failing test for the behaviour you want.
2. **Green**: write the minimum code to make it pass.
3. **Refactor**: clean up without breaking the test.

**C# example with xUnit:**

```csharp
// Production code
public class Calculator
{
    public int Add(int a, int b) => a + b;
    public double Divide(double a, double b)
    {
        if (b == 0) throw new DivideByZeroException();
        return a / b;
    }
}

// Test class
public class CalculatorTests
{
    private readonly Calculator _calc = new();

    [Fact]
    public void Add_TwoPositives_ReturnsCorrectSum()
        => Assert.Equal(5, _calc.Add(2, 3));

    [Fact]
    public void Divide_ByZero_ThrowsException()
        => Assert.Throws<DivideByZeroException>(() => _calc.Divide(10, 0));

    [Theory]
    [InlineData(10,  2, 5.0)]
    [InlineData(9,   3, 3.0)]
    [InlineData(-6,  2, -3.0)]
    public void Divide_ValidInputs_ReturnsCorrectResult(double a, double b, double expected)
        => Assert.Equal(expected, _calc.Divide(a, b));
}
```

**Why TDD matters:**
- Forces you to design the API before implementation — cleaner interfaces.
- Regression safety: every future change is tested automatically.
- Living documentation: tests describe exactly what the code should do.

**Popular C# testing frameworks:** xUnit, NUnit, MSTest.

---

#### C. Asynchronous Programming with async and await

See full explanation in **Part 03 Bonus** below.

---

## 🎁 Part 03 — Bonus

### Self-Study Report

**Key takeaways from Task 10:**

- Generics and delegates are the two most powerful features that make C# expressive.
  Together they unlock type-safe, reusable, functional-style code.
- `Func<T,TResult>`, `Action<T>`, and `Predicate<T>` cover ~90% of delegate needs.
  Custom delegate types are only needed for very specific signatures or events.
- Lambda expressions are not just syntax sugar — they enable the entire LINQ ecosystem,
  closures, and deferred execution. Modern C# is unthinkable without them.
- `default(T)` is a small keyword with a big job: safe initialisation of unknown types.
- Constraints (`where T : IComparable<T>`) turn open generics into precise contracts.
- The functional pipeline pattern (Where → Select → OrderBy) is the cleanest way to
  express data transformations — and it is all delegates under the hood.

---

### What is Asynchronous Programming?

Synchronous code runs line by line. Each line waits for the previous one to finish.
If you call a database, the thread just sits there doing nothing for 200ms.

Asynchronous programming lets a thread start an I/O operation, hand it off to the
OS, and go do other useful work while waiting. When the result arrives, execution
resumes from where it left off.

**The problem async solves:**

```csharp
// Synchronous — thread is blocked for 2 seconds. Useless.
string data = File.ReadAllText("big-file.txt");  // 2s wait
ProcessData(data);

// Asynchronous — thread is free during the wait
string data = await File.ReadAllTextAsync("big-file.txt");  // 2s I/O, thread free
ProcessData(data);
```

**Core concepts:**

```csharp
// async marks a method as asynchronous
// await pauses the method until the Task completes — without blocking the thread
public async Task<string> FetchUserAsync(int id)
{
    // Thread is NOT blocked here — it returns to the thread pool
    string json = await httpClient.GetStringAsync($"/users/{id}");
    return JsonSerializer.Deserialize<User>(json).Name;
}

// Run multiple async tasks in parallel
Task<string> t1 = FetchUserAsync(1);
Task<string> t2 = FetchUserAsync(2);
Task<string> t3 = FetchUserAsync(3);

// Wait for ALL to finish — total time = max(t1,t2,t3), not t1+t2+t3
string[] results = await Task.WhenAll(t1, t2, t3);

// Wait for FIRST to finish
string fastest = await Task.WhenAny(t1, t2, t3).Result;
```

**Return types:**
- `Task` — async method that returns nothing (like void).
- `Task<T>` — async method that returns a value of type T.
- `ValueTask<T>` — optimised for frequently-synchronous code paths.

**Where async is essential:**
- Web APIs — handle thousands of simultaneous requests on a small thread pool.
- Desktop/mobile UI — never block the UI thread; use async to keep apps responsive.
- Database queries — `await db.SaveChangesAsync()` instead of `db.SaveChanges()`.
- File and network I/O — any operation that waits for external resources.

**Common mistakes:**
- `async void` — avoid except for event handlers; exceptions are uncatchable.
- `.Result` or `.Wait()` — causes deadlocks in UI/ASP.NET contexts; always use `await`.
- Unnecessary `await` in pass-through methods — omit it and return the Task directly.

Async/await turned I/O-bound C# code from callback spaghetti into clean,
readable, sequential-looking code that scales to millions of concurrent requests.

---

## 🛠 Requirements
- .NET 8 SDK
- Visual Studio 2022 (any edition)

## 📤 GitHub
```bash
git init && git add . && git commit -m "Task10 - PolySharp4 Generics, Delegates, Lambdas" && git push
```
