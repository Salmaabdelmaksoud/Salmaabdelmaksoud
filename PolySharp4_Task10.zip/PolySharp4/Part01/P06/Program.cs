// ============================================================
//  Part01 – P06 | Anonymous function vs Lambda expression
//  Q: How do anonymous functions differ from lambdas?
// ============================================================
namespace P06_AnonVsLambda;

public class SortingTwo<T>
{
    public static void Sort(T[] data, Func<T, T, bool> shouldSwap)
    {
        int n = data.Length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (shouldSwap(data[j], data[j + 1]))
                    (data[j], data[j + 1]) = (data[j + 1], data[j]);
    }
}

class Program
{
    // Named method — most explicit, fully reusable across files
    static bool AscendingInt(int a, int b) => a > b;

    static void Print(int[] arr, string label)
        => Console.WriteLine($"  {label,-38}: [{string.Join(", ", arr)}]");

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P06  |  Anonymous Function vs Lambda    ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        int[] a = { 5, 1, 8, 3, 9, 2, 7 };
        int[] b = a.ToArray();
        int[] c = a.ToArray();
        int[] d = a.ToArray();

        Print(a, "Original");

        // 1. Named method reference
        SortingTwo<int>.Sort(a, AscendingInt);
        Print(a, "Named method (ascending)");

        // 2. Anonymous function — explicit 'delegate' keyword
        SortingTwo<int>.Sort(b, delegate(int x, int y) { return x < y; });
        Print(b, "Anonymous func (descending)");

        // 3. Lambda expression — concise arrow syntax
        SortingTwo<int>.Sort(c, (x, y) => x < y);
        Print(c, "Lambda expression (descending)");

        // 4. Lambda block — when logic needs multiple lines
        SortingTwo<int>.Sort(d, (x, y) =>
        {
            int ax = Math.Abs(x - 5);
            int ay = Math.Abs(y - 5);
            return ax > ay;    // sort by closeness to 5
        });
        Print(d, "Lambda block (closest to 5 first)");

        Console.WriteLine("\n  Side-by-side syntax comparison:");
        Console.WriteLine("  Named method : AscendingInt");
        Console.WriteLine("  Anonymous    : delegate(int x, int y) { return x > y; }");
        Console.WriteLine("  Lambda arrow : (x, y) => x > y");
        Console.WriteLine("  Lambda block : (x, y) => { ... multi-line logic ... }");

        Console.WriteLine("\n  Q: Anonymous vs Lambda?");
        Console.WriteLine("  Anonymous requires 'delegate' keyword + explicit param types.");
        Console.WriteLine("  Lambda infers types and uses '=>' — roughly 4x less syntax.");
        Console.WriteLine("  Both compile to identical IL — no runtime performance difference.");
        Console.WriteLine("  Lambdas are standard in modern C#; anonymous used mainly when");
        Console.WriteLine("  interoperating with older APIs or for explicitness.\n");
    }
}
