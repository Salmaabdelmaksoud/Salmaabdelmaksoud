// ============================================================
//  Part01 – P11 | Delegate string → string transformations
//  Q: Benefits of delegates for functional string transforms?
// ============================================================
namespace P11_StringTransform;

public delegate string StringTransformer(string input);

public static class ListHelper
{
    public static List<string> Transform(List<string> source, StringTransformer fn)
    {
        var result = new List<string>(source.Count);
        foreach (var s in source) result.Add(fn(s));
        return result;
    }
}

class Program
{
    static string Reverse(string s) => new string(s.Reverse().ToArray());
    static string RemoveVowels(string s) =>
        new string(s.Where(c => !"aeiouAEIOU".Contains(c)).ToArray());

    static void Show(List<string> list, string label)
    {
        Console.Write($"  {label,-30}: ");
        Console.WriteLine("[" + string.Join(", ", list.Select(s => $"\"{s}\"")) + "]");
    }

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P11  |  String Transform Delegate       ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        List<string> words = new() { "hello", "world", "csharp", "delegates", "lambda" };
        Show(words, "Original");

        Show(ListHelper.Transform(words, s => s.ToUpper()),               "ToUpper");
        Show(ListHelper.Transform(words, s => s.ToLower()),               "ToLower");
        Show(ListHelper.Transform(words, Reverse),                        "Reverse (named)");
        Show(ListHelper.Transform(words, s => $"[{s}]"),                  "Wrap in brackets");
        Show(ListHelper.Transform(words, s => s.Length > 5 ? s[..5]+"…" : s), "Truncate > 5");
        Show(ListHelper.Transform(words, RemoveVowels),                   "Remove vowels");
        Show(ListHelper.Transform(words, s => s.Replace("l", "L")),       "Replace l→L");

        // Store delegate in a variable and reuse
        StringTransformer shout = s => s.ToUpper() + "!!!";
        Show(ListHelper.Transform(words, shout), "Shout (stored delegate)");

        // Compose two transforms manually
        StringTransformer composed = s => Reverse(s.ToUpper());
        Show(ListHelper.Transform(words, composed), "Reverse(ToUpper) composed");

        Console.WriteLine("\n  Q: Benefits of delegates for string transforms?");
        Console.WriteLine("  Transform() is a stable skeleton — it never changes.");
        Console.WriteLine("  Each new transformation is one lambda, zero method signature change.");
        Console.WriteLine("  Delegates are first-class: store, pass, compose, chain.\n");
    }
}
