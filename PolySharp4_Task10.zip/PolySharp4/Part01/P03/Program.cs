// ============================================================
//  Part01 – P03 | SortingTwo<T> — sort strings by length
//  Q: Why use a dynamic comparer for various data types?
// ============================================================
namespace P03_StringLengthSort;

public class SortingTwo<T>
{
    public static void Sort(T[] data, Func<T, T, bool> shouldSwap)
    {
        int n = data.Length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (shouldSwap(data[j], data[j + 1]))
                    (data[j], data[j + 1]) = (data[j + 1], data[j]);
    }

    public static void Print(T[] data, string label)
        => Console.WriteLine($"  {label,-32}: [{string.Join(", ", data)}]");
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P03  |  Sort Strings by Length          ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        string[] words = { "banana", "kiwi", "apple", "fig", "strawberry", "mango", "plum" };
        SortingTwo<string>.Print(words, "Original");

        // Length ascending (shorter first)
        SortingTwo<string>.Sort(words, (a, b) => a.Length > b.Length);
        SortingTwo<string>.Print(words, "Length ascending");

        // Length descending (longer first)
        SortingTwo<string>.Sort(words, (a, b) => a.Length < b.Length);
        SortingTwo<string>.Print(words, "Length descending");

        // Alphabetical
        SortingTwo<string>.Sort(words, (a, b) =>
            string.Compare(a, b, StringComparison.Ordinal) > 0);
        SortingTwo<string>.Print(words, "Alphabetical");

        // By last character
        SortingTwo<string>.Sort(words, (a, b) => a[^1] > b[^1]);
        SortingTwo<string>.Print(words, "By last char");

        // By vowel count
        static int VowelCount(string s) =>
            s.Count(c => "aeiou".Contains(c, StringComparison.OrdinalIgnoreCase));

        SortingTwo<string>.Sort(words, (a, b) => VowelCount(a) > VowelCount(b));
        SortingTwo<string>.Print(words, "Vowel count ascending");

        Console.WriteLine("\n  Q: Why use a dynamic comparer?");
        Console.WriteLine("  'string' has dozens of valid orderings: length, alpha, vowels,");
        Console.WriteLine("  last char, etc. A fixed comparer serves exactly one scenario.");
        Console.WriteLine("  A Func<T,T,bool> lets the caller inject any rule they need");
        Console.WriteLine("  without touching Sort() — Open/Closed Principle in action.\n");
    }
}
