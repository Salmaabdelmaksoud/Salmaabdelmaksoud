// ============================================================
//  Part01 – P19 | Lambda expression — filter strings
//  Q: What makes lambda expressions essential in modern C#?
// ============================================================
namespace P19_LambdaFilter;

public static class ListHelper
{
    public static List<T> Filter<T>(List<T> source, Func<T, bool> condition)
    {
        var result = new List<T>();
        foreach (var item in source)
            if (condition(item)) result.Add(item);
        return result;
    }
}

class Program
{
    static void Show(List<string> list, string label)
    {
        Console.Write($"  {label,-36}: ");
        Console.WriteLine("[" + string.Join(", ", list) + "]");
    }

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P19  |  Lambda Expression Filter        ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        List<string> words = new()
        {
            "apple", "elephant", "banana", "cherry", "ice", "avocado",
            "date", "elderberry", "fig", "grape", "umbrella", "orange"
        };
        Show(words, "Source");
        Console.WriteLine();

        // Length conditions
        Show(Filter(words, s => s.Length > 3),       "Length > 3");
        Show(Filter(words, s => s.Length >= 6),      "Length >= 6");
        Show(Filter(words, s => s.Length == 4),      "Length == 4");

        // Contains letter
        Show(Filter(words, s => s.Contains('e')),    "Contains 'e'");
        Show(Filter(words, s => s.Contains("an")),   "Contains 'an'");

        // Starts / ends
        Show(Filter(words, s => s.StartsWith('a')),  "Starts with 'a'");
        Show(Filter(words, s => s.EndsWith('e')),    "Ends with 'e'");

        // Combined conditions
        Show(Filter(words, s => s.Length > 3 && s.Contains('e')), "Len>3 AND has 'e'");
        Show(Filter(words, s => s[0] == 'a' || s[0] == 'e' || s[0] == 'i' ||
                                s[0] == 'o' || s[0] == 'u'),      "Starts with vowel");

        // Lambda with block body
        Show(Filter(words, s =>
        {
            int vowelCount = s.Count(c => "aeiou".Contains(c));
            return vowelCount >= 3;
        }), "3+ vowels");

        Console.WriteLine("\n  Q: What makes lambdas essential in modern C#?");
        Console.WriteLine("  They enable LINQ, async/await patterns, delegates, events,");
        Console.WriteLine("  and functional composition without verbose boilerplate.");
        Console.WriteLine("  s => s.Length > 3 reads like natural language.");
        Console.WriteLine("  Entire pipelines: list.Where(…).OrderBy(…).Select(…) in one line.\n");
    }

    // Local helper to reduce typing
    static List<string> Filter(List<string> src, Func<string, bool> fn)
        => ListHelper.Filter(src, fn);
}
