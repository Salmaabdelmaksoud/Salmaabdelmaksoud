// ============================================================
//  Part01 – P05 | Func<T,T,bool> delegate — sort by Name length
//  Q: Advantage of built-in delegates like Func<T,T,TResult>?
// ============================================================
namespace P05_FuncDelegate;

public class Employee
{
    public int    Id     { get; }
    public string Name   { get; }
    public double Salary { get; }

    public Employee(int id, string name, double salary)
    { Id = id; Name = name; Salary = salary; }

    public override string ToString()
        => $"  [{Id}] {Name,-20} (len={Name.Length,2})  Salary={Salary,10:C}";
}

public class SortingTwo<T>
{
    public static void Sort(T[] data, Func<T, T, bool> shouldSwap)
    {
        int n = data.Length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (shouldSwap(data[j], data[j + 1]))
                    (data[j], data[j + 1]) = (data[j + 1], data[j]);
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P05  |  Func<T,T,bool> — Name Length   ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Employee[] employees =
        {
            new Employee(1, "Ali",              14_500),
            new Employee(2, "Sara Mohamed",      8_200),
            new Employee(3, "Karim",            22_000),
            new Employee(4, "Layla Tarek",      11_750),
            new Employee(5, "Omar Saeed",       18_300),
        };

        Console.WriteLine("  Original:");
        foreach (var e in employees) Console.WriteLine(e);

        // Store Func in a named variable — reusable
        Func<Employee, Employee, bool> byNameAsc  = (a, b) => a.Name.Length > b.Name.Length;
        Func<Employee, Employee, bool> byNameDesc = (a, b) => a.Name.Length < b.Name.Length;
        Func<Employee, Employee, bool> bySalary   = (a, b) => a.Salary > b.Salary;

        SortingTwo<Employee>.Sort(employees, byNameAsc);
        Console.WriteLine("\n  By Name length ascending:");
        foreach (var e in employees) Console.WriteLine(e);

        SortingTwo<Employee>.Sort(employees, byNameDesc);
        Console.WriteLine("\n  By Name length descending:");
        foreach (var e in employees) Console.WriteLine(e);

        SortingTwo<Employee>.Sort(employees, bySalary);
        Console.WriteLine("\n  By Salary ascending (different Func, same Sort method):");
        foreach (var e in employees) Console.WriteLine(e);

        Console.WriteLine("\n  Q: Advantage of built-in Func<T,T,TResult>?");
        Console.WriteLine("  No need to declare a custom delegate type. Func is universal —");
        Console.WriteLine("  every C# developer recognises it instantly. Works natively with");
        Console.WriteLine("  lambdas, method groups, and stored variables. Zero boilerplate.\n");
    }
}
