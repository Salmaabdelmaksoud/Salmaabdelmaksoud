// ============================================================
//  Part01 – P10 | ICloneable constraint — clone Employee array
//  Q: How do constraints ensure type safety?
// ============================================================
namespace P10_ICloneable;

public class Employee : IComparable<Employee>, ICloneable
{
    public int    Id     { get; }
    public string Name   { get; }
    public double Salary { get; set; }

    public Employee(int id, string name, double salary)
    { Id = id; Name = name; Salary = salary; }

    public int CompareTo(Employee? other)
    {
        if (other is null) return 1;
        return Salary.CompareTo(other.Salary);
    }

    public object Clone() => new Employee(Id, Name, Salary);

    public override string ToString()
        => $"  [{Id}] {Name,-18} Salary={Salary,10:C}";
}

// Constraint: T must implement IComparable<T> AND ICloneable
public class SortingAlgorithm<T> where T : IComparable<T>, ICloneable
{
    private readonly T[] _original;
    public SortingAlgorithm(T[] data) { _original = data; }

    // Clone the whole array first, then sort the clone
    public T[] CloneAndSort()
    {
        T[] copy = new T[_original.Length];
        for (int i = 0; i < _original.Length; i++)
            copy[i] = (T)_original[i].Clone();

        int n = copy.Length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (copy[j].CompareTo(copy[j + 1]) > 0)
                    (copy[j], copy[j + 1]) = (copy[j + 1], copy[j]);

        return copy;
    }

    public void PrintOriginal(string label)
    {
        Console.WriteLine($"\n  {label}:");
        foreach (var item in _original) Console.WriteLine(item);
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P10  |  ICloneable Constraint           ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝");

        Employee[] original =
        {
            new Employee(1, "Ahmed Hassan",  14_500),
            new Employee(2, "Sara Mohamed",   8_200),
            new Employee(3, "Karim Ali",     22_000),
            new Employee(4, "Layla Tarek",   11_750),
        };

        var sorter = new SortingAlgorithm<Employee>(original);
        sorter.PrintOriginal("Original (before clone-sort)");

        Employee[] sorted = sorter.CloneAndSort();

        Console.WriteLine("\n  Sorted clone (ascending salary):");
        foreach (var e in sorted) Console.WriteLine(e);

        sorter.PrintOriginal("Original (unchanged after clone-sort)");

        // Prove true independence — mutate clone, original unaffected
        sorted[0].Salary = 999_999;
        Console.WriteLine("\n  After mutating sorted[0].Salary = 999,999:");
        Console.WriteLine("\n  Clone:");
        foreach (var e in sorted) Console.WriteLine(e);
        sorter.PrintOriginal("Original (still unchanged)");

        Console.WriteLine("\n  Q: How do constraints ensure type safety?");
        Console.WriteLine("  'where T : IComparable<T>, ICloneable' means the compiler");
        Console.WriteLine("  rejects any T that doesn't satisfy both interfaces.");
        Console.WriteLine("  You can safely call .CompareTo() and .Clone() without casts —");
        Console.WriteLine("  no runtime InvalidCastException is possible. Zero defensive code.\n");
    }
}
