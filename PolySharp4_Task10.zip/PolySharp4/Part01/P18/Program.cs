// ============================================================
//  Part01 – P18 | Anonymous function — math on two integers
//  Q: When prefer anonymous functions over named methods?
// ============================================================
namespace P18_AnonMath;

public static class Calculator
{
    public static int Compute(int a, int b, Func<int, int, int> op) => op(a, b);

    public static void Show(int a, int b, Func<int, int, int> op, string label)
        => Console.WriteLine($"  {label,-28}: {Compute(a, b, op)}");
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P18  |  Anonymous Function Math         ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        int x = 15, y = 4;
        Console.WriteLine($"  x = {x},  y = {y}\n");

        // All operations via anonymous functions
        Calculator.Show(x, y,
            delegate(int a, int b) { return a + b; },
            "Add (anon)");

        Calculator.Show(x, y,
            delegate(int a, int b) { return a - b; },
            "Subtract (anon)");

        Calculator.Show(x, y,
            delegate(int a, int b) { return a * b; },
            "Multiply (anon)");

        Calculator.Show(x, y,
            delegate(int a, int b) { return b != 0 ? a / b : 0; },
            "Divide   (anon, safe)");

        Calculator.Show(x, y,
            delegate(int a, int b) { return a % b; },
            "Modulo   (anon)");

        Calculator.Show(x, y,
            delegate(int a, int b) { return (int)Math.Pow(a, b); },
            "Power    (anon)");

        // Multi-line anonymous with intermediate variable
        Console.WriteLine("\n  Multi-step anonymous function:");
        Calculator.Show(x, y,
            delegate(int a, int b)
            {
                int sum  = a + b;
                int prod = a * b;
                return prod - sum;   // a*b - (a+b)
            },
            "Product minus Sum (anon)");

        // Stored anonymous function
        Func<int, int, int> gcd = delegate(int a, int b)
        {
            while (b != 0) { int t = b; b = a % b; a = t; }
            return a;
        };
        Console.WriteLine($"\n  GCD({x}, {y}) via stored anonymous = {Calculator.Compute(x, y, gcd)}");

        // Same with lambda for comparison
        Func<int, int, int> lcm = (a, b) => Math.Abs(a * b) / Calculator.Compute(a, b, gcd);
        Console.WriteLine($"  LCM({x}, {y}) via lambda            = {Calculator.Compute(x, y, lcm)}");

        Console.WriteLine("\n  Q: When prefer anonymous functions over named methods?");
        Console.WriteLine("  When the logic is used exactly once and won't be reused.");
        Console.WriteLine("  When the operation is clear from context (no name needed).");
        Console.WriteLine("  Lambdas are preferred for brevity; anonymous for explicitness.\n");
    }
}
