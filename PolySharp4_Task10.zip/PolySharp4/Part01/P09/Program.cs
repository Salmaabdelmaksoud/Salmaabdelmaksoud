// ============================================================
//  Part01 – P09 | GetDefault<T> using default(T)
//  Q: Why is default(T) crucial in generic programming?
// ============================================================
namespace P09_GetDefault;

public static class GenericUtils
{
    public static T GetDefault<T>() => default(T)!;

    public static bool IsDefault<T>(T value)
        => EqualityComparer<T>.Default.Equals(value, default(T));

    public static T[] CreateDefaultArray<T>(int size)
    {
        T[] arr = new T[size];
        for (int i = 0; i < size; i++) arr[i] = default(T)!;
        return arr;
    }

    public static void PrintDefault<T>(string typeName)
    {
        T val = GetDefault<T>();
        string display = val is null ? "null" : val.ToString()!;
        Console.WriteLine($"  default({typeName,-12}) = {display}");
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P09  |  GetDefault<T>                   ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Console.WriteLine("  Value type defaults:");
        GenericUtils.PrintDefault<int>("int");
        GenericUtils.PrintDefault<double>("double");
        GenericUtils.PrintDefault<bool>("bool");
        GenericUtils.PrintDefault<char>("char");
        GenericUtils.PrintDefault<long>("long");
        GenericUtils.PrintDefault<DateTime>("DateTime");

        Console.WriteLine("\n  Reference type defaults:");
        GenericUtils.PrintDefault<string>("string");
        GenericUtils.PrintDefault<int[]>("int[]");

        Console.WriteLine("\n  IsDefault checks:");
        Console.WriteLine($"  IsDefault<int>(0)        = {GenericUtils.IsDefault<int>(0)}");
        Console.WriteLine($"  IsDefault<int>(5)        = {GenericUtils.IsDefault<int>(5)}");
        Console.WriteLine($"  IsDefault<bool>(false)   = {GenericUtils.IsDefault<bool>(false)}");
        Console.WriteLine($"  IsDefault<bool>(true)    = {GenericUtils.IsDefault<bool>(true)}");
        Console.WriteLine($"  IsDefault<string>(null)  = {GenericUtils.IsDefault<string>(null!)}");
        Console.WriteLine($"  IsDefault<string>(\"hi\")  = {GenericUtils.IsDefault<string>("hi")}");

        Console.WriteLine("\n  CreateDefaultArray<int>(5):");
        int[] arr = GenericUtils.CreateDefaultArray<int>(5);
        Console.WriteLine("  [" + string.Join(", ", arr) + "]");

        Console.WriteLine("\n  Q: Why is default(T) crucial?");
        Console.WriteLine("  Inside a generic method T is unknown at write time.");
        Console.WriteLine("  You cannot say 'return 0' — 0 is meaningless for string.");
        Console.WriteLine("  default(T) resolves to 0/false for value types, null for classes.");
        Console.WriteLine("  It is the only safe way to initialise or reset a T generically.\n");
    }
}
