// ============================================================
//  Part01 – P16 | Predicate<T> — filter even numbers
//  Q: Role of predicates in functional programming?
// ============================================================
namespace P16_PredicateFilter;

public static class ListHelper
{
    // Filter using Predicate<T>
    public static List<T> Filter<T>(List<T> source, Predicate<T> predicate)
    {
        var result = new List<T>();
        foreach (var item in source)
            if (predicate(item))
                result.Add(item);
        return result;
    }

    // Count matching items
    public static int Count<T>(List<T> source, Predicate<T> predicate)
    {
        int count = 0;
        foreach (var item in source)
            if (predicate(item)) count++;
        return count;
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P16  |  Predicate<T> Filter             ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        List<int> nums = new() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 15, 20 };
        Console.WriteLine($"  Source: [{string.Join(", ", nums)}]");

        // Even numbers
        Predicate<int> isEven = n => n % 2 == 0;
        List<int> evens = ListHelper.Filter(nums, isEven);
        Console.WriteLine($"\n  Even:         [{string.Join(", ", evens)}]");

        // Odd numbers
        List<int> odds = ListHelper.Filter(nums, n => n % 2 != 0);
        Console.WriteLine($"  Odd:          [{string.Join(", ", odds)}]");

        // Greater than 7
        List<int> big = ListHelper.Filter(nums, n => n > 7);
        Console.WriteLine($"  Greater > 7:  [{string.Join(", ", big)}]");

        // Divisible by 3
        List<int> div3 = ListHelper.Filter(nums, n => n % 3 == 0);
        Console.WriteLine($"  Div by 3:     [{string.Join(", ", div3)}]");

        // Perfect square
        Predicate<int> isPerfectSquare = n =>
        {
            int s = (int)Math.Sqrt(n);
            return s * s == n;
        };
        List<int> squares = ListHelper.Filter(nums, isPerfectSquare);
        Console.WriteLine($"  PerfectSquare:[{string.Join(", ", squares)}]");

        // Predicate<string>
        List<string> words = new() { "apple", "art", "banana", "avocado", "cherry", "apricot" };
        Console.WriteLine($"\n  Words: [{string.Join(", ", words)}]");

        Predicate<string> startsWithA = s => s.StartsWith('a');
        List<string> aWords = ListHelper.Filter(words, startsWithA);
        Console.WriteLine($"  Starts with 'a': [{string.Join(", ", aWords)}]");

        // Count how many match
        int evenCount = ListHelper.Count(nums, isEven);
        Console.WriteLine($"\n  Count of evens = {evenCount}");

        Console.WriteLine("\n  Q: Role of predicates in functional programming?");
        Console.WriteLine("  A predicate is a pure boolean question about a value.");
        Console.WriteLine("  It decouples the filtering logic from the iteration logic.");
        Console.WriteLine("  Predicates compose: isEven AND isPositive AND isSmall.");
        Console.WriteLine("  Code reads like prose: Filter(list, isEven).\n");
    }
}
