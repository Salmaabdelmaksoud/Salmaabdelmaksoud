// ============================================================
//  Part01 – P07 | SortingAlgorithm<T> + standalone Swap<T>
//  Q: Why is generic Swap beneficial?
// ============================================================
namespace P07_GenericSwap;

public class SortingAlgorithm<T> where T : IComparable<T>
{
    private readonly T[] _data;
    public SortingAlgorithm(T[] data) { _data = data; }

    // Standalone generic Swap — works for any type
    public static void Swap<TItem>(ref TItem a, ref TItem b)
    {
        TItem temp = a;
        a = b;
        b = temp;
    }

    // Uses the generic Swap internally
    public void Sort()
    {
        int n = _data.Length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (_data[j].CompareTo(_data[j + 1]) > 0)
                    Swap(ref _data[j], ref _data[j + 1]);
    }

    public void Print(string label = "")
    {
        if (!string.IsNullOrEmpty(label))
            Console.Write($"  {label,-32}: ");
        Console.WriteLine("[" + string.Join(", ", _data) + "]");
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P07  |  Generic Swap<T>                 ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // Direct swap on variables
        int x = 10, y = 99;
        Console.WriteLine($"  Before Swap(int):  x={x}  y={y}");
        SortingAlgorithm<int>.Swap(ref x, ref y);
        Console.WriteLine($"  After  Swap(int):  x={x}  y={y}");

        string s1 = "Hello", s2 = "World";
        Console.WriteLine($"\n  Before Swap(string): s1={s1}  s2={s2}");
        SortingAlgorithm<int>.Swap(ref s1, ref s2);
        Console.WriteLine($"  After  Swap(string): s1={s1}  s2={s2}");

        double d1 = 3.14, d2 = 2.71;
        Console.WriteLine($"\n  Before Swap(double): d1={d1}  d2={d2}");
        SortingAlgorithm<int>.Swap(ref d1, ref d2);
        Console.WriteLine($"  After  Swap(double): d1={d1}  d2={d2}");

        // Array of integers — sort using generic Swap internally
        int[] nums = { 64, 25, 12, 22, 11, 90, 3 };
        var sorter = new SortingAlgorithm<int>(nums);
        sorter.Print("\n  Before sort");
        sorter.Sort();
        sorter.Print("After BubbleSort (uses Swap)");

        // Strings sorted
        string[] words = { "cherry", "apple", "date", "banana", "fig" };
        var strSorter = new SortingAlgorithm<string>(words);
        strSorter.Print("\n  Strings before sort");
        strSorter.Sort();
        strSorter.Print("Strings after sort");

        Console.WriteLine("\n  Q: Why generic Swap over type-specific versions?");
        Console.WriteLine("  Swap<TItem> handles int, string, double, Employee — anything.");
        Console.WriteLine("  Without generics you'd write SwapInt, SwapString, SwapDouble...");
        Console.WriteLine("  That's N methods for N types. Generic = 1 method, N types.\n");
    }
}
