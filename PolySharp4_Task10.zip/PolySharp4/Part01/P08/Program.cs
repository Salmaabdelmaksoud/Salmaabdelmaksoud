// ============================================================
//  Part01 – P08 | SortingTwo<T> — Salary then Name tiebreaker
//  Q: Challenges and benefits of multi-criteria sorting?
// ============================================================
namespace P08_MultiCriteriaSort;

public class Employee
{
    public int    Id     { get; }
    public string Name   { get; }
    public double Salary { get; }

    public Employee(int id, string name, double salary)
    { Id = id; Name = name; Salary = salary; }

    public override string ToString()
        => $"  [{Id}] {Name,-20} Salary={Salary,10:C}";
}

public class SortingTwo<T>
{
    // Comparer returns int: negative = a<b, 0 = equal, positive = a>b
    public static void Sort(T[] data, Func<T, T, int> comparer)
    {
        int n = data.Length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (comparer(data[j], data[j + 1]) > 0)
                    (data[j], data[j + 1]) = (data[j + 1], data[j]);
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P08  |  Multi-Criteria Sort             ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Employee[] employees =
        {
            new Employee(1, "Omar Saeed",    15_000),
            new Employee(2, "Ahmed Hassan",  15_000),  // tie on salary
            new Employee(3, "Sara Mohamed",   8_200),
            new Employee(4, "Karim Ali",     22_000),
            new Employee(5, "Layla Tarek",   15_000),  // another tie
        };

        Console.WriteLine("  Original:");
        foreach (var e in employees) Console.WriteLine(e);

        // Primary: Salary ASC — Secondary: Name ASC (alphabetical tiebreaker)
        Func<Employee, Employee, int> bySalaryThenName = (a, b) =>
        {
            int cmp = a.Salary.CompareTo(b.Salary);
            if (cmp != 0) return cmp;
            return string.Compare(a.Name, b.Name, StringComparison.Ordinal);
        };

        SortingTwo<Employee>.Sort(employees, bySalaryThenName);
        Console.WriteLine("\n  Sorted by Salary ASC, then Name ASC:");
        foreach (var e in employees) Console.WriteLine(e);

        // Primary: Name length ASC — Secondary: Salary DESC
        Func<Employee, Employee, int> byLenThenSalaryDesc = (a, b) =>
        {
            int cmp = a.Name.Length.CompareTo(b.Name.Length);
            if (cmp != 0) return cmp;
            return b.Salary.CompareTo(a.Salary);  // reversed = descending
        };

        SortingTwo<Employee>.Sort(employees, byLenThenSalaryDesc);
        Console.WriteLine("\n  Sorted by Name-Length ASC, then Salary DESC:");
        foreach (var e in employees) Console.WriteLine(e);

        Console.WriteLine("\n  Q: Challenges and benefits?");
        Console.WriteLine("  Challenge: criteria must be evaluated strictly in priority order.");
        Console.WriteLine("  Only move to the next criterion when the current one is tied.");
        Console.WriteLine("  Benefit: Sort() never changes. The lambda holds all the logic.");
        Console.WriteLine("  Adding a third criterion = one more 'if' inside the lambda.\n");
    }
}
