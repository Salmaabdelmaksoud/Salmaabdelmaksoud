// ============================================================
//  Part01 – P02 | SortingTwo<T>.Sort with Lambda — descending ints
//  Q: How do lambdas improve readability and flexibility?
// ============================================================
namespace P02_LambdaDescending;

public class SortingTwo<T>
{
    // Sort accepts a comparer injected at call-site
    public static void Sort(T[] data, Func<T, T, bool> shouldSwap)
    {
        int n = data.Length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (shouldSwap(data[j], data[j + 1]))
                    (data[j], data[j + 1]) = (data[j + 1], data[j]);
    }

    public static void Print(T[] data, string label)
        => Console.WriteLine($"  {label,-30}: [{string.Join(", ", data)}]");
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P02  |  Lambda Descending Sort          ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        int[] nums = { 42, 7, 19, 85, 3, 56, 28, 64 };
        SortingTwo<int>.Print(nums, "Original");

        // Ascending  — swap when left > right
        SortingTwo<int>.Sort(nums, (a, b) => a > b);
        SortingTwo<int>.Print(nums, "Ascending  (a > b lambda)");

        // Descending — swap when left < right
        SortingTwo<int>.Sort(nums, (a, b) => a < b);
        SortingTwo<int>.Print(nums, "Descending (a < b lambda)");

        // Sort by absolute distance from 50
        SortingTwo<int>.Sort(nums, (a, b) => Math.Abs(a - 50) > Math.Abs(b - 50));
        SortingTwo<int>.Print(nums, "Closest to 50 first");

        // Anonymous function equivalent (verbose)
        int[] nums2 = { 9, 1, 7, 3, 5 };
        SortingTwo<int>.Sort(nums2, delegate(int a, int b) { return a < b; });
        SortingTwo<int>.Print(nums2, "Descending (anon func)");

        Console.WriteLine("\n  Comparison:");
        Console.WriteLine("  Lambda:     (a, b) => a < b");
        Console.WriteLine("  Anonymous:  delegate(int a, int b) { return a < b; }");
        Console.WriteLine("\n  Q: How do lambdas improve readability?");
        Console.WriteLine("  They express intent in minimal syntax at the call-site.");
        Console.WriteLine("  Sort() stays unchanged — the lambda IS the flexibility.\n");
    }
}
