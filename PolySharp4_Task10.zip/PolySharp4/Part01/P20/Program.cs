// ============================================================
//  Part01 – P20 | Lambda expression — math on two doubles
//  Q: How do lambdas enhance mathematical expressiveness?
// ============================================================
namespace P20_LambdaMath;

public static class MathEngine
{
    public static double Compute(double a, double b, Func<double, double, double> op)
        => op(a, b);

    public static void Show(double a, double b, Func<double, double, double> op, string label)
        => Console.WriteLine($"  {label,-30}: {Compute(a, b, op):F6}");
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P20  |  Lambda Math on Doubles          ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        double x = 8.0, y = 3.0;
        Console.WriteLine($"  x = {x},  y = {y}\n");

        // Basic operations
        MathEngine.Show(x, y, (a, b) => a / b,                  "Division  x/y");
        MathEngine.Show(x, y, (a, b) => Math.Pow(a, b),         "Power     x^y");
        MathEngine.Show(x, y, (a, b) => Math.Sqrt(a + b),       "Sqrt(x+y)");
        MathEngine.Show(x, y, (a, b) => Math.Log(a) / Math.Log(b), "Log_y(x)");
        MathEngine.Show(x, y, (a, b) => a % b,                  "Modulo    x%y");
        MathEngine.Show(x, y, (a, b) => Math.Abs(a - b),        "|x - y|");

        // Trigonometric with doubles
        Console.WriteLine($"\n  x = π/3 ({Math.PI/3:F4}), y = π/6 ({Math.PI/6:F4})\n");
        double angle1 = Math.PI / 3;
        double angle2 = Math.PI / 6;

        MathEngine.Show(angle1, angle2, (a, b) => Math.Sin(a) + Math.Cos(b), "sin(x)+cos(y)");
        MathEngine.Show(angle1, angle2, (a, b) => Math.Tan(a) * Math.Tan(b), "tan(x)*tan(y)");

        // Store lambda in variable — reuse multiple times
        Console.WriteLine("\n  Stored lambdas:");
        Func<double, double, double> hypotenuse = (a, b) => Math.Sqrt(a * a + b * b);
        Func<double, double, double> harmonic    = (a, b) => 2 * a * b / (a + b);
        Func<double, double, double> geometric   = (a, b) => Math.Sqrt(a * b);
        Func<double, double, double> arithmetic  = (a, b) => (a + b) / 2;

        Console.WriteLine($"  Hypotenuse({x},{y})    = {hypotenuse(x, y):F6}");
        Console.WriteLine($"  Harmonic mean({x},{y}) = {harmonic(x, y):F6}");
        Console.WriteLine($"  Geometric mean({x},{y})= {geometric(x, y):F6}");
        Console.WriteLine($"  Arithmetic mean({x},{y})={arithmetic(x, y):F6}");

        // Lambda with multi-step computation
        Func<double, double, double> compound = (principal, rate) =>
        {
            double monthly = rate / 12 / 100;
            int months = 12;
            return principal * Math.Pow(1 + monthly, months);
        };
        Console.WriteLine($"\n  Compound interest (1000 at 5% for 1yr) = {compound(1000, 5):C}");

        Console.WriteLine("\n  Q: How do lambdas enhance math expressiveness?");
        Console.WriteLine("  (a, b) => Math.Pow(a, b) reads exactly like the math formula.");
        Console.WriteLine("  Formulas can be stored, passed, composed, and swapped at runtime.");
        Console.WriteLine("  No boilerplate — the formula IS the function.\n");
    }
}
