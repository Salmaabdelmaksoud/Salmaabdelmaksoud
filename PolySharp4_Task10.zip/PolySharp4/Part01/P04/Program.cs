// ============================================================
//  Part01 – P04 | Manager : Employee + IComparable<Manager>
//  Q: How does IComparable in derived classes enable custom sorting?
// ============================================================
namespace P04_ManagerSort;

public class Employee : IComparable<Employee>
{
    public int    Id     { get; }
    public string Name   { get; }
    public double Salary { get; }

    public Employee(int id, string name, double salary)
    { Id = id; Name = name; Salary = salary; }

    public virtual int CompareTo(Employee? other)
    {
        if (other is null) return 1;
        return Salary.CompareTo(other.Salary);
    }

    public override string ToString()
        => $"  [Employee]  {Name,-18} Salary={Salary,10:C}";
}

public class Manager : Employee, IComparable<Manager>
{
    public string Department { get; }
    public int    TeamSize   { get; }

    public Manager(int id, string name, double salary, string dept, int teamSize)
        : base(id, name, salary)
    { Department = dept; TeamSize = teamSize; }

    // Manager-specific: salary first, then team size as tiebreaker
    public int CompareTo(Manager? other)
    {
        if (other is null) return 1;
        int cmp = Salary.CompareTo(other.Salary);
        return cmp != 0 ? cmp : TeamSize.CompareTo(other.TeamSize);
    }

    public override string ToString()
        => $"  [Manager ]  {Name,-18} Salary={Salary,10:C}  Team={TeamSize}  Dept={Department}";
}

public class SortingAlgorithm<T> where T : IComparable<T>
{
    public static void BubbleSort(T[] data)
    {
        int n = data.Length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (data[j].CompareTo(data[j + 1]) > 0)
                    (data[j], data[j + 1]) = (data[j + 1], data[j]);
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P04  |  Manager IComparable<Manager>    ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Employee[] employees =
        {
            new Employee(1, "Ahmed Hassan",  14_500),
            new Employee(2, "Sara Mohamed",   8_200),
            new Employee(3, "Karim Ali",     22_000),
        };

        Console.WriteLine("  Employees sorted by Salary:");
        SortingAlgorithm<Employee>.BubbleSort(employees);
        foreach (var e in employees) Console.WriteLine(e);

        Manager[] managers =
        {
            new Manager(10, "Layla Tarek",  45_000, "Engineering", 8),
            new Manager(11, "Omar Saeed",   45_000, "Marketing",   3),  // same salary!
            new Manager(12, "Nour Hamed",   60_000, "Finance",     5),
        };

        Console.WriteLine("\n  Managers sorted by Salary then TeamSize:");
        SortingAlgorithm<Manager>.BubbleSort(managers);
        foreach (var m in managers) Console.WriteLine(m);

        // Polymorphic — mix treated as Employee (base type rules)
        Employee[] mixed =
        {
            new Employee(1, "Ahmed",   14_500),
            new Manager(10, "Layla",  45_000, "Eng", 8),
            new Employee(2, "Sara",    8_200),
            new Manager(11, "Omar",   20_000, "Mkt", 3),
        };

        Console.WriteLine("\n  Mixed array sorted as Employee (salary only):");
        SortingAlgorithm<Employee>.BubbleSort(mixed);
        foreach (var item in mixed) Console.WriteLine(item);

        Console.WriteLine("\n  Q: How does IComparable in derived classes enable sorting?");
        Console.WriteLine("  Each class defines its own comparison rules in CompareTo.");
        Console.WriteLine("  Manager adds TeamSize as a tiebreaker without changing Employee.");
        Console.WriteLine("  The generic algorithm just calls .CompareTo — polymorphism");
        Console.WriteLine("  routes to the correct override at runtime.\n");
    }
}
