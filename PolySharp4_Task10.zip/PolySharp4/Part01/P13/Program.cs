// ============================================================
//  Part01 – P13 | Generic delegate<T, R> — list transformation
//  Q: Advantages of generic delegates in data transformation?
// ============================================================
namespace P13_GenericDelegate;

public delegate R Transformer<T, R>(T input);

public static class ListMapper
{
    public static List<R> Map<T, R>(List<T> source, Transformer<T, R> transform)
    {
        var result = new List<R>(source.Count);
        foreach (var item in source)
            result.Add(transform(item));
        return result;
    }
}

class Employee
{
    public string Name   { get; }
    public double Salary { get; }
    public Employee(string name, double salary) { Name = name; Salary = salary; }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P13  |  Generic Delegate<T, R>          ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // int → string
        List<int> nums = new() { 1, 2, 3, 4, 5 };
        List<string> asStr = ListMapper.Map(nums, i => i.ToString());
        Console.WriteLine($"  int→string   : [{string.Join(", ", asStr)}]");

        // int → double (square root)
        List<double> sqrts = ListMapper.Map(nums, i => Math.Sqrt(i));
        Console.WriteLine($"  int→sqrt     : [{string.Join(", ", sqrts.Select(d => $"{d:F3}"))}]");

        // int → bool (even?)
        List<bool> evens = ListMapper.Map(nums, i => i % 2 == 0);
        Console.WriteLine($"  int→even?    : [{string.Join(", ", evens)}]");

        // string → int (length)
        List<string> words = new() { "apple", "fig", "strawberry", "mango" };
        List<int> lengths = ListMapper.Map(words, s => s.Length);
        Console.WriteLine($"\n  string→length: [{string.Join(", ", lengths)}]");

        // string → string (reverse)
        List<string> reversed = ListMapper.Map(words, s => new string(s.Reverse().ToArray()));
        Console.WriteLine($"  string→rev   : [{string.Join(", ", reversed)}]");

        // Employee → string summary
        List<Employee> employees = new()
        {
            new Employee("Ahmed",  14_500),
            new Employee("Sara",    8_200),
            new Employee("Karim",  22_000),
        };
        List<string> summaries = ListMapper.Map<Employee, string>(
            employees, e => $"{e.Name}: {e.Salary:C}");
        Console.WriteLine("\n  Employee→summary:");
        summaries.ForEach(s => Console.WriteLine($"    {s}"));

        // Employee → double (extract salary)
        List<double> salaries = ListMapper.Map(employees, e => e.Salary);
        Console.WriteLine($"\n  Employee→salary: [{string.Join(", ", salaries.Select(s => $"{s:N0}"))}]");

        Console.WriteLine("\n  Q: Advantages of generic delegates?");
        Console.WriteLine("  Map<T,R> works for any (T,R) pair: int→string, Employee→bool.");
        Console.WriteLine("  One implementation replaces N type-specific mapper methods.");
        Console.WriteLine("  Type-safe: compiler prevents a wrong transform being passed.\n");
    }
}
