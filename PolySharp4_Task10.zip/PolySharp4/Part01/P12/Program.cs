// ============================================================
//  Part01 – P12 | Delegate (int, int) → int — math operations
//  Q: How do delegates promote reusability?
// ============================================================
namespace P12_MathDelegate;

public delegate int MathOperation(int a, int b);

public static class Calculator
{
    public static int Compute(int a, int b, MathOperation op) => op(a, b);

    public static void Show(int a, int b, MathOperation op, string opName)
        => Console.WriteLine($"  {a,4} {opName,-12} {b,4} = {Compute(a, b, op),6}");
}

class Program
{
    static int Add(int a, int b)      => a + b;
    static int Subtract(int a, int b) => a - b;
    static int Multiply(int a, int b) => a * b;
    static int SafeDivide(int a, int b)
    {
        if (b == 0) throw new DivideByZeroException("Cannot divide by zero.");
        return a / b;
    }
    static int Modulo(int a, int b) => a % b;
    static int Power(int a, int b)  => (int)Math.Pow(a, b);

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P12  |  Math Delegate (int, int) → int  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        int x = 20, y = 4;
        Console.WriteLine($"  x = {x},  y = {y}\n");

        // Named method delegates
        Calculator.Show(x, y, Add,        "+  (named)");
        Calculator.Show(x, y, Subtract,   "-  (named)");
        Calculator.Show(x, y, Multiply,   "*  (named)");
        Calculator.Show(x, y, SafeDivide, "/  (named)");
        Calculator.Show(x, y, Modulo,     "%  (named)");
        Calculator.Show(x, y, Power,      "^  (named)");

        // Lambda delegates
        Console.WriteLine("\n  Lambda operations:");
        Calculator.Show(x, y, (a, b) => a + b,              "+  (lambda)");
        Calculator.Show(x, y, (a, b) => Math.Max(a, b),     "max(lambda)");
        Calculator.Show(x, y, (a, b) => Math.Abs(a - b),    "|a-b|(lambda)");
        Calculator.Show(x, y, (a, b) => a * a + b * b,      "a²+b²(lambda)");

        // Switch delegate at runtime
        Console.WriteLine("\n  Switch operation via delegate variable:");
        MathOperation op = Add;
        Console.WriteLine($"  op=Add:      Compute(10, 3) = {Calculator.Compute(10, 3, op)}");
        op = Multiply;
        Console.WriteLine($"  op=Multiply: Compute(10, 3) = {Calculator.Compute(10, 3, op)}");
        op = (a, b) => a - b * 2;
        Console.WriteLine($"  op=custom:   Compute(10, 3) = {Calculator.Compute(10, 3, op)}");

        // Division by zero safety
        Console.WriteLine("\n  Safe divide by zero:");
        try { Calculator.Show(10, 0, SafeDivide, "/"); }
        catch (DivideByZeroException ex) { Console.WriteLine($"  Exception: {ex.Message}"); }

        Console.WriteLine("\n  Q: How do delegates promote reusability?");
        Console.WriteLine("  Compute(a, b, op) is written once. Any math operation —");
        Console.WriteLine("  now or future — plugs in without touching Compute().\n");
    }
}
