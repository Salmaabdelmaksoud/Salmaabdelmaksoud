// ============================================================
//  Part01 – P15 | Action<T> delegate — print each string
//  Q: Why is Action preferred for void operations?
// ============================================================
namespace P15_ActionDelegate;

public static class ListHelper
{
    // Apply an Action to each item — void, no return
    public static void ForEach<T>(List<T> source, Action<T> action)
    {
        foreach (var item in source)
            action(item);
    }

    // Apply action with index
    public static void ForEachIndexed<T>(List<T> source, Action<T, int> action)
    {
        for (int i = 0; i < source.Count; i++)
            action(source[i], i);
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P15  |  Action<T> Delegate              ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        List<string> words = new() { "apple", "banana", "cherry", "date", "elderberry" };

        // Basic print
        Console.WriteLine("  Action: print each string");
        Action<string> print = s => Console.WriteLine($"  → {s}");
        ListHelper.ForEach(words, print);

        // Uppercase print
        Console.WriteLine("\n  Action: print uppercase");
        ListHelper.ForEach(words, s => Console.WriteLine($"  → {s.ToUpper()}"));

        // Print with length
        Console.WriteLine("\n  Action: print with length");
        ListHelper.ForEach(words, s => Console.WriteLine($"  → {s,-15} (len={s.Length})"));

        // Print with index
        Console.WriteLine("\n  Action with index:");
        ListHelper.ForEachIndexed(words, (s, i) =>
            Console.WriteLine($"  [{i}] {s}"));

        // Action<int> — apply to numbers
        List<int> nums = new() { 1, 4, 9, 16, 25 };
        Console.WriteLine("\n  Action<int> — print sqrt:");
        ListHelper.ForEach(nums, n =>
            Console.WriteLine($"  sqrt({n,2}) = {Math.Sqrt(n):F3}"));

        // Multicast action
        Console.WriteLine("\n  Multicast Action (two side effects at once):");
        Action<string> multi = s => Console.Write($"  UPPER: {s.ToUpper()}");
        multi += s => Console.WriteLine($"   | reversed: {new string(s.Reverse().ToArray())}");
        ListHelper.ForEach(words.Take(3).ToList(), multi);

        Console.WriteLine("\n  Q: Why is Action preferred for void operations?");
        Console.WriteLine("  Action clearly communicates 'this has a side effect, no return'.");
        Console.WriteLine("  Using Func<T,Unit> or returning null would be misleading.");
        Console.WriteLine("  Action chains naturally for multicast (logging, event handling).\n");
    }
}
