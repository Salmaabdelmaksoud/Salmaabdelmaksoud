// ============================================================
//  Part01 – P17 | Anonymous function — filter strings by condition
//  Q: How do anonymous functions improve code modularity?
// ============================================================
namespace P17_AnonFilter;

public static class ListHelper
{
    public static List<T> Filter<T>(List<T> source, Func<T, bool> condition)
    {
        var result = new List<T>();
        foreach (var item in source)
            if (condition(item)) result.Add(item);
        return result;
    }
}

class Program
{
    static void Show(List<string> list, string label)
    {
        Console.Write($"  {label,-36}: ");
        Console.WriteLine("[" + string.Join(", ", list) + "]");
    }

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P17  |  Anonymous Function Filter       ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        List<string> words = new()
        {
            "apple", "avocado", "banana", "blueberry", "cherry",
            "date", "elderberry", "fig", "grape", "honeydew"
        };
        Show(words, "Source");
        Console.WriteLine();

        // Anonymous functions assigned to variables
        Func<string, bool> startsWithA = delegate(string s) { return s.StartsWith('a'); };
        Func<string, bool> containsE   = delegate(string s) { return s.Contains('e'); };
        Func<string, bool> longWords   = delegate(string s) { return s.Length > 6; };
        Func<string, bool> shortWords  = delegate(string s) { return s.Length <= 4; };
        Func<string, bool> endsWithY   = delegate(string s) { return s.EndsWith('y'); };

        Show(ListHelper.Filter(words, startsWithA), "Starts with 'a' (anon)");
        Show(ListHelper.Filter(words, containsE),   "Contains 'e'    (anon)");
        Show(ListHelper.Filter(words, longWords),    "Length > 6      (anon)");
        Show(ListHelper.Filter(words, shortWords),   "Length <= 4     (anon)");
        Show(ListHelper.Filter(words, endsWithY),    "Ends with 'y'   (anon)");

        // Inline anonymous functions
        Console.WriteLine();
        Show(ListHelper.Filter(words, delegate(string s) { return s.Contains("an"); }),
             "Contains 'an'  (inline)");

        Show(ListHelper.Filter(words, delegate(string s) { return s[0] == s[^1]; }),
             "First==Last char (inline)");

        // Combine conditions manually inside anonymous func
        Show(ListHelper.Filter(words, delegate(string s)
        {
            return s.StartsWith('b') && s.Length > 6;
        }), "Starts 'b' AND len > 6");

        Console.WriteLine("\n  Q: How do anonymous functions improve modularity?");
        Console.WriteLine("  The condition logic lives exactly where it is used.");
        Console.WriteLine("  No need to create a named method for a one-off filter.");
        Console.WriteLine("  Filter() is reusable across any condition without changing.\n");
    }
}
