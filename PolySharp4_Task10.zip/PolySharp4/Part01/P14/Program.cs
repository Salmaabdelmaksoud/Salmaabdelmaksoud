// ============================================================
//  Part01 – P14 | Func<T,TResult> — square each int in list
//  Q: How does Func simplify delegate creation and usage?
// ============================================================
namespace P14_FuncSquare;

public static class ListProcessor
{
    // Applies any Func<T,R> to each element
    public static List<R> Apply<T, R>(List<T> source, Func<T, R> selector)
    {
        var result = new List<R>(source.Count);
        foreach (var item in source)
            result.Add(selector(item));
        return result;
    }

    // Overload: apply in-place and return same list type
    public static List<T> ApplyInPlace<T>(List<T> source, Func<T, T> mutator)
    {
        var result = new List<T>(source.Count);
        foreach (var item in source) result.Add(mutator(item));
        return result;
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P14  |  Func<int,int> — Square          ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        List<int> nums = new() { 1, 2, 3, 4, 5, 6, 7, 8 };
        Console.WriteLine($"  Original:  [{string.Join(", ", nums)}]");

        // Square — Func<int,int>
        Func<int, int> square = x => x * x;
        List<int> squares = ListProcessor.Apply(nums, square);
        Console.WriteLine($"  Squared:   [{string.Join(", ", squares)}]");

        // Cube
        Func<int, int> cube = x => x * x * x;
        List<int> cubes = ListProcessor.Apply(nums, cube);
        Console.WriteLine($"  Cubed:     [{string.Join(", ", cubes)}]");

        // Square root → double
        Func<int, double> sqrt = x => Math.Sqrt(x);
        List<double> sqrts = ListProcessor.Apply(nums, sqrt);
        Console.WriteLine($"  Sqrt:      [{string.Join(", ", sqrts.Select(d => $"{d:F2}"))}]");

        // Is even? → bool
        Func<int, bool> isEven = x => x % 2 == 0;
        List<bool> evens = ListProcessor.Apply(nums, isEven);
        Console.WriteLine($"  Even?:     [{string.Join(", ", evens)}]");

        // Int → string
        Func<int, string> toStr = x => $"#{x}";
        List<string> labels = ListProcessor.Apply(nums, toStr);
        Console.WriteLine($"  Labels:    [{string.Join(", ", labels)}]");

        // Doubles
        List<double> dblNums = new() { 1.5, 2.5, 3.0, 4.5 };
        Func<double, double> sqDbl = x => x * x;
        Console.WriteLine($"\n  Double squares: [{string.Join(", ", ListProcessor.Apply(dblNums, sqDbl).Select(d => $"{d:F2}"))}]");

        // Sum of squares using Func result
        int sumOfSquares = squares.Sum();
        Console.WriteLine($"\n  Sum of squares (1²+2²+...+8²) = {sumOfSquares}");

        Console.WriteLine("\n  Q: How does Func simplify delegates?");
        Console.WriteLine("  Func<T,TResult> is built-in — no 'delegate int Square(int x)'");
        Console.WriteLine("  declaration needed. Lambda expression assigns instantly.");
        Console.WriteLine("  Readable, composable, and recognized across all .NET libraries.\n");
    }
}
