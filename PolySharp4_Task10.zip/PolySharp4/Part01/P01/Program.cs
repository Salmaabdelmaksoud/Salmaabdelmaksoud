// ============================================================
//  Part01 – P01 | SortingAlgorithm<T> — Employee sorted by Salary
//  Q: Benefits of generic sorting over non-generic?
// ============================================================
namespace P01_GenericSort;

public class Employee : IComparable<Employee>
{
    public int    Id     { get; }
    public string Name   { get; }
    public double Salary { get; }

    public Employee(int id, string name, double salary)
    { Id = id; Name = name; Salary = salary; }

    public int CompareTo(Employee? other)
    {
        if (other is null) return 1;
        return Salary.CompareTo(other.Salary);  // ascending by salary
    }

    public override string ToString()
        => $"  [{Id}] {Name,-18} Salary = {Salary,10:C}";
}

// Generic bubble-sort — T must support ordering via IComparable<T>
public class SortingAlgorithm<T> where T : IComparable<T>
{
    private readonly T[] _data;
    public SortingAlgorithm(T[] data) { _data = data; }

    public void Sort()
    {
        int n = _data.Length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (_data[j].CompareTo(_data[j + 1]) > 0)
                    (_data[j], _data[j + 1]) = (_data[j + 1], _data[j]);
    }

    public void Print(string label = "")
    {
        if (!string.IsNullOrEmpty(label))
            Console.WriteLine($"\n  {label}:");
        foreach (var item in _data)
            Console.WriteLine(item);
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P01  |  Generic Sort — Employee Salary  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝");

        Employee[] employees =
        {
            new Employee(1, "Ahmed Hassan",  14_500),
            new Employee(2, "Sara Mohamed",   8_200),
            new Employee(3, "Karim Ali",     22_000),
            new Employee(4, "Layla Tarek",   11_750),
            new Employee(5, "Omar Saeed",    18_300),
        };

        var sorter = new SortingAlgorithm<Employee>(employees);
        sorter.Print("Before sort");
        sorter.Sort();
        sorter.Print("After sort — ascending by Salary");

        // Same algorithm on int[] — no code change needed
        Console.WriteLine();
        int[] nums = { 64, 25, 12, 22, 11 };
        var intSorter = new SortingAlgorithm<int>(nums);
        intSorter.Print("Same generic sort on int[]  (before)");
        intSorter.Sort();
        intSorter.Print("Sorted ints");

        Console.WriteLine("\n  Q: Benefits of generic sorting?");
        Console.WriteLine("  One SortingAlgorithm<T> handles Employee, int, double, string");
        Console.WriteLine("  — anything with IComparable<T>. Zero code duplication,");
        Console.WriteLine("  full compile-time type safety, no boxing for value types.\n");
    }
}
