// ================================================================
//  Problem 01 – Car Class with Multiple Constructors
//  Topic      : Constructors & Constructor Overloading
// ================================================================

namespace Problem01_Car;

// ── Car Class ───────────────────────────────────────────────────
public class Car
{
    public int    Id    { get; set; }
    public string Brand { get; set; }
    public double Price { get; set; }

    /// <summary>1. Default constructor – no parameters</summary>
    public Car()
    {
        Id    = 0;
        Brand = "Unknown";
        Price = 0.0;
    }

    /// <summary>2. Constructor with one parameter (Id)</summary>
    public Car(int id)
    {
        Id    = id;
        Brand = "Unknown";
        Price = 0.0;
    }

    /// <summary>3. Constructor with two parameters (Id, Brand)</summary>
    public Car(int id, string brand)
    {
        Id    = id;
        Brand = brand;
        Price = 0.0;
    }

    /// <summary>4. Constructor with all three parameters</summary>
    public Car(int id, string brand, double price)
    {
        Id    = id;
        Brand = brand;
        Price = price;
    }

    public override string ToString()
        => $"| Id: {Id,-3} | Brand: {Brand,-10} | Price: {Price,10:C} |";
}

// ── Program Entry Point ─────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 01 – Car Class: Multiple Constructors  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Car c1 = new Car();                          // default
        Car c2 = new Car(1);                         // one param
        Car c3 = new Car(2, "Toyota");               // two params
        Car c4 = new Car(3, "BMW", 75_000.00);       // all three

        Console.WriteLine("Constructor Used          | Result");
        Console.WriteLine(new string('-', 60));
        Console.WriteLine($"Default                   {c1}");
        Console.WriteLine($"One param   (Id)          {c2}");
        Console.WriteLine($"Two params  (Id, Brand)   {c3}");
        Console.WriteLine($"All params                {c4}");

        Console.WriteLine("\n[Q] Why does a custom constructor suppress the default?");
        Console.WriteLine("    Because the C# compiler only auto-generates a default");
        Console.WriteLine("    constructor when NO constructor is defined. Once you");
        Console.WriteLine("    write any custom constructor, you must explicitly add");
        Console.WriteLine("    the default one if you still need it.\n");
    }
}
