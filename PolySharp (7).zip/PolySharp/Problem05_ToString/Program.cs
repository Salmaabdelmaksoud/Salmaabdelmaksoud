// ================================================================
//  Problem 05 – Overriding ToString() and Polymorphism
//  Topic      : ToString() Override, Runtime Polymorphism
// ================================================================

namespace Problem05_ToString;

// ── Parent Class ─────────────────────────────────────────────────
public class Parent
{
    public int X { get; set; }
    public int Y { get; set; }

    public Parent(int x, int y) { X = x; Y = y; }

    /// <summary>Returns (X, Y) representation.</summary>
    public override string ToString() => $"({X}, {Y})";
}

// ── Child Class ──────────────────────────────────────────────────
public class Child : Parent
{
    public int Z { get; set; }

    public Child(int x, int y, int z) : base(x, y) { Z = z; }

    /// <summary>Returns (X, Y, Z) representation.</summary>
    public override string ToString() => $"({X}, {Y}, {Z})";
}

// ── Program Entry Point ──────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 05 – ToString() & Polymorphism         ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Parent p = new Parent(1, 2);
        Child  c = new Child(1, 2, 3);

        Console.WriteLine($"Parent instance  : {p}");
        Console.WriteLine($"Child  instance  : {c}");

        // ── Polymorphism – Parent reference, Child object ─────────
        Console.WriteLine("\n─── Polymorphism (Parent ref → Child object) ───");
        Parent poly = new Child(5, 6, 7);
        Console.WriteLine($"poly.ToString()  : {poly}");   // Child's ToString() called!

        // ── Mixed polymorphic list ────────────────────────────────
        Console.WriteLine("\n─── Mixed List (polymorphic) ───");
        List<Parent> list = new()
        {
            new Parent(10, 20),
            new Child(1, 2, 3),
            new Child(4, 5, 6)
        };

        foreach (var item in list)
            Console.WriteLine($"  {item.GetType().Name,-8} → {item}");

        Console.WriteLine("\n[Q] Why override ToString()?");
        Console.WriteLine("    Default returns 'Namespace.ClassName' – useless for debugging.");
        Console.WriteLine("    Overriding integrates automatically with Console.WriteLine,");
        Console.WriteLine("    string interpolation, and logging without extra effort.\n");
    }
}
