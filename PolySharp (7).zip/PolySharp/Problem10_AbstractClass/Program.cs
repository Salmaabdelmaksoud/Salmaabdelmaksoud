// ================================================================
//  Problem 10 – Abstract Class: virtual vs abstract Methods
//  Topic      : Abstract Classes, Virtual Dispatch, Polymorphism
// ================================================================

namespace Problem10_AbstractClass;

// ── Abstract Base Class ──────────────────────────────────────────
public abstract class Shape
{
    /// <summary>
    /// VIRTUAL – has a default body.
    /// Derived classes MAY override it; if not, this runs.
    /// </summary>
    public virtual void Draw()
        => Console.WriteLine($"  [Shape.Draw] Drawing a generic shape");

    /// <summary>
    /// ABSTRACT – NO body.
    /// Every concrete derived class MUST implement this.
    /// </summary>
    public abstract double CalculateArea();

    /// <summary>Concrete helper – available to all derived classes.</summary>
    public void PrintInfo()
        => Console.WriteLine($"  Type: {GetType().Name,-12}  |  Area: {CalculateArea(),10:F4}");
}

// ── Rectangle : Shape ────────────────────────────────────────────
public class Rectangle : Shape
{
    public double Width  { get; }
    public double Height { get; }

    public Rectangle(double width, double height)
    {
        Width  = width;
        Height = height;
    }

    // Overrides virtual Draw()
    public override void Draw()
        => Console.WriteLine($"  [Rectangle.Draw] ▭  {Width} × {Height}");

    // Implements abstract CalculateArea()
    public override double CalculateArea() => Width * Height;
}

// ── Circle : Shape ────────────────────────────────────────────────
public class Circle : Shape
{
    public double Radius { get; }

    public Circle(double radius) { Radius = radius; }

    // Does NOT override Draw() → base Shape.Draw() runs
    // Implements abstract CalculateArea()
    public override double CalculateArea() => Math.PI * Radius * Radius;
}

// ── Triangle : Shape ─────────────────────────────────────────────
public class Triangle : Shape
{
    public double Base   { get; }
    public double Height { get; }

    public Triangle(double b, double h) { Base = b; Height = h; }

    public override void Draw()
        => Console.WriteLine($"  [Triangle.Draw]  △  base={Base}, height={Height}");

    public override double CalculateArea() => 0.5 * Base * Height;
}

// ── Program Entry Point ──────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 10 – Abstract Class                    ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // Individual objects
        Shape rect     = new Rectangle(6, 4);
        Shape circle   = new Circle(5);
        Shape triangle = new Triangle(8, 3);

        Console.WriteLine("── Individual shapes ──");
        rect.Draw();     rect.PrintInfo();
        Console.WriteLine();
        circle.Draw();   circle.PrintInfo();   // uses base Draw()
        Console.WriteLine();
        triangle.Draw(); triangle.PrintInfo();

        // Polymorphic list
        Console.WriteLine("\n── Polymorphic List ──");
        List<Shape> shapes = new()
        {
            new Rectangle(3, 2),
            new Circle(4),
            new Triangle(10, 6),
            new Rectangle(7, 5)
        };

        foreach (var s in shapes)
        {
            s.Draw();
            Console.WriteLine($"    → Area = {s.CalculateArea():F2}\n");
        }

        Console.WriteLine("[Q] virtual vs abstract?");
        Console.WriteLine("    virtual  → has default body; derived classes MAY override.");
        Console.WriteLine("    abstract → no body; derived classes MUST override.\n");
    }
}
