// ================================================================
//  Problem 04 – new vs override in Method Overriding
//  Topic      : Polymorphism – Hiding vs True Override
// ================================================================

namespace Problem04_NewVsOverride;

// ── Base Class ───────────────────────────────────────────────────
public class Parent
{
    public int X { get; set; }
    public int Y { get; set; }

    public Parent(int x, int y) { X = x; Y = y; }

    /// <summary>Virtual – can be overridden or hidden by derived classes.</summary>
    public virtual int Product()
    {
        Console.WriteLine("  [Parent.Product] called");
        return X * Y;
    }
}

// ── Child using 'new' (HIDES base – no runtime polymorphism) ─────
public class ChildNew : Parent
{
    public ChildNew(int x, int y) : base(x, y) { }

    /// <summary>
    /// 'new' hides the base method.
    /// When accessed via a Parent reference → Parent.Product() runs!
    /// </summary>
    public new int Product()
    {
        Console.WriteLine("  [ChildNew.Product] called  (new – hides base)");
        return X * Y * 10;
    }
}

// ── Child using 'override' (TRUE runtime polymorphism) ───────────
public class ChildOverride : Parent
{
    public ChildOverride(int x, int y) : base(x, y) { }

    /// <summary>
    /// 'override' replaces the virtual method in the vtable.
    /// Even through a Parent reference → ChildOverride.Product() runs!
    /// </summary>
    public override int Product()
    {
        Console.WriteLine("  [ChildOverride.Product] called  (override – true polymorphism)");
        return X * Y * 10;
    }
}

// ── Program Entry Point ──────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 04 – new vs override                   ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // ── Direct child-type reference (both behave the same) ────
        Console.WriteLine("─── Direct (child-type) reference ───");
        ChildNew      cn = new ChildNew(3, 4);
        ChildOverride co = new ChildOverride(3, 4);

        Console.Write("ChildNew.Product()      = ");
        Console.WriteLine(cn.Product());       // 120

        Console.Write("ChildOverride.Product() = ");
        Console.WriteLine(co.Product());       // 120

        // ── Parent reference ← THIS is where they differ! ────────
        Console.WriteLine("\n─── Parent reference (polymorphism test) ───");
        Parent pNew      = new ChildNew(3, 4);
        Parent pOverride = new ChildOverride(3, 4);

        Console.Write("pNew.Product()      = ");
        Console.WriteLine(pNew.Product());      // 12  ← Parent version called!

        Console.Write("pOverride.Product() = ");
        Console.WriteLine(pOverride.Product()); // 120 ← Child version called!

        Console.WriteLine("\n  'new'      → compile-time binding, hides base, breaks polymorphism.");
        Console.WriteLine("  'override' → runtime  binding, replaces base, enables polymorphism.\n");
    }
}
