# PolySharp 🔷
### C# OOP – Task 7 | Full Assignment Solution

---

## 🚀 How to Run in Visual Studio

1. **Extract** this ZIP anywhere on your PC
2. **Double-click** `PolySharp.sln` → opens in Visual Studio 2022
3. In **Solution Explorer**, right-click any project → **Set as Startup Project**
4. Press **Ctrl + F5** to run without debugging

## 📁 Projects

| # | Project | Topic |
|---|---------|-------|
| 01 | `Problem01_Car` | Multiple constructors |
| 02 | `Problem02_Calculator` | Method overloading |
| 03 | `Problem03_ConstructorChaining` | base() chaining |
| 04 | `Problem04_NewVsOverride` | new vs override |
| 05 | `Problem05_ToString` | ToString() + polymorphism |
| 06 | `Problem06_IShape` | Interface + Rectangle |
| 07 | `Problem07_DefaultInterface` | C# 8 default methods |
| 08 | `Problem08_IMovable` | Interface reference |
| 09 | `Problem09_MultipleInterfaces` | IReadable + IWritable |
| 10 | `Problem10_AbstractClass` | virtual vs abstract |

## 🛠 Requirements
- .NET 8 SDK
- Visual Studio 2022 (Community / Professional / Enterprise)
