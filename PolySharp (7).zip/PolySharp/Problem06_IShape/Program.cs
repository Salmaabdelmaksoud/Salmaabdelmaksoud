// ================================================================
//  Problem 06 – IShape Interface with Rectangle
//  Topic      : Interfaces – Contract Definition & Implementation
// ================================================================

namespace Problem06_IShape;

// ── Interface ────────────────────────────────────────────────────
public interface IShape
{
    /// <summary>Get-only property – Area must be computed by implementor.</summary>
    double Area { get; }

    /// <summary>Every shape must know how to draw itself.</summary>
    void Draw();
}

// ── Rectangle : IShape ───────────────────────────────────────────
public class Rectangle : IShape
{
    public double Width  { get; }
    public double Height { get; }

    public Rectangle(double width, double height)
    {
        Width  = width;
        Height = height;
    }

    public double Area => Width * Height;

    public void Draw()
        => Console.WriteLine($"  ┌{'─',1}{'─' * (int)Width}┐\n" +
                             $"  │  Rectangle {Width} × {Height}  │\n" +
                             $"  └{'─',1}{'─' * (int)Width}┘");
}

// ── Triangle : IShape ────────────────────────────────────────────
public class Triangle : IShape
{
    public double Base   { get; }
    public double Height { get; }

    public Triangle(double b, double h) { Base = b; Height = h; }

    public double Area => 0.5 * Base * Height;

    public void Draw()
        => Console.WriteLine($"  △ Triangle  base={Base}, height={Height}");
}

// ── Program Entry Point ──────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 06 – IShape Interface                  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        IShape rect     = new Rectangle(5, 3);
        IShape triangle = new Triangle(6, 4);

        Console.WriteLine("── Rectangle ──");
        rect.Draw();
        Console.WriteLine($"  Area = {rect.Area}\n");

        Console.WriteLine("── Triangle ──");
        triangle.Draw();
        Console.WriteLine($"  Area = {triangle.Area}\n");

        Console.WriteLine("[Q] Why can't you instantiate an interface directly?");
        Console.WriteLine("    An interface has no fields, no constructor, no memory layout.");
        Console.WriteLine("    It is a pure contract. Only concrete classes provide the");
        Console.WriteLine("    actual code that gives the interface meaning.\n");
    }
}
