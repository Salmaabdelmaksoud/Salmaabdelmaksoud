// ================================================================
//  Problem 09 – Multiple Interface Implementation
//  Topic      : IReadable + IWritable  →  DataFile class
// ================================================================

namespace Problem09_MultipleInterfaces;

// ── Interfaces ───────────────────────────────────────────────────
public interface IReadable
{
    string Read();
}

public interface IWritable
{
    void Write(string data);
}

// ── DataFile implements BOTH interfaces ──────────────────────────
public class DataFile : IReadable, IWritable
{
    public  string Name    { get; }
    private string _buffer = string.Empty;

    public DataFile(string name) { Name = name; }

    public void Write(string data)
    {
        _buffer = data;
        Console.WriteLine($"  [WRITE] → {Name}  :  \"{data}\"");
    }

    public string Read()
    {
        Console.WriteLine($"  [READ ] ← {Name}  :  \"{_buffer}\"");
        return _buffer;
    }
}

// ── Program Entry Point ──────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 09 – Multiple Interface Implementation  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        DataFile file = new DataFile("report.txt");

        // Use via concrete type
        Console.WriteLine("── Using concrete type ──");
        file.Write("Hello, PolySharp!");
        file.Read();

        // Use via IWritable reference only
        Console.WriteLine("\n── IWritable reference (write-only view) ──");
        IWritable writer = file;
        writer.Write("Updated content at " + DateTime.Now.ToShortTimeString());

        // Use via IReadable reference only
        Console.WriteLine("\n── IReadable reference (read-only view) ──");
        IReadable reader = file;
        string content = reader.Read();
        Console.WriteLine($"  Retrieved: \"{content}\"");

        Console.WriteLine("\n[Q] How does C# overcome single inheritance with interfaces?");
        Console.WriteLine("    A class can implement unlimited interfaces, composing");
        Console.WriteLine("    multiple capabilities cleanly without the diamond problem.\n");
    }
}
