// ================================================================
//  Problem 03 – Constructor Chaining with base()
//  Topic      : Inheritance & Constructor Chaining
// ================================================================

namespace Problem03_ConstructorChaining;

// ── Parent Class ─────────────────────────────────────────────────
public class Parent
{
    public int X { get; set; }
    public int Y { get; set; }

    public Parent(int x, int y)
    {
        X = x;
        Y = y;
        Console.WriteLine($"  >> Parent constructor fired  →  X={X}, Y={Y}");
    }

    public override string ToString() => $"Parent(X={X}, Y={Y})";
}

// ── Child Class ──────────────────────────────────────────────────
public class Child : Parent
{
    public int Z { get; set; }

    /// <summary>
    /// Chains to Parent(x, y) via base() BEFORE executing its own body.
    /// Execution order: base constructor first → then child body.
    /// </summary>
    public Child(int x, int y, int z) : base(x, y)
    {
        Z = z;
        Console.WriteLine($"  >> Child  constructor fired  →  Z={Z}");
    }

    public override string ToString() => $"Child(X={X}, Y={Y}, Z={Z})";
}

// ── Program Entry Point ──────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 03 – Constructor Chaining with base()  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Console.WriteLine("Creating: new Child(1, 2, 3)\n");
        Child child = new Child(1, 2, 3);

        Console.WriteLine($"\nFinal object → {child}");

        Console.WriteLine("\n[Q] What is the purpose of constructor chaining?");
        Console.WriteLine("    Ensures the base class initialises its own fields first.");
        Console.WriteLine("    Avoids duplicating initialisation code across constructors.\n");
    }
}
