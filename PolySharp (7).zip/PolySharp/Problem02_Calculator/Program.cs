// ================================================================
//  Problem 02 – Calculator with Overloaded Sum() Methods
//  Topic      : Method Overloading (Static / Compile-time Binding)
// ================================================================

namespace Problem02_Calculator;

// ── Calculator Class ─────────────────────────────────────────────
public class Calculator
{
    /// <summary>Overload 1 – Add two integers</summary>
    public int Sum(int a, int b)
    {
        Console.WriteLine($"  [Overload 1] Sum(int {a}, int {b})");
        return a + b;
    }

    /// <summary>Overload 2 – Add three integers</summary>
    public int Sum(int a, int b, int c)
    {
        Console.WriteLine($"  [Overload 2] Sum(int {a}, int {b}, int {c})");
        return a + b + c;
    }

    /// <summary>Overload 3 – Add two doubles</summary>
    public double Sum(double a, double b)
    {
        Console.WriteLine($"  [Overload 3] Sum(double {a}, double {b})");
        return a + b;
    }
}

// ── Program Entry Point ──────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 02 – Calculator: Method Overloading    ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        Calculator calc = new Calculator();

        Console.WriteLine("Calling Sum(3, 5):");
        Console.WriteLine($"  Result = {calc.Sum(3, 5)}\n");

        Console.WriteLine("Calling Sum(1, 2, 3):");
        Console.WriteLine($"  Result = {calc.Sum(1, 2, 3)}\n");

        Console.WriteLine("Calling Sum(2.5, 3.7):");
        Console.WriteLine($"  Result = {calc.Sum(2.5, 3.7)}\n");

        Console.WriteLine("[Q] How does overloading improve readability?");
        Console.WriteLine("    One intuitive name (Sum) works for all cases.");
        Console.WriteLine("    The compiler picks the right overload automatically.\n");
    }
}
