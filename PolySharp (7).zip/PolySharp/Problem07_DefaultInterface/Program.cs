// ================================================================
//  Problem 07 – Default Interface Method (C# 8.0)
//  Topic      : Default Interface Implementations
// ================================================================

namespace Problem07_DefaultInterface;

// ── Interface with default method ────────────────────────────────
public interface IShape
{
    double Area { get; }
    void Draw();

    /// <summary>
    /// Default implementation introduced in C# 8.0.
    /// Implementors get this for free; they may override it.
    /// </summary>
    void PrintDetails()
        => Console.WriteLine($"  [Default] Shape  |  Area = {Area:F4}");
}

// ── Circle – uses the DEFAULT PrintDetails() ─────────────────────
public class Circle : IShape
{
    public double Radius { get; }

    public Circle(double radius) { Radius = radius; }

    public double Area => Math.PI * Radius * Radius;

    public void Draw()
        => Console.WriteLine($"  ○  Circle  (radius = {Radius})");

    // No PrintDetails() – uses the default from IShape
}

// ── Rectangle – OVERRIDES PrintDetails() ─────────────────────────
public class Rectangle : IShape
{
    public double Width  { get; }
    public double Height { get; }

    public Rectangle(double w, double h) { Width = w; Height = h; }

    public double Area => Width * Height;

    public void Draw()
        => Console.WriteLine($"  ▭  Rectangle  ({Width} × {Height})");

    /// <summary>Custom override of the default implementation.</summary>
    public void PrintDetails()
        => Console.WriteLine($"  [Custom ] Rectangle  |  Width={Width}  Height={Height}  Area={Area:F2}");
}

// ── Program Entry Point ──────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 07 – Default Interface Method (C# 8)   ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        IShape circle = new Circle(4);
        circle.Draw();
        circle.PrintDetails();     // → uses IShape default

        Console.WriteLine();

        IShape rect = new Rectangle(5, 3);
        rect.Draw();
        rect.PrintDetails();       // → uses Rectangle's own override

        Console.WriteLine("\n[Q] Benefits of default interface methods?");
        Console.WriteLine("    Evolve interfaces without breaking existing implementors.");
        Console.WriteLine("    Ship new shared behaviour free – no abstract base class needed.\n");
    }
}
