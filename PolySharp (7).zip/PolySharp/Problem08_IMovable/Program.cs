// ================================================================
//  Problem 08 – IMovable Interface with Car
//  Topic      : Interface Reference & Runtime Polymorphism
// ================================================================

namespace Problem08_IMovable;

// ── Interface ────────────────────────────────────────────────────
public interface IMovable
{
    void Move();
}

// ── Car : IMovable ───────────────────────────────────────────────
public class Car : IMovable
{
    public string Brand { get; }
    private int _speed = 0;

    public Car(string brand) { Brand = brand; }

    public void Move()
    {
        _speed += 30;
        Console.WriteLine($"  🚗  {Brand,-10} is moving  →  speed = {_speed} km/h");
    }
}

// ── Drone : IMovable ─────────────────────────────────────────────
public class Drone : IMovable
{
    public string Model { get; }
    private int _altitude = 0;

    public Drone(string model) { Model = model; }

    public void Move()
    {
        _altitude += 10;
        Console.WriteLine($"  🚁  {Model,-10} is flying  →  altitude = {_altitude} m");
    }
}

// ── Program Entry Point ──────────────────────────────────────────
class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║    Problem 08 – IMovable Interface                ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // Interface reference → Car object
        IMovable vehicle = new Car("Tesla");
        vehicle.Move();
        vehicle.Move();

        Console.WriteLine();

        // Interface reference → Drone object (same code, different behaviour)
        IMovable drone = new Drone("DJI-Mini");
        drone.Move();
        drone.Move();

        // Polymorphic collection
        Console.WriteLine("\n─── Polymorphic IMovable list ───");
        List<IMovable> fleet = new()
        {
            new Car("Ford"),
            new Drone("Parrot"),
            new Car("Audi"),
            new Drone("Skydio")
        };

        foreach (var m in fleet)
            m.Move();

        Console.WriteLine("\n[Q] Why use an interface reference?");
        Console.WriteLine("    Decouples caller from implementation – works with any");
        Console.WriteLine("    future IMovable type without changing existing code.\n");
    }
}
