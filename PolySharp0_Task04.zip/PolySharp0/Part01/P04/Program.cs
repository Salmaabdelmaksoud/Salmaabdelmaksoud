// ============================================================
//  Part01 – P04 | 5 Array Methods: Sort, Reverse, IndexOf, Copy, Clear
//  Q: Array.Copy() vs Array.ConstrainedCopy()?
// ============================================================
namespace P04_ArrayMethods;

class Program
{
    static void Print(int[] arr, string label)
        => Console.WriteLine($"  {label,-34}: [{string.Join(", ", arr)}]");

    static void Sep() => Console.WriteLine("  " + new string('─', 52));

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P04  |  Array Methods Demo              ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        int[] arr = { 42, 17, 85, 3, 61, 29, 54, 8 };

        // ── 1. Array.Sort() ───────────────────────────────────────────
        Console.WriteLine("  1. Array.Sort()");
        int[] s = (int[])arr.Clone();
        Print(s, "Before Sort");
        Array.Sort(s);
        Print(s, "After Sort  (ascending)");
        Sep();

        // ── 2. Array.Reverse() ────────────────────────────────────────
        Console.WriteLine("\n  2. Array.Reverse()");
        int[] r = (int[])s.Clone();
        Print(r, "Before Reverse  (sorted)");
        Array.Reverse(r);
        Print(r, "After Reverse   (descending)");
        Sep();

        // ── 3. Array.IndexOf() ────────────────────────────────────────
        Console.WriteLine("\n  3. Array.IndexOf()");
        int[] sorted = (int[])arr.Clone();
        Array.Sort(sorted);
        Print(sorted, "Sorted array");
        int target1 = 29;
        int idx1 = Array.IndexOf(sorted, target1);
        Console.WriteLine($"  IndexOf({target1})    = {idx1}  (first occurrence)");

        // Add duplicate and show LastIndexOf
        int[] withDup = { 5, 10, 29, 20, 29, 30, 29 };
        Print(withDup, "Array with duplicates");
        int idxFirst = Array.IndexOf(withDup, 29);
        int idxLast  = Array.LastIndexOf(withDup, 29);
        Console.WriteLine($"  IndexOf(29)     = {idxFirst}  (first)");
        Console.WriteLine($"  LastIndexOf(29) = {idxLast}  (last)");
        Sep();

        // ── 4. Array.Copy() ───────────────────────────────────────────
        Console.WriteLine("\n  4. Array.Copy()");
        int[] src  = { 100, 200, 300, 400, 500 };
        int[] dst  = new int[5];
        Print(src, "Source before copy");
        Print(dst, "Destination before copy");
        Array.Copy(src, dst, src.Length);
        Print(dst, "Destination after Copy");

        // Partial copy
        int[] partDst = new int[8];
        Array.Copy(src, 1, partDst, 2, 3);   // 3 elements from src[1] → partDst[2]
        Print(partDst, "Partial copy (src[1..3]→dst[2])");
        Sep();

        // ── 5. Array.Clear() ──────────────────────────────────────────
        Console.WriteLine("\n  5. Array.Clear()");
        int[] c = { 10, 20, 30, 40, 50, 60 };
        Print(c, "Before Clear");
        Array.Clear(c, 1, 3);   // clear 3 elements starting at index 1
        Print(c, "After Clear(arr, 1, 3)  (zeroes [1..3])");

        int[] full = (int[])arr.Clone();
        Array.Clear(full);      // clear entire array
        Print(full, "After Clear(arr)  (entire array)");
        Sep();

        Console.WriteLine("\n  Q: Array.Copy() vs Array.ConstrainedCopy()?");
        Console.WriteLine("  Copy()            → copies elements, no type-safety guarantee.");
        Console.WriteLine("                      On failure, destination may be partially modified.");
        Console.WriteLine("  ConstrainedCopy() → all-or-nothing: if any element can't be copied,");
        Console.WriteLine("                      the destination is left UNCHANGED (rollback).");
        Console.WriteLine("                      Safer for reference-type arrays.\n");
    }
}
