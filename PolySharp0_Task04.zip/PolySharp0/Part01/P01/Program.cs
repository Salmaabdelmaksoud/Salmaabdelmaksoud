// ============================================================
//  Part01 – P01 | Array Initialization (3 ways) + IndexOutOfRange
//  Q: What is the default value of array elements in C#?
// ============================================================
namespace P01_ArrayInit;

class Program
{
    static void PrintArr(int[] arr, string label)
    {
        Console.Write($"  {label,-28}: [");
        Console.Write(string.Join(", ", arr));
        Console.WriteLine("]");
    }

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P01  |  Array Initialization            ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // ── Way 1: new int[size] ──────────────────────────────────────
        Console.WriteLine("  Way 1 — new int[5]  (default values are 0):");
        int[] arr1 = new int[5];
        PrintArr(arr1, "Before assignment");

        arr1[0] = 10;
        arr1[1] = 20;
        arr1[2] = 30;
        arr1[3] = 40;
        arr1[4] = 50;
        PrintArr(arr1, "After manual assignment");

        // ── Way 2: Initializer list ───────────────────────────────────
        Console.WriteLine("\n  Way 2 — new int[] { ... }  (initializer list):");
        int[] arr2 = new int[] { 15, 25, 35, 45, 55 };
        PrintArr(arr2, "Declared and initialized");

        // ── Way 3: Array syntax sugar ─────────────────────────────────
        Console.WriteLine("\n  Way 3 — { ... }  (syntax sugar shorthand):");
        int[] arr3 = { 100, 200, 300, 400, 500 };
        PrintArr(arr3, "Syntax sugar");

        // Default values for different types
        Console.WriteLine("\n  Default values in freshly allocated arrays:");
        int[]    defInt  = new int[3];
        double[] defDbl  = new double[3];
        bool[]   defBool = new bool[3];
        string[] defStr  = new string[3];   // null refs

        Console.WriteLine($"  int[]    → [{string.Join(", ", defInt)}]");
        Console.WriteLine($"  double[] → [{string.Join(", ", defDbl)}]");
        Console.WriteLine($"  bool[]   → [{string.Join(", ", defBool)}]");
        Console.WriteLine($"  string[] → [{string.Join(", ", defStr.Select(s => s ?? "null"))}]");

        // ── IndexOutOfRangeException ──────────────────────────────────
        Console.WriteLine($"\n  Demonstrating IndexOutOfRangeException:");
        Console.WriteLine($"  arr1.Length = {arr1.Length}  → valid indices: 0 to {arr1.Length - 1}");
        Console.WriteLine("  Accessing arr1[10] now...");
        try
        {
            int bad = arr1[10];
        }
        catch (IndexOutOfRangeException ex)
        {
            Console.WriteLine($"  *** Caught: {ex.GetType().Name}");
            Console.WriteLine($"  *** {ex.Message}");
        }

        Console.WriteLine("\n  Q: What is the default value of array elements?");
        Console.WriteLine("  Numeric types  → 0  (int, double, float, long…)");
        Console.WriteLine("  bool           → false");
        Console.WriteLine("  char           → '\\0' (null character, Unicode U+0000)");
        Console.WriteLine("  Reference types→ null  (string, object, any class)\n");
    }
}
