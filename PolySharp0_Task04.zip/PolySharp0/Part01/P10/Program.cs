// ============================================================
//  Part01 – P10 | Sum of array — for vs foreach + timing
//  Q: Which loop is more efficient for calculating the sum?
// ============================================================
namespace P10_SumLoops;

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P10  |  Sum with for vs foreach         ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        int[] numbers = { 15, 28, 43, 67, 91, 4, 52, 36, 88, 11 };
        Console.WriteLine("  Array: [" + string.Join(", ", numbers) + "]\n");

        // ── for loop sum ──────────────────────────────────────────────
        int sumFor = 0;
        for (int i = 0; i < numbers.Length; i++)
            sumFor += numbers[i];

        Console.WriteLine("  ── for loop ──");
        Console.Write("  Accumulation: ");
        int running = 0;
        for (int i = 0; i < numbers.Length; i++)
        {
            running += numbers[i];
            Console.Write($"{running}");
            if (i < numbers.Length - 1) Console.Write(" → ");
        }
        Console.WriteLine();
        Console.WriteLine($"  for loop sum  = {sumFor}");

        // ── foreach loop sum ──────────────────────────────────────────
        int sumForeach = 0;
        foreach (int n in numbers)
            sumForeach += n;

        Console.WriteLine("\n  ── foreach loop ──");
        Console.Write("  Elements seen: ");
        bool first = true;
        foreach (int n in numbers)
        {
            if (!first) Console.Write(", ");
            Console.Write(n);
            first = false;
        }
        Console.WriteLine();
        Console.WriteLine($"  foreach loop sum = {sumForeach}");

        Console.WriteLine($"\n  Both sums match: {sumFor == sumForeach}");

        // Extra stats
        double avg  = (double)sumFor / numbers.Length;
        int    minV = numbers.Min();
        int    maxV = numbers.Max();
        Console.WriteLine($"  Average = {avg:F2}");
        Console.WriteLine($"  Min     = {minV}");
        Console.WriteLine($"  Max     = {maxV}");

        // ── Timing comparison ─────────────────────────────────────────
        Console.WriteLine("\n  Timing comparison (50 million iterations on 10-element array):");

        int reps = 50_000_000;
        var sw = System.Diagnostics.Stopwatch.StartNew();
        long totalFor = 0;
        for (int r = 0; r < reps; r++)
            for (int i = 0; i < numbers.Length; i++)
                totalFor += numbers[i];
        sw.Stop();
        long msFor = sw.ElapsedMilliseconds;

        sw.Restart();
        long totalForeach = 0;
        for (int r = 0; r < reps; r++)
            foreach (int n in numbers)
                totalForeach += n;
        sw.Stop();

        Console.WriteLine($"  for     : {msFor,5} ms  (sum={totalFor})");
        Console.WriteLine($"  foreach : {sw.ElapsedMilliseconds,5} ms  (sum={totalForeach})");
        Console.WriteLine("  (Results vary per run; both are JIT-optimized similarly)");

        Console.WriteLine("\n  Q: Which loop is more efficient for array sum?");
        Console.WriteLine("  For an int[] the JIT treats them identically in Release mode.");
        Console.WriteLine("  foreach on arrays is optimised away to a direct indexed loop.");
        Console.WriteLine("  In Debug mode for is marginally faster due to bound checks.");
        Console.WriteLine("  Practically: prefer foreach for clarity; use for when you need");
        Console.WriteLine("  the index or fine control. The difference is negligible.\n");
    }
}
