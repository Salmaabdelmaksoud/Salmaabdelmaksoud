// ============================================================
//  Part01 – P02 | Shallow Copy vs Deep Copy (Clone / Array.Copy)
//  Q: What is the difference between Array.Clone() and Array.Copy()?
// ============================================================
namespace P02_ShallowDeepCopy;

class Program
{
    static void Print(int[] arr, string label)
        => Console.WriteLine($"  {label,-36}: [{string.Join(", ", arr)}]");

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P02  |  Shallow vs Deep Copy            ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // ── Shallow copy — just copies the reference, NOT the data ────
        Console.WriteLine("  ── SHALLOW COPY  (arr2 = arr1) ──");
        int[] arr1 = { 10, 20, 30, 40, 50 };
        int[] arr2 = arr1;   // both variables point to the SAME array in memory

        Print(arr1, "arr1 before");
        Print(arr2, "arr2 before  (same ref)");

        arr2[0] = 999;   // changing arr2 also changes arr1 — they share the object
        Console.WriteLine("\n  arr2[0] = 999  →  both arrays change:");
        Print(arr1, "arr1 AFTER  (also changed!)");
        Print(arr2, "arr2 AFTER");
        Console.WriteLine("  *** Shallow copy: both names point to the same data ***\n");

        // ── Deep copy using Clone() ───────────────────────────────────
        Console.WriteLine("  ── DEEP COPY via Clone() ──");
        int[] original = { 10, 20, 30, 40, 50 };
        int[] cloned   = (int[])original.Clone();  // new independent array on the heap

        Print(original, "original before");
        Print(cloned,   "cloned   before");

        cloned[0] = 777;
        Console.WriteLine("\n  cloned[0] = 777  →  only the clone changes:");
        Print(original, "original  (unchanged!)");
        Print(cloned,   "cloned    (modified)");
        Console.WriteLine("  *** Clone creates a completely separate copy ***\n");

        // ── Deep copy using Array.Copy() ──────────────────────────────
        Console.WriteLine("  ── DEEP COPY via Array.Copy() ──");
        int[] source = { 1, 2, 3, 4, 5 };
        int[] dest   = new int[5];
        Array.Copy(source, dest, source.Length);

        dest[2] = 300;
        Print(source, "source  (unchanged!)");
        Print(dest,   "dest    (modified)");

        // Partial copy demo
        Console.WriteLine("\n  Partial Array.Copy  (indices 1-3 only):");
        int[] partial = new int[5];
        Array.Copy(source, 1, partial, 1, 3);   // copy 3 elements starting at index 1
        Print(source,  "source");
        Print(partial, "partial  (only [1],[2],[3] filled)");

        Console.WriteLine("\n  Q: Array.Clone() vs Array.Copy()?");
        Console.WriteLine("  Clone()  → copies the WHOLE array into a NEW array object.");
        Console.WriteLine("             No destination needed; returns object (needs cast).");
        Console.WriteLine("  Copy()   → copies into an EXISTING destination array.");
        Console.WriteLine("             Supports partial copy with offset and length params.");
        Console.WriteLine("  Both are shallow for reference types (class objects inside).");
        Console.WriteLine("  For value-type arrays (int[]) both give full independent copies.\n");
    }
}
