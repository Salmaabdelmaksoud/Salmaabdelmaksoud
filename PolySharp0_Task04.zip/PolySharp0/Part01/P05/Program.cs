// ============================================================
//  Part01 – P05 | for / foreach / while loop comparison
//  Q: Why is foreach preferred for read-only array operations?
// ============================================================
namespace P05_LoopTypes;

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P05  |  Loop Types: for / foreach / while║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        int[] numbers = { 10, 25, 38, 47, 56, 63, 72, 89, 94, 100 };

        Console.WriteLine("  Array: [" + string.Join(", ", numbers) + "]\n");

        // ── 1. for loop ───────────────────────────────────────────────
        Console.WriteLine("  ── 1. for loop (index access) ──");
        Console.Write("  Elements: ");
        for (int i = 0; i < numbers.Length; i++)
        {
            Console.Write($"{numbers[i]}");
            if (i < numbers.Length - 1) Console.Write(", ");
        }
        Console.WriteLine();

        // for loop also lets you modify elements
        int[] doubled = new int[numbers.Length];
        for (int i = 0; i < numbers.Length; i++)
            doubled[i] = numbers[i] * 2;
        Console.WriteLine("  Doubled:  [" + string.Join(", ", doubled) + "]");

        // ── 2. foreach loop ───────────────────────────────────────────
        Console.WriteLine("\n  ── 2. foreach loop (read-only iteration) ──");
        Console.Write("  Elements: ");
        bool first = true;
        foreach (int n in numbers)
        {
            if (!first) Console.Write(", ");
            Console.Write(n);
            first = false;
        }
        Console.WriteLine();

        // Practical foreach — find max
        int max = numbers[0];
        foreach (int n in numbers)
            if (n > max) max = n;
        Console.WriteLine($"  Max value (foreach): {max}");

        // ── 3. while loop — reverse order ─────────────────────────────
        Console.WriteLine("\n  ── 3. while loop (reverse order) ──");
        Console.Write("  Reversed: ");
        int idx = numbers.Length - 1;
        bool firstW = true;
        while (idx >= 0)
        {
            if (!firstW) Console.Write(", ");
            Console.Write(numbers[idx]);
            firstW = false;
            idx--;
        }
        Console.WriteLine();

        // do-while variant
        Console.WriteLine("\n  ── 3b. do-while loop (always runs at least once) ──");
        int pos = numbers.Length - 1;
        Console.Write("  Reversed via do-while: ");
        bool fd = true;
        do
        {
            if (!fd) Console.Write(", ");
            Console.Write(numbers[pos]);
            fd = false;
            pos--;
        } while (pos >= 0);
        Console.WriteLine();

        // Performance note with timing
        Console.WriteLine("\n  Timing comparison (1 million iterations):");
        var sw = System.Diagnostics.Stopwatch.StartNew();
        long sumFor = 0;
        for (int rep = 0; rep < 1_000_000; rep++)
            for (int i = 0; i < numbers.Length; i++)
                sumFor += numbers[i];
        sw.Stop();
        long forMs = sw.ElapsedMilliseconds;

        sw.Restart();
        long sumForeach = 0;
        for (int rep = 0; rep < 1_000_000; rep++)
            foreach (int n in numbers)
                sumForeach += n;
        sw.Stop();

        Console.WriteLine($"  for     elapsed: {forMs} ms  (sum={sumFor})");
        Console.WriteLine($"  foreach elapsed: {sw.ElapsedMilliseconds} ms  (sum={sumForeach})");

        Console.WriteLine("\n  Q: Why is foreach preferred for read-only operations?");
        Console.WriteLine("  1. Cleaner syntax — no index variable, no off-by-one risk.");
        Console.WriteLine("  2. Works on any IEnumerable, not just arrays.");
        Console.WriteLine("  3. Compiler can prove you don't modify the collection — safer.");
        Console.WriteLine("  4. JIT optimizes foreach on arrays similarly to for.");
        Console.WriteLine("  Use for when you need the index, need to modify elements,");
        Console.WriteLine("  or need to iterate in non-sequential order.\n");
    }
}
