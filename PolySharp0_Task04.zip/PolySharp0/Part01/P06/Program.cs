// ============================================================
//  Part01 – P06 | Input Validation — do-while + int.TryParse
//  Q: Why is input validation important?
// ============================================================
namespace P06_InputValidation;

class Program
{
    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P06  |  Input Validation (do-while)     ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // ── Simulated input queue (so this runs non-interactively) ────
        // In real use: remove this queue and use Console.ReadLine() directly
        Queue<string> simulatedInput = new(new[] { "abc", "-3", "0", "4", "7" });

        static string ReadLine(Queue<string> q)
        {
            string val = q.Dequeue();
            Console.WriteLine($"  > {val}");   // echo the simulated input
            return val;
        }

        Console.WriteLine("  Enter a positive odd number (demo with preset inputs):\n");

        int validNumber;

        do
        {
            Console.Write("  Enter a positive odd number: ");
            string? raw = ReadLine(simulatedInput);

            // Step 1: parse check — is it even a number?
            if (!int.TryParse(raw, out int parsed))
            {
                Console.WriteLine("  ✗ Not a valid integer. Please try again.\n");
                continue;
            }

            // Step 2: positive check
            if (parsed <= 0)
            {
                Console.WriteLine($"  ✗ {parsed} is not positive. Must be > 0.\n");
                continue;
            }

            // Step 3: odd check
            if (parsed % 2 == 0)
            {
                Console.WriteLine($"  ✗ {parsed} is even. Must be an odd number.\n");
                continue;
            }

            // All checks passed
            validNumber = parsed;
            Console.WriteLine($"  ✓ {validNumber} is a valid positive odd number!\n");
            break;

        } while (true);

        Console.WriteLine($"  Accepted value: {validNumber}");
        Console.WriteLine($"  Its square    : {validNumber * validNumber}");

        // ── Show what breaks without validation ───────────────────────
        Console.WriteLine("\n  Why validation matters — without it:");
        Console.WriteLine("  string raw = Console.ReadLine();");
        Console.WriteLine("  int n = int.Parse(raw);   // crashes on 'abc'");
        Console.WriteLine("  int[] arr = new int[n];   // crashes on -3");
        Console.WriteLine("  arr[n % 2] = ...;         // wrong result on even n");

        Console.WriteLine("\n  Q: Why is input validation important?");
        Console.WriteLine("  1. Crash prevention — invalid input causes runtime exceptions.");
        Console.WriteLine("  2. Security — unvalidated input is the root of many exploits.");
        Console.WriteLine("  3. Data integrity — wrong data stored = corrupted results.");
        Console.WriteLine("  4. User experience — clear error messages instead of crashes.");
        Console.WriteLine("  int.TryParse returns false instead of throwing — the safe way.\n");
    }
}
