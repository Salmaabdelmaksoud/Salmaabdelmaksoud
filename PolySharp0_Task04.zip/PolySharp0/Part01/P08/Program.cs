// ============================================================
//  Part01 – P08 | Month Name — if-else vs switch statement
//  Q: When should you prefer switch over if-else?
// ============================================================
namespace P08_MonthName;

class Program
{
    // ── if-else version ───────────────────────────────────────────────
    static string GetMonthIfElse(int month)
    {
        if      (month == 1)  return "January";
        else if (month == 2)  return "February";
        else if (month == 3)  return "March";
        else if (month == 4)  return "April";
        else if (month == 5)  return "May";
        else if (month == 6)  return "June";
        else if (month == 7)  return "July";
        else if (month == 8)  return "August";
        else if (month == 9)  return "September";
        else if (month == 10) return "October";
        else if (month == 11) return "November";
        else if (month == 12) return "December";
        else                  return "Invalid month number";
    }

    // ── switch version ────────────────────────────────────────────────
    static string GetMonthSwitch(int month)
    {
        switch (month)
        {
            case 1:  return "January";
            case 2:  return "February";
            case 3:  return "March";
            case 4:  return "April";
            case 5:  return "May";
            case 6:  return "June";
            case 7:  return "July";
            case 8:  return "August";
            case 9:  return "September";
            case 10: return "October";
            case 11: return "November";
            case 12: return "December";
            default: return "Invalid month number";
        }
    }

    // ── switch expression version (C# 8+) ────────────────────────────
    static string GetMonthExpression(int month) => month switch
    {
        1  => "January",
        2  => "February",
        3  => "March",
        4  => "April",
        5  => "May",
        6  => "June",
        7  => "July",
        8  => "August",
        9  => "September",
        10 => "October",
        11 => "November",
        12 => "December",
        _  => "Invalid month number"
    };

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P08  |  Month Name — if-else vs switch  ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        int[] testMonths = { 1, 3, 6, 9, 12, 0, 13 };

        Console.WriteLine($"  {"Month",-6} {"if-else",-15} {"switch",-15} {"switch expr"}");
        Console.WriteLine("  " + new string('-', 55));

        foreach (int m in testMonths)
        {
            string ifElseResult = GetMonthIfElse(m);
            string switchResult = GetMonthSwitch(m);
            string exprResult   = GetMonthExpression(m);

            Console.WriteLine($"  {m,-6} {ifElseResult,-15} {switchResult,-15} {exprResult}");
        }

        // Grouped switch — quarters
        Console.WriteLine("\n  Bonus: Switch with grouped cases (quarters):");
        for (int m = 1; m <= 12; m++)
        {
            string quarter = m switch
            {
                1 or 2 or 3   => "Q1",
                4 or 5 or 6   => "Q2",
                7 or 8 or 9   => "Q3",
                10 or 11 or 12 => "Q4",
                _             => "?"
            };
            Console.WriteLine($"  Month {m,2} ({GetMonthSwitch(m),-10}) → {quarter}");
        }

        Console.WriteLine("\n  Q: When to prefer switch over if-else?");
        Console.WriteLine("  Use switch when comparing ONE variable against MULTIPLE discrete values.");
        Console.WriteLine("  Advantages of switch:");
        Console.WriteLine("    • Cleaner and more scannable for many discrete cases.");
        Console.WriteLine("    • Compiler can generate a jump table → O(1) instead of O(n).");
        Console.WriteLine("    • switch expressions (C# 8) are exhaustive — compiler warns if a");
        Console.WriteLine("      case is missing, which prevents subtle bugs.");
        Console.WriteLine("  Use if-else when conditions involve ranges, multiple variables,");
        Console.WriteLine("  or complex boolean logic (x > 10 && y < 5 etc.).\n");
    }
}
