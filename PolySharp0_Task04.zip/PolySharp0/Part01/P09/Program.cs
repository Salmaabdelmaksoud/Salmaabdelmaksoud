// ============================================================
//  Part01 – P09 | Array.Sort + IndexOf + LastIndexOf
//  Q: What is the time complexity of Array.Sort()?
// ============================================================
namespace P09_SortSearch;

class Program
{
    static void Print(int[] arr, string label)
        => Console.WriteLine($"  {label,-34}: [{string.Join(", ", arr)}]");

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P09  |  Sort + Search                   ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // ── Sorting ───────────────────────────────────────────────────
        int[] numbers = { 64, 25, 12, 22, 11, 90, 37, 55, 22, 80, 22 };
        Print(numbers, "Original array");

        int[] ascending = (int[])numbers.Clone();
        Array.Sort(ascending);
        Print(ascending, "Sorted ascending (Array.Sort)");

        int[] descending = (int[])ascending.Clone();
        Array.Reverse(descending);
        Print(descending, "Sorted descending (Sort + Reverse)");

        // Sort with custom comparer
        string[] words = { "banana", "Apple", "cherry", "Date", "elderberry" };
        Console.Write("\n  Words before sort        : [");
        Console.Write(string.Join(", ", words));
        Console.WriteLine("]");

        Array.Sort(words, StringComparer.OrdinalIgnoreCase);
        Console.Write("  Words after sort (no case): [");
        Console.Write(string.Join(", ", words));
        Console.WriteLine("]");

        // ── Searching ─────────────────────────────────────────────────
        Console.WriteLine("\n  ── Searching in sorted array ──");
        Print(ascending, "Sorted numbers");

        int[] targets = { 22, 11, 99, 37 };
        foreach (int t in targets)
        {
            int first = Array.IndexOf(ascending, t);
            int last  = Array.LastIndexOf(ascending, t);

            if (first == -1)
                Console.WriteLine($"  Search({t,2})  → NOT FOUND");
            else if (first == last)
                Console.WriteLine($"  Search({t,2})  → index {first}  (single occurrence)");
            else
                Console.WriteLine($"  Search({t,2})  → first={first}  last={last}  (multiple)");
        }

        // BinarySearch (requires sorted array)
        Console.WriteLine("\n  ── Binary Search (requires sorted array) ──");
        Print(ascending, "Sorted array");
        int[] bsTargets = { 22, 90, 50 };
        foreach (int t in bsTargets)
        {
            int result = Array.BinarySearch(ascending, t);
            if (result >= 0)
                Console.WriteLine($"  BinarySearch({t,2}) → found at index {result}");
            else
                Console.WriteLine($"  BinarySearch({t,2}) → not found (complement={~result})");
        }

        Console.WriteLine("\n  Q: Time complexity of Array.Sort()?");
        Console.WriteLine("  Array.Sort() uses Introsort — a hybrid of:");
        Console.WriteLine("    • Quicksort   → O(n log n) average");
        Console.WriteLine("    • Heapsort    → O(n log n) worst case fallback");
        Console.WriteLine("    • Insertion sort → O(n²) but O(n) for small n (threshold ~16)");
        Console.WriteLine("  Overall: O(n log n) average AND worst case.");
        Console.WriteLine("  Space:   O(log n) for recursive call stack.");
        Console.WriteLine("  Array.IndexOf:    O(n) — linear scan.");
        Console.WriteLine("  Array.BinarySearch: O(log n) — requires sorted array.\n");
    }
}
