// ============================================================
//  Part01 – P03 | 2D Array — Student Grades (3 students × 3 subjects)
//  Q: GetLength() vs Length for multidimensional arrays?
// ============================================================
namespace P03_2DGrades;

class Program
{
    static void PrintGrades(int[,] grades, string[] students, string[] subjects)
    {
        int rows = grades.GetLength(0);
        int cols = grades.GetLength(1);

        Console.WriteLine();
        Console.Write($"  {"Student",-16}");
        foreach (string s in subjects) Console.Write($"  {s,-10}");
        Console.WriteLine("  Average");
        Console.WriteLine("  " + new string('-', 55));

        for (int i = 0; i < rows; i++)
        {
            Console.Write($"  {students[i],-16}");
            int total = 0;
            for (int j = 0; j < cols; j++)
            {
                Console.Write($"  {grades[i, j],-10}");
                total += grades[i, j];
            }
            Console.WriteLine($"  {(double)total / cols:F1}");
        }
        Console.WriteLine();
    }

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P03  |  2D Array — Student Grades       ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        string[] students = { "Ahmed Hassan", "Sara Mohamed", "Karim Ali" };
        string[] subjects = { "Math", "Science", "English" };
        int[,] grades = new int[3, 3];

        // Simulate user input with predefined values (for non-interactive demo)
        int[][] mockInput =
        {
            new[] { 85, 90, 78 },
            new[] { 92, 88, 95 },
            new[] { 70, 75, 80 },
        };

        Console.WriteLine("  Entering grades for each student:\n");
        for (int i = 0; i < 3; i++)
        {
            Console.WriteLine($"  Student: {students[i]}");
            for (int j = 0; j < 3; j++)
            {
                // In a real run: Console.Write($"    {subjects[j]}: "); input = int.Parse(Console.ReadLine()!);
                grades[i, j] = mockInput[i][j];
                Console.WriteLine($"    Enter {subjects[j]} grade: {grades[i, j]}");
            }
            Console.WriteLine();
        }

        Console.WriteLine("  ── Grade Report ──");
        PrintGrades(grades, students, subjects);

        // GetLength vs Length demo
        Console.WriteLine("  Demonstrating GetLength() vs Length:");
        Console.WriteLine($"  grades.Length          = {grades.Length}  (total elements: 3×3)");
        Console.WriteLine($"  grades.GetLength(0)    = {grades.GetLength(0)}  (number of rows)");
        Console.WriteLine($"  grades.GetLength(1)    = {grades.GetLength(1)}  (number of columns)");
        Console.WriteLine($"  grades.Rank            = {grades.Rank}  (number of dimensions)");

        // What happens when you use Length incorrectly on 2D
        Console.WriteLine("\n  Why Length alone is not enough for 2D arrays:");
        Console.WriteLine("  Length=9 tells you total elements, not shape.");
        Console.WriteLine("  GetLength(0)=3 rows, GetLength(1)=3 columns — you need both.\n");

        Console.WriteLine("  Q: GetLength() vs Length for multidimensional arrays?");
        Console.WriteLine("  Length      → total element count across ALL dimensions.");
        Console.WriteLine("                For [3,3] that's 9, for [4,5] that's 20.");
        Console.WriteLine("  GetLength(d)→ element count for dimension d only.");
        Console.WriteLine("                GetLength(0)=rows, GetLength(1)=columns.");
        Console.WriteLine("  Use GetLength() inside nested loops — Length alone is misleading.\n");
    }
}
