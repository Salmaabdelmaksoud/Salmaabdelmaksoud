// ============================================================
//  Part01 – P07 | 2D Array — Matrix Print (formatted output)
//  Q: How can you format the output of a 2D array for readability?
// ============================================================
namespace P07_MatrixPrint;

class Program
{
    static void PrintMatrix(int[,] m, string title)
    {
        int rows = m.GetLength(0);
        int cols = m.GetLength(1);

        Console.WriteLine($"\n  {title}  ({rows}×{cols})");
        Console.WriteLine("  ┌" + string.Join("┬", Enumerable.Repeat("──────", cols)) + "┐");

        for (int i = 0; i < rows; i++)
        {
            Console.Write("  │");
            for (int j = 0; j < cols; j++)
                Console.Write($" {m[i, j],4} │");
            Console.WriteLine();

            if (i < rows - 1)
                Console.WriteLine("  ├" + string.Join("┼", Enumerable.Repeat("──────", cols)) + "┤");
        }

        Console.WriteLine("  └" + string.Join("┴", Enumerable.Repeat("──────", cols)) + "┘");
    }

    static void PrintFlat(int[,] m, string title)
    {
        int rows = m.GetLength(0);
        int cols = m.GetLength(1);

        Console.WriteLine($"\n  {title}:");
        for (int i = 0; i < rows; i++)
        {
            Console.Write("  Row " + i + ": [");
            for (int j = 0; j < cols; j++)
            {
                Console.Write($"{m[i, j],4}");
                if (j < cols - 1) Console.Write(", ");
            }
            Console.WriteLine("]");
        }
    }

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part01 – P07  |  2D Matrix Print                 ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝");

        // ── Matrix 1: 3×4 ─────────────────────────────────────────────
        int[,] matrix1 =
        {
            {  1,  2,  3,  4 },
            {  5,  6,  7,  8 },
            {  9, 10, 11, 12 }
        };

        PrintMatrix(matrix1, "Matrix 1 (box format)");
        PrintFlat(matrix1,   "Matrix 1 (row format)");

        // ── Matrix 2: multiplication table ────────────────────────────
        int size = 5;
        int[,] multTable = new int[size, size];
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++)
                multTable[i, j] = (i + 1) * (j + 1);

        PrintMatrix(multTable, "5×5 Multiplication Table");

        // ── Matrix 3: identity matrix ─────────────────────────────────
        int[,] identity = new int[4, 4];
        for (int i = 0; i < 4; i++)
            identity[i, i] = 1;
        PrintMatrix(identity, "4×4 Identity Matrix");

        // ── Column/row sums ───────────────────────────────────────────
        Console.WriteLine("\n  Row and Column Sums for Matrix 1:");
        for (int i = 0; i < matrix1.GetLength(0); i++)
        {
            int rowSum = 0;
            for (int j = 0; j < matrix1.GetLength(1); j++)
                rowSum += matrix1[i, j];
            Console.WriteLine($"  Row {i} sum = {rowSum}");
        }

        Console.WriteLine("\n  Q: How to format 2D array output for readability?");
        Console.WriteLine("  1. Use fixed-width formatting: {value,4} aligns columns.");
        Console.WriteLine("  2. Draw borders with box-drawing chars (┌─┬─┐ etc.).");
        Console.WriteLine("  3. Print row/column headers for context.");
        Console.WriteLine("  4. Add row sums or column sums where helpful.\n");
    }
}
