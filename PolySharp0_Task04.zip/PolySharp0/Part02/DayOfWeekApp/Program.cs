// ============================================================
//  Part02 | DayOfWeek Enum — integer input → day name
//  Q3: What happens if user enters outside 1-7?
// ============================================================
namespace DayOfWeekApp;

// Custom enum — explicitly assigned values matching 1-7 user input
public enum DayOfWeek
{
    Monday    = 1,
    Tuesday   = 2,
    Wednesday = 3,
    Thursday  = 4,
    Friday    = 5,
    Saturday  = 6,
    Sunday    = 7
}

class Program
{
    static string DayType(DayOfWeek day)
        => day is DayOfWeek.Saturday or DayOfWeek.Sunday ? "Weekend 🎉" : "Weekday 💼";

    static void Main()
    {
        Console.WriteLine("╔══════════════════════════════════════════════════╗");
        Console.WriteLine("║  Part02  |  DayOfWeek Enum                        ║");
        Console.WriteLine("╚══════════════════════════════════════════════════╝\n");

        // ── Print all enum values ─────────────────────────────────────
        Console.WriteLine("  All days in the enum:");
        Console.WriteLine($"  {"#",-4} {"Name",-12} {"Value",-8} {"Type"}");
        Console.WriteLine("  " + new string('-', 38));
        foreach (DayOfWeek d in Enum.GetValues<DayOfWeek>())
            Console.WriteLine($"  {(int)d,-4} {d,-12} {(int)d,-8} {DayType(d)}");

        // ── Simulated inputs (interactive in real run) ────────────────
        Console.WriteLine("\n  Testing inputs:\n");
        int[] testInputs = { 1, 4, 6, 7, 0, 8, -1, 99 };

        foreach (int input in testInputs)
        {
            Console.Write($"  Input = {input,3}  →  ");

            // Validate range first
            if (input < 1 || input > 7)
            {
                Console.WriteLine($"Invalid! Must be 1-7. Got {input}.");
                continue;
            }

            // Enum.Parse approach
            if (Enum.TryParse<DayOfWeek>(input.ToString(), out DayOfWeek day1))
            {
                Console.WriteLine($"{day1}  [{DayType(day1)}]");
            }
            else
            {
                Console.WriteLine("Could not parse.");
            }
        }

        // ── Enum.Parse demo ───────────────────────────────────────────
        Console.WriteLine("\n  Enum.Parse demos:");

        // Parse from integer string
        DayOfWeek d1 = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), "3");
        Console.WriteLine($"  Enum.Parse(\"3\")         = {d1}  (int→enum cast)");

        // Parse from name string
        DayOfWeek d2 = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), "Friday");
        Console.WriteLine($"  Enum.Parse(\"Friday\")    = {d2}  (value={(int)d2})");

        // Safe parse
        if (Enum.TryParse<DayOfWeek>("Monday", out DayOfWeek d3))
            Console.WriteLine($"  TryParse(\"Monday\")      = {d3}  ✓");

        if (!Enum.TryParse<DayOfWeek>("Funday", out DayOfWeek d4))
            Console.WriteLine($"  TryParse(\"Funday\")      = failed ✓  (not in enum)");

        // ── Out-of-range behaviour ────────────────────────────────────
        Console.WriteLine("\n  What happens with out-of-range values (8, 0)?");

        // C# allows casting any int to an enum — no automatic validation!
        DayOfWeek invalid1 = (DayOfWeek)8;
        DayOfWeek invalid2 = (DayOfWeek)0;
        Console.WriteLine($"  (DayOfWeek)8  = {invalid1}  (compiles, but not a named value!)");
        Console.WriteLine($"  (DayOfWeek)0  = {invalid2}  (no name — prints as 0)");
        Console.WriteLine($"  Enum.IsDefined((DayOfWeek)8) = {Enum.IsDefined(typeof(DayOfWeek), 8)}");
        Console.WriteLine($"  Enum.IsDefined((DayOfWeek)3) = {Enum.IsDefined(typeof(DayOfWeek), 3)}");

        Console.WriteLine("\n  Q3: What happens if user enters outside 1-7?");
        Console.WriteLine("  Without validation: (DayOfWeek)8 compiles but has no name.");
        Console.WriteLine("  Enum.IsDefined() returns false — the value is technically");
        Console.WriteLine("  an enum but doesn't correspond to any declared member.");
        Console.WriteLine("  Best practice: validate range BEFORE casting, or use");
        Console.WriteLine("  Enum.IsDefined() / Enum.TryParse() to detect bad values.\n");
    }
}
