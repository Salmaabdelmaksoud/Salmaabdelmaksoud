# PolySharp0 🔷
## C# Task 04 | Arrays · Loops · Enums · Input Validation
### 10 Problems + Part02 DayOfWeek + Full Theory + Bonus

---

## 🚀 How to Open in Visual Studio

1. Extract the ZIP anywhere
2. Double-click **`PolySharp0.sln`**
3. Right-click any project → **Set as Startup Project**
4. Press **Ctrl+F5**

---

## 📁 Project Map

### Part 01 — 10 Problems

| # | Project | Topic |
|---|---------|-------|
| 01 | `P01_ArrayInit` | 3 ways to initialise arrays + IndexOutOfRangeException |
| 02 | `P02_ShallowDeepCopy` | Shallow copy vs Clone() vs Array.Copy() |
| 03 | `P03_2DGrades` | 2D array grades — GetLength() demo |
| 04 | `P04_ArrayMethods` | Sort, Reverse, IndexOf, Copy, Clear |
| 05 | `P05_LoopTypes` | for / foreach / while + do-while |
| 06 | `P06_InputValidation` | do-while + int.TryParse defensive coding |
| 07 | `P07_MatrixPrint` | 2D array formatted matrix output |
| 08 | `P08_MonthName` | Month: if-else vs switch vs switch expression |
| 09 | `P09_SortSearch` | Array.Sort + IndexOf + LastIndexOf + BinarySearch |
| 10 | `P10_SumLoops` | Sum with for vs foreach + timing comparison |

### Part 02

| Project | Topic |
|---------|-------|
| `DayOfWeekApp` | DayOfWeek enum with Enum.Parse + out-of-range handling |

---

## 📚 Part 02 — Theory

### 1. LinkedIn Article: Loop Statements in C#

**"Loops in C#: for, foreach, while, do-while — and When to Use Each"**

Loops are the heartbeat of any program. Getting comfortable with all four
loop types in C# is one of the first signs of a developer levelling up.

**The `for` loop — when you know the count:**
```csharp
for (int i = 0; i < array.Length; i++)
    Console.WriteLine(array[i]);
```
Use `for` when you need the index. It gives you full control over start, stop,
and step. It is the only loop that lets you iterate backwards, skip elements, or
modify the collection index while iterating.

**The `foreach` loop — clean, safe iteration:**
```csharp
foreach (int item in array)
    Console.WriteLine(item);
```
`foreach` works on any `IEnumerable<T>` — arrays, lists, dictionaries, custom
collections. You can't accidentally step out of bounds. You can't accidentally
modify the index. It signals "I'm just reading this" to anyone reading your code.
The compiler and JIT optimise `foreach` on arrays into direct indexed access, so
there's no performance penalty.

**The `while` loop — condition-driven iteration:**
```csharp
while (!done)
{
    Process();
    done = CheckCompletion();
}
```
Use `while` when you don't know in advance how many iterations are needed. Reading
from a file, waiting for a network response, or processing until a sentinel value
arrives are natural `while` scenarios.

**The `do-while` loop — guaranteed first execution:**
```csharp
do
{
    Console.Write("Enter a number: ");
    valid = int.TryParse(Console.ReadLine(), out number);
} while (!valid);
```
`do-while` is the input validation loop. It guarantees the body runs at least once
before checking the condition, which perfectly matches "ask the user, then check
if their answer was valid".

**The rule of thumb:**
- Know the count → `for`
- Reading a collection → `foreach`
- Unknown condition → `while`
- Must run once → `do-while`

---

### 2. DayOfWeek Enum — see `DayOfWeekApp` project for full code

### 3. What happens if user enters outside 1-7?

Without explicit validation, C# silently allows casting any integer to an enum.
`(DayOfWeek)8` compiles fine but prints as `8` since no member has that value.
`Enum.IsDefined(typeof(DayOfWeek), 8)` returns `false`.
Always validate with a range check or `Enum.IsDefined` before accepting the input.

---

## 🎁 Part 03 — Bonus

### Self-Study Report

**Key takeaways from Task 04:**

- Arrays are reference types in C# — a plain assignment just copies the reference,
  not the data. Always use Clone() or Array.Copy() when you need independence.
- 2D arrays need GetLength(0) and GetLength(1) inside loops — Length alone gives
  the total element count and doesn't reveal the shape.
- Array.Sort() uses Introsort — O(n log n) average and worst case.
  Array.IndexOf is O(n). Array.BinarySearch is O(log n) but needs a sorted array.
- foreach is idiomatic C# for read-only iteration. for is necessary when you need
  the index or when modifying the array during iteration.
- int.TryParse is always safer than int.Parse. TryParse returns false on bad input;
  Parse throws a FormatException. In a do-while loop, TryParse-based validation
  gives clean, crash-free user input handling.
- switch expressions (C# 8+) are exhaustive — the compiler warns if any case is
  missing, making them safer than chains of if-else for discrete value matching.

---

### Stack and Heap — Default Sizes and Considerations

**Stack:**
The stack is where local variables, method parameters, and return addresses live.
It is a LIFO structure allocated per thread.

- Default size: **1 MB** on 32-bit Windows, **4 MB** on 64-bit Windows (per thread).
- Can be configured via thread constructor: `new Thread(Method, stackSizeBytes)`.
- Linux defaults are typically **8 MB** per thread (configurable via `ulimit -s`).

**Heap:**
The heap is where objects created with `new` live. Managed by the .NET GC.

- No fixed default size — grows dynamically as needed (limited by OS memory).
- GC organises it into generations (Gen 0, Gen 1, Gen 2) and the Large Object Heap (LOH).
- Gen 0: small short-lived objects (~256 KB).
- LOH: objects ≥ 85,000 bytes — collected separately, can fragment.

**Key Considerations:**

| Factor | Stack | Heap |
|--------|-------|------|
| Speed | Very fast (pointer move) | Slower (GC overhead) |
| Size | Fixed, small | Dynamic, large |
| Overflow | StackOverflowException | OutOfMemoryException |
| Lifetime | Scoped to method call | Until GC collects |
| Types stored | Value types, refs | Objects (reference types) |

**StackOverflowException** typically occurs from infinite recursion.
There is no way to catch it in managed code — the process must restart.
Avoid deep recursion on the stack; convert to iterative or use an explicit stack.

**Memory fragmentation on the heap** can be a performance concern for long-running
applications. The GC compacts Gen 0 and Gen 1 but LOH is not compacted by default
(configurable since .NET Core 3.0 via `GCSettings.LargeObjectHeapCompactionMode`).

---

### What is Time Complexity?

Time complexity describes how the runtime of an algorithm grows relative to its
input size `n`. It is expressed in Big O notation.

**Common complexities (best to worst):**

| Notation | Name | Example |
|----------|------|---------|
| O(1) | Constant | Array element access `arr[i]` |
| O(log n) | Logarithmic | Binary search, balanced BST |
| O(n) | Linear | Linear scan, Array.IndexOf |
| O(n log n) | Log-linear | Array.Sort (Introsort) |
| O(n²) | Quadratic | Bubble sort, Selection sort |
| O(2ⁿ) | Exponential | Brute-force subset enumeration |

**Why it matters:**

```
n = 1,000,000

O(1)       → 1 operation
O(log n)   → ~20 operations
O(n)       → 1,000,000 operations
O(n log n) → ~20,000,000 operations
O(n²)      → 1,000,000,000,000 operations — unusable
```

**Practical C# examples:**

```csharp
int x = arr[5];              // O(1)  — direct address
Array.BinarySearch(arr, v);  // O(log n) — sorted array required
Array.IndexOf(arr, v);       // O(n)  — linear scan
Array.Sort(arr);             // O(n log n) — Introsort
// Naive nested loop         // O(n²) — double loop over n elements
```

Space complexity follows the same notation — O(1) for in-place algorithms,
O(n) for algorithms that create a copy of the input.

---

## 🛠 Requirements
- .NET 8 SDK
- Visual Studio 2022 (any edition)

## 📤 GitHub
```bash
git init && git add . && git commit -m "Task04 - PolySharp0 Arrays, Loops, Enums" && git push
```
